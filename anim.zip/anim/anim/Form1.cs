﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace anim
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void picture_MouseEnter(object sender, EventArgs e)
        {
            {
            //    int x = picture.Location.X;
            //    int y = picture.Location.Y;
            //    picture.Location = new Point(x + 12, y + 12);



            }
        }

        private void picture_MouseLeave(object sender, EventArgs e)
        {
            //int x = picture.Location.X;
            //int y = picture.Location.Y;
            //picture.Location = new Point(x - 12, y - 12);


        }

        private void picture_MouseHover(object sender, EventArgs e)
        {
           int x = picture.Location.X;
            int y = picture.Location.Y;
            picture.Location = new Point(x + 12, y + 12);
        }

        private void picture_Move(object sender, EventArgs e)
        {
            //int x = picture.Location.X;
            //int y = picture.Location.Y;
            //picture.Location = new Point(x - 12, y - 12);

        }
    }
}
