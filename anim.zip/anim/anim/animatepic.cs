﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace anim
{
    public partial class animatepic : Form
    {
        public animatepic()
        {
            InitializeComponent();
        }

        private void animatepic_Load(object sender, EventArgs e)
        {
            
        }
        private void animatepic_KeyDown(object sender, KeyEventArgs e)
        {
            //int x = pictureBox1.Location.X;
            //int y = pictureBox1.Location.Y;

            //if (e.KeyCode == Keys.Right)
            //{ x += 1; }

            //else if (e.KeyCode == Keys.Left)
            //{ x -= 1; }
            //pictureBox1.Location = new Point(x, y);
        }

        private void animatepic_KeyDown_1(object sender, KeyEventArgs e)
        {
            //int x = pictureBox1.Location.X;
            //int y = pictureBox1.Location.Y;

           
            //if (e.KeyCode == Keys.Right)
            //{
            //    //for (;  x<816; i++)
            //    {
            //        x += 10;
            //    }
            //}
            

            //else if (e.KeyCode == Keys.Left)
            // x -= 10; 
            //pictureBox1.Location = new Point(x, y);
        }

        private void animatepic_MouseClick(object sender, MouseEventArgs e)
        {
            int x = pictureBox1.Location.X;
            int y = pictureBox1.Location.Y;

            if (e.Clicks > 0)
            { x += 1; }
        }

        private void buttonBTN_Click(object sender, EventArgs e)
        {
            this.timer1.Enabled = true;
            //for (int i = 0; i < 500; i++)
            //{
            //    //Tempbox is a picturebox
            //    this.pictureBox2.Location = new Point(this.pictureBox2.Left++, 0);
            //    Application.DoEvents();
            //    System.Threading.Thread.Sleep(50);
            //}

            //using (Graphics g = Graphics.FromImage(BufferBm))
            //{
            //    for (int i = 0; i < 500; i++)
            //    {
            //        g.DrawImage(tempContolImage, new System.Drawing.Point(i, 0));
            //        this.Tempbox.Image = BufferBm;
            //        Application.DoEvents();
            //        System.Threading.Thread.Sleep(50);
            //    }
            //}
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // calculate new position
          ////  this.pictureBox1.Top++;
            this.pictureBox1.Left++;

            // when to stop
            do
            {
                if (this.pictureBox1.Top > (this.Height - (2 * this.pictureBox1.Height)))
                {
                    this.timer1.Enabled = false;
                }
            } while (true);
            
        }
    }
}
