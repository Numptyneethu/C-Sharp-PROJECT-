﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBase.dto
{
    class StudentMARK
    {
      

        private String studentID;
        public String StudentID
        {
            get { return studentID; }
            set { studentID = value; }
        }


        private String studentNAME;
        public String StudentNAME
        {
            get { return studentNAME; }
            set { studentNAME = value; }
        }


        private int mark1;
        public int Mark1
        {
            get { return mark1; }
            set { mark1 = value; }
        }


        private int mark2;
        public int Mark2
        {
            get { return mark2; }
            set { mark2 = value; }
        }


        private int mark3;
        public int Mark3
        {
            get { return mark3; }
            set { mark3 = value; }
        }

        private int total;
        public int Total
        {
            get { return total; }
            set { total = value; }
        }

        private String result;
        public String Result
        {
            get { return result; }
            set { result = value; }
        }




    }
}


