﻿INSERT INTO [dbo].[student_mark] ([Id], [student_name], [mark1], [mark2], [mark3], [total], [result]) VALUES (N'stu101', N'neenu', 44, 55, 34, 160, N'pass')
INSERT INTO [dbo].[student_mark] ([Id], [student_name], [mark1], [mark2], [mark3], [total], [result]) VALUES (N'stu102', N'seesu', 66, 77, 99, 200, N'pass')
