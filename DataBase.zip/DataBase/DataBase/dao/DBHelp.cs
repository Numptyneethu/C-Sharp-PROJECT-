﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace DataBase.dao
{
    class DBHelp
    {
        public static SqlConnection GetConnection ()
        {
            SqlConnection con = null;
            string connectionstring = null;
            try
            {
                connectionstring = "Data Source = (LocalDB)\\MSSQLLocalDB; AttachDbFilename = C:\\Users\\1028289\\source\\repos\\DataBase\\DataBase\\data.mdf; Integrated Security = True";
                con = new SqlConnection(connectionstring); //connection with db
            }
            catch(Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : DB_helper.cs " + e3.Message.ToString());
            }
            return con;
        }
    }
}
