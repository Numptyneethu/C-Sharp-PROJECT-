﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataBase.dto;using System.Data.SqlClient;
using System.Data;

namespace DataBase.dao
{
     class student_DAO
    {
        public static int StudentMarkINSERT(StudentMARK studentMARK)
        {
            int output = 0;
            string sql = null;
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = " insert into student_mark(id,student_name,mark1,mark2,mark3,total,result) VALUES (";
                sql = sql + "'" + studentMARK.StudentID + "',";
                sql = sql + "'" + studentMARK.StudentNAME + "',";
                sql = sql + studentMARK. Mark1 + ",";
                sql = sql + studentMARK.Mark2 + ",";
                sql = sql + studentMARK. Mark3 + ",";
                sql = sql + studentMARK.Total + ",";
                sql = sql + "'" + studentMARK. Result + "')";

                    ////////////
                con = DBHelp.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs " + e3.Message.ToString());


            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }
        public static DataSet GetStudentIDs()
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
           
            DataSet dsSTudents = null;

            try
            {
                sql = "select Id from student_mark";
                con = DBHelp.GetConnection();
                con.Open();
                dsSTudents = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsSTudents);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs " + e3.Message.ToString());


            }
            finally
            {
                con.Close();
                
            }
            return dsSTudents;
        }
        public static StudentMARK GetStudentByIDs(string studentid)
        {
            StudentMARK objstudent = null;
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsSTudent = null;

            try
            {
                sql = "select * from student_mark where Id = '"+studentid+"'";
                con = DBHelp.GetConnection();
                con.Open();
                dsSTudent = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsSTudent);
                Object []Data = null;
                if(dsSTudent.Tables[0].Rows.Count>0)
                {
                    Data = dsSTudent.Tables[0].Rows[0].ItemArray;
                    objstudent = new StudentMARK();
                    objstudent.StudentID = Data[0].ToString();
                    objstudent.StudentNAME = Data[1].ToString();
                    objstudent.Mark1 = Convert.ToInt32(Data[2].ToString());
                    objstudent.Mark2 = Convert.ToInt32(Data[3].ToString());
                    objstudent.Mark3 = Convert.ToInt32(Data[4].ToString());
                    objstudent.Total = Convert.ToInt32(Data[5].ToString());
                    objstudent.Result = Data[6].ToString();
                }


            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs " + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return objstudent;
        }
        public static String GetLastStudentID()
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsSTudents = null;

            string lastastudentId = null;
            Object[] Data = null;

            try
            {
                sql = "select Id from student_mark order by Id desc";
                con = DBHelp.GetConnection();
                con.Open();
                dsSTudents = new DataSet();
                adapter = new SqlDataAdapter(sql, con);

                adapter.Fill(dsSTudents);
                if(dsSTudents.Tables[0].Rows.Count>0)
                {
                    Data = dsSTudents.Tables[0].Rows[0].ItemArray;
                    lastastudentId = Data[0].ToString();

                }
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs : GetLastStudentID" + e3.Message.ToString());

            }
            finally
            {
                con.Close();

            }
            return lastastudentId;
        }
        public static int StudentMarkDelete(StudentMARK StudentID)
        {
            int output = 0;
            string sql = null;
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = " delete from student_mark where Id='" + StudentID+ ";";
                
                con = DBHelp.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs:StudentMarkDelete() " + e3.Message.ToString());


            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }
        public static int StudentMarkUPDATE(StudentMARK studentMARK)
        {
            int output = 0;
            string sql = null;
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = " update student_mark set ";
                sql = sql + "student_name='" + studentMARK.StudentNAME + "',";

                sql = sql + " mark1=" + studentMARK.Mark1 + ",";
                sql = sql + " mark2=" + studentMARK.Mark2 + ",";
                sql = sql + " mark3=" + studentMARK.Mark3 + ",";
                sql = sql + " total=" + studentMARK.Total + ",";
                sql = sql + " result='" + studentMARK.Result + "'";
                sql = sql + "where Id=" + studentMARK.StudentID + " ";

                
                con = DBHelp.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs : StudentMarkUPDATE " + e3.Message.ToString());


            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }
        public static DataSet GetStudents()
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsSTudents = null;

            try
            {
                sql = "select * from student_mark";
                con = DBHelp.GetConnection();
                con.Open();
                dsSTudents = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsSTudents);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs: GetStudents " + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return dsSTudents;
        }
        public static DataSet GetStudentsLike(string likeName)
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsSTudents = null;

            try
            {
                sql = "select * from student_mark where student_name like '" + likeName+"%'";
                con = DBHelp.GetConnection();
                con.Open();
                dsSTudents = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsSTudents);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs: GetStudentsLike " + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return dsSTudents;
        }
    }
}
