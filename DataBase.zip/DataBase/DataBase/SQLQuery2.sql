﻿select * from student_mark where result= 'PASS'and total>150
