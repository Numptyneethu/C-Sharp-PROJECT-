﻿CREATE TABLE [dbo].[student_personal]
(
	[Id] VARCHAR(50) NOT NULL PRIMARY KEY, 
    [email] VARCHAR(50) NOT NULL, 
    [mobileNumber] INT NOT NULL, 
    [address] VARCHAR(500) NOT NULL, 
    [dob] DATE NOT NULL, 
)
