﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBase.helper
{
    class UtilityHelper
    {
        public static string GenerateId(string oldID)
        {
            string prefix, suffix;
            int next;
            string newID = null;
            try
            {
                
                prefix = oldID.Substring(0, 3);
                suffix = oldID.Substring(3);
                next= Convert.ToInt32(suffix) + 1;
                newID = prefix + next;

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : UtilityHelper.cs : GenerateId" + e3.Message.ToString());

            }
            return newID;
        }



    }
}
