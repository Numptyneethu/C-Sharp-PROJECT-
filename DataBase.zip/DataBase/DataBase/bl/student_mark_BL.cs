﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataBase.dto;
using DataBase.dao;
using System.Data.SqlClient;
using DataBase.helper;

using System.Data;

namespace DataBase.bl
{
    class student_mark_BL
    {


        public static int StudentMarkINSERT(StudentMARK studentMARK)
        {
            int output = 0;
           
          

            try
            {
                studentMARK.Total = studentMARK.Mark1 + studentMARK.Mark2 + studentMARK.Mark3;

                if (studentMARK.Mark1 < 50 || studentMARK.Mark2 < 50)
                {
                    studentMARK.Result = "Fail";
                }
                else
                {
                    studentMARK.Result = "Pass";
                }

                output = student_DAO.StudentMarkINSERT(studentMARK); 

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_mark_BL.cs " + e3.Message.ToString());


            }
           
            return output;
        }
        public static DataSet GetStudentIDs()
        {
            //String sql = "";
            
            DataSet dsSTudents = null;

            try
            {

                dsSTudents = student_DAO.GetStudentIDs();

               
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_BL.cs :GetStudentIDs" + e3.Message.ToString());


            }
           
            return dsSTudents;
        }
        public static StudentMARK GetStudentByIDs(string studentid)
        {
            StudentMARK objstudent = null;
            

            try
            {
                objstudent = student_DAO.GetStudentByIDs(studentid);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_bl.cs " + e3.Message.ToString());
            }
            
            return objstudent;
        }
        public static int StudentMarkDelete(StudentMARK StudentID)
        {
            int output = 0;
            

            try
            {
                output = student_DAO.StudentMarkDelete(StudentID);

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_bl.cs:StudentMarkDelete() " + e3.Message.ToString());


            }
            return output;
        }
        public static int StudentMarkUPDATE(StudentMARK studentMARK)
        {
            int output = 0;
            

            try
            {
                studentMARK.Total = studentMARK.Mark1 + studentMARK.Mark2 + studentMARK.Mark3;

                if (studentMARK.Mark1 < 50 || studentMARK.Mark2 < 50)
                {
                    studentMARK.Result = "Fail";
                }
                else
                {
                    studentMARK.Result = "Pass";
                }
                output = student_DAO.StudentMarkUPDATE(studentMARK);

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_bl.cs : StudentMarkUPDATE " + e3.Message.ToString());


            }
           
            return output;
        }
        public static DataSet GetStudents()
        {
           
            DataSet dsSTudents = null;

            try
            {
                dsSTudents = student_DAO.GetStudents();
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_BL.cs " + e3.Message.ToString());


            }

            return dsSTudents;
        }
        public static String GetNewStudentID()
        {
            
            string lastastudentId = null;
            string newStudentId = null;

            try
            {

                lastastudentId = student_DAO.GetLastStudentID();
                if(lastastudentId!=null)
                {

                    newStudentId = UtilityHelper.GenerateId(lastastudentId);
                }
                else
                {
                    newStudentId = "stu101";
                }
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs : GetLastStudentID" + e3.Message.ToString());

            }
           
            return newStudentId;
        }
        public static DataSet GetStudentsLike(string likeName)
        {
          
            DataSet dsSTudents = null;

            try
            {
                dsSTudents = student_DAO.GetStudentsLike(likeName);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_BL.cs: GetStudentsLike() " + e3.Message.ToString());


            }
            
            return dsSTudents;
        }
    }
}

