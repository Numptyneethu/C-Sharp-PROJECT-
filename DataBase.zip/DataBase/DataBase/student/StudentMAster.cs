﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using DataBase.dto;
using DataBase.bl;
using System.Data;

namespace DataBase.student
{
    public partial class StudentMAster : Form
    {
        int countMark1 = 0;bool flagMark1 = false;
        int countMark2 = 0; bool flagMark2 = false;
        int countMark3 = 0; bool flagMark3 = false;

        public StudentMAster()
        {
            InitializeComponent();
        }
        private void LoadSTudentIDs()
        {
            DataSet dsStudentID = null;
            try
            {
                dsStudentID = student_mark_BL.GetStudentIDs();
                if(dsStudentID!=null)
                {
                    comboBox1.DataSource = dsStudentID.Tables[0];


                    comboBox1.ValueMember = "Id";
                    comboBox1.DisplayMember = "Id";

                }
                else
                {
                    labelmessage.Text = "No students avialbale";
                }
            }
            catch(Exception ex)
            {
                labelmessage.Text = ex.Message.ToString();
                     
            }
        }
        private void buttonsave_Click(object sender, EventArgs e)
        {
            
            //SqlConnection connection = null;
            //SqlCommand command = null;
            //String ConnectionString = null;
            //String sql = null;
            //String student_id, student_name, result;
            //int mark1, mark2, mark3, total;

            int output = 0;
            //try
            //{
            //    ConnectionString = "Data Source = (LocalDB)\\MSSQLLocalDB; AttachDbFilename = C:\\Users\\1028289\\source\\repos\\DataBase\\DataBase\\data.mdf; Integrated Security = True";
            //    connection = new SqlConnection(ConnectionString); //connection with db
            //    student_id = txtid.Text;
            //    student_name = txtname.Text;
            //    mark1 = Convert.ToInt32(txtmark1.Text);
            //    mark2 = Convert.ToInt32(txtmark2.Text);
            //    mark3 = Convert.ToInt32(txtmark3.Text);
            //    total = mark1 + mark2 + mark3;

            //    if (mark1 < 50 || mark2<50)
            //    {
            //        result = "Fail";
            //    }
            //    else
            //    {
            //        result = "Pass";
            //    }
            //    sql = " insert into student_mark(id,student_name,mark1,mark2,mark3,total,result) VALUES (";
            //    sql = sql + "'" + student_id + "',";
            //    sql = sql + "'" + student_name + "',";
            //    sql = sql + mark1 + ",";
            //    sql = sql + mark2 + ",";
            //    sql = sql + mark3 + ",";
            //    sql = sql + total + ",";
            //    sql = sql +"'"+ result + "')";



            //    connection.Open();//db open

            //    command = new SqlCommand(sql, connection);
            //    output = command.ExecuteNonQuery();

            //    if (output > 0)

            //    {
            //        labelmessage.Text = "success";

            //    }
            //    else
            //    {
            //        labelmessage.Text = "fail";
            //    }
            //}
            //catch(Exception e1)
            //{
            //    labelmessage.Text = e1.Message.ToString();
            //}
            //finally
            //{
            //    connection.Close();

            //    command.Dispose();


            //}
            
            StudentMARK studentMARK = null;

            try
            {
                if (buttonsave.Text == "NEW")
                {
                    buttonsave.Text = "SAVE";
                    ClearControl();
                    txtid.Text = student_mark_BL.GetNewStudentID();

                    buttondelete.Enabled = false;
                    buttonupdate.Enabled = false;
                    buttonclear.Text = "BACK";
                }
                else
                {


                    studentMARK = new StudentMARK();
                    studentMARK.StudentID = txtid.Text;// prop
                    studentMARK.StudentNAME = txtname.Text;
                    studentMARK.Mark1 = Convert.ToInt32(txtmark1.Text);
                    studentMARK.Mark2 = Convert.ToInt32(txtmark2.Text);
                    studentMARK.Mark3 = Convert.ToInt32(txtmark3.Text);
                    output = student_mark_BL.StudentMarkINSERT(studentMARK);

                    if (studentMARK.Mark1 < 0 || studentMARK.Mark1 > 100)
                    {
                        labelmessage.Text = "Enter a mark between 0-100";
                    }
                    else
                    {
                        if (output > 0)

                        {
                            labelmessage.Text = "success";
                            LoadSTudents();

                            buttonsave.Text = "NEW";
                            buttondelete.Enabled = true;
                            buttonupdate.Enabled = true;
                            buttonclear.Text = "CLEAR";
                        }
                        else
                        {
                            labelmessage.Text = "fail";
                        }

                    }
                }
            }
            catch (Exception e4)
            {
                labelmessage.Text = e4.Message.ToString();
            }
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtmark2_TextChanged(object sender, EventArgs e)
        {

        }

        private void StudentMAster_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'studentDbDataSet.student_mark' table. You can move, or remove it, as needed.
            //  this.student_markTableAdapter.Fill(this.studentDbDataSet.student_mark);
            LoadSTudents();
            LoadSTudentIDs();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // MessageBox.Show(comboBox1.Text);
            StudentMARK objStudent = null;
           
            try
            {
                objStudent = student_mark_BL.GetStudentByIDs(comboBox1.Text);
                if (objStudent != null)
                {
                    
                    txtid.Text = objStudent.StudentID;
                    txtname.Text = objStudent.StudentNAME;
                    txtmark1.Text = objStudent.Mark1.ToString();
                    txtmark2.Text = objStudent.Mark2.ToString();
                    txtmark3.Text = objStudent.Mark3.ToString();
                }
                
            }
            catch(Exception ex)
            {
                labelmessage.Text = ex.Message.ToString();
            }
        }

        private void buttondelete_Click(object sender, EventArgs e)
        {
            int output = 0;
            try
            {
                if (MessageBox.Show("Do u want to delete?", "s i s",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)

                {


                    // output = student_mark_BL.StudentMarkDelete(comboBox1.Text);
                    if (output > 0)
                    {
                        labelmessage.Text = "Student details deleted";
                        //                 this.student_markTableAdapter.Fill(this.studentmarkBindingSource,)
                        LoadSTudentIDs();


                    }
                    else
                    {
                        labelmessage.Text = "try later";
                    }
                }
            }
            catch(Exception e3)
            {
                labelmessage.Text = e3.Message.ToString();

            }
        }

        private void buttonupdate_Click(object sender, EventArgs e)
        {
            int output = 0;
            StudentMARK studentMARK = null;

            try
            {
                studentMARK = new StudentMARK();
                studentMARK.StudentID = txtid.Text;// prop
                studentMARK.StudentNAME = txtname.Text;
                studentMARK.Mark1 = Convert.ToInt32(txtmark1.Text);
                studentMARK.Mark2 = Convert.ToInt32(txtmark2.Text);
                studentMARK.Mark3 = Convert.ToInt32(txtmark3.Text);
                output = student_mark_BL.StudentMarkUPDATE(studentMARK);

                if (studentMARK.Mark1 < 0 || studentMARK.Mark1 > 100)
                {
                    labelmessage.Text = "Enter a mark1 between 0-100";
                    txtmark1.Focus();
                }
                else
                {
                    if (output > 0)

                    {
                        labelmessage.Text = "success";

                    }
                    else
                    {
                        labelmessage.Text = "fail";
                    }

                }
            }
            catch (Exception e4)
            {
                labelmessage.Text = e4.Message.ToString();
            }
        }
        private void LoadSTudents()
        {
            DataSet dsStudent = null;
            try
            {
                dsStudent = student_mark_BL.GetStudents();
                if (dsStudent != null)
                {
                    dgbstudent.DataSource = dsStudent.Tables[0];

                }
                else
                {
                    labelmessage.Text = "No students avialbale";
                }
            }
            catch (Exception ex)
            {
                labelmessage.Text = ex.Message.ToString();

            }

           
        }
        private void ClearControl()
        {
            txtid.Text = "";
            txtmark1.Text = "";
            txtmark2.Text = "";
            txtmark3.Text = "";
            txtname.Text = "";
            labelmessage.Text = "";

        }
        private void txtid_MouseHover(object sender, EventArgs e)
        {
           
        }

        private void panel1_MouseHover(object sender, EventArgs e)
        {

        }

        private void buttonclear_Click(object sender, EventArgs e)
        {
            if(buttonclear.Text=="BACK")
            {
                buttonsave.Text = "NEW";
                buttondelete.Enabled = true;
                buttonupdate.Enabled = true;
                buttonclear.Text = "CLEAR";
            }
            else
            {
                ClearControl();
            }
           
        }

        private void textsearch_TextChanged(object sender, EventArgs e)
        {
            
                DataSet dsStudent = null;
                try
                {
                    dsStudent = student_mark_BL.GetStudentsLike(textsearch.Text);
                    if (dsStudent != null)
                    {
                        dgbstudent.DataSource = dsStudent.Tables[0];

                    }
                    else
                    {
                        labelmessage.Text = "No students avialbale";
                    }
                }
                catch (Exception ex)
                {
                    labelmessage.Text = ex.Message.ToString();

                }


            
        }

        private void txtmark1_KeyDown(object sender, KeyEventArgs e)
        {
            flagMark1 = false;
            if(!txtmark1.Text.Contains(".") &&countMark1>0)
            {
                countMark1--;
            }


            if((e.KeyCode>=Keys.D0 && e.KeyCode<= Keys.D9)||
                (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9) || 
                ((e.KeyCode == Keys.Decimal || e.KeyCode == Keys.OemPeriod) && countMark1 <1 )
                || e.KeyCode==Keys.Back)
            {
                flagMark1 = true;


                if((e.KeyCode == Keys.Decimal || e.KeyCode == Keys.OemPeriod))
                {
                    countMark1++;
                }
            }
        }

        private void txtmark1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!flagMark1)
            {
                e.Handled = true; //handling event
            }
        }

        private void txtid_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgbstudent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgbstudent_SelectionChanged(object sender, EventArgs e)
        {

            string studentid, studentname;
            int mark1, mark2, mark3;

            if(dgbstudent.SelectedCells.Count>0) //name of grid view/select 1st row
            {
                int selectedrowindex = dgbstudent.SelectedCells[0].RowIndex; //select 1 whole row data 

                DataGridView selectedRow = dgbstudent.Rows[selectedrowindex]; //select 1 whole row data and store to an object named selected row

                studentid = Convert.ToString(selectedRow.Cells["studentid"].Value);
                studentname = Convert.ToString(selectedRow.Cells["studentname"].Value);
                mark1 = Convert.ToString(selectedRow.Cells["mark1"].Value);
                mark2 = Convert.ToString(selectedRow.Cells["mark2"].Value);
                mark3 = Convert.ToString(selectedRow.Cells["mark3"].Value);
                txtid.Text = studentid;
                txtname.Text = studentname;
                txtmark1.Text = mark1.ToString();
                txtmark2.Text = mark2.ToString();
                txtmark3.Text = mark3.ToString();


            }
        }
    }
    
}
