﻿namespace DataBase.student
{
    partial class StudentMAster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.txtmark3 = new System.Windows.Forms.TextBox();
            this.txtmark2 = new System.Windows.Forms.TextBox();
            this.txtmark1 = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtid = new System.Windows.Forms.TextBox();
            this.labelmark3 = new System.Windows.Forms.Label();
            this.labelmark2 = new System.Windows.Forms.Label();
            this.labelmark1 = new System.Windows.Forms.Label();
            this.labelname = new System.Windows.Forms.Label();
            this.labelid = new System.Windows.Forms.Label();
            this.labelheading = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonupdate = new System.Windows.Forms.Button();
            this.buttondelete = new System.Windows.Forms.Button();
            this.buttonclear = new System.Windows.Forms.Button();
            this.buttonsave = new System.Windows.Forms.Button();
            this.labelmessage = new System.Windows.Forms.Label();
            this.dgbstudent = new System.Windows.Forms.DataGridView();
            this.textsearch = new System.Windows.Forms.TextBox();
            this.labelSearchName = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgbstudent)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.txtmark3);
            this.panel1.Controls.Add(this.txtmark2);
            this.panel1.Controls.Add(this.txtmark1);
            this.panel1.Controls.Add(this.txtname);
            this.panel1.Controls.Add(this.txtid);
            this.panel1.Controls.Add(this.labelmark3);
            this.panel1.Controls.Add(this.labelmark2);
            this.panel1.Controls.Add(this.labelmark1);
            this.panel1.Controls.Add(this.labelname);
            this.panel1.Controls.Add(this.labelid);
            this.panel1.Location = new System.Drawing.Point(12, 73);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(481, 239);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.panel1.MouseHover += new System.EventHandler(this.panel1_MouseHover);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(138, 14);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(157, 21);
            this.comboBox1.TabIndex = 13;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // txtmark3
            // 
            this.txtmark3.Location = new System.Drawing.Point(138, 200);
            this.txtmark3.Name = "txtmark3";
            this.txtmark3.Size = new System.Drawing.Size(299, 20);
            this.txtmark3.TabIndex = 10;
            // 
            // txtmark2
            // 
            this.txtmark2.Location = new System.Drawing.Point(138, 166);
            this.txtmark2.Name = "txtmark2";
            this.txtmark2.Size = new System.Drawing.Size(299, 20);
            this.txtmark2.TabIndex = 9;
            this.txtmark2.TextChanged += new System.EventHandler(this.txtmark2_TextChanged);
            // 
            // txtmark1
            // 
            this.txtmark1.Location = new System.Drawing.Point(138, 121);
            this.txtmark1.Name = "txtmark1";
            this.txtmark1.Size = new System.Drawing.Size(299, 20);
            this.txtmark1.TabIndex = 8;
            this.txtmark1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtmark1_KeyDown);
            this.txtmark1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmark1_KeyPress);
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(138, 83);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(299, 20);
            this.txtname.TabIndex = 7;
            // 
            // txtid
            // 
            this.txtid.Location = new System.Drawing.Point(138, 50);
            this.txtid.Name = "txtid";
            this.txtid.ReadOnly = true;
            this.txtid.Size = new System.Drawing.Size(299, 20);
            this.txtid.TabIndex = 6;
            this.txtid.TextChanged += new System.EventHandler(this.txtid_TextChanged);
            this.txtid.MouseHover += new System.EventHandler(this.txtid_MouseHover);
            // 
            // labelmark3
            // 
            this.labelmark3.AutoSize = true;
            this.labelmark3.ForeColor = System.Drawing.Color.Maroon;
            this.labelmark3.Location = new System.Drawing.Point(23, 200);
            this.labelmark3.Name = "labelmark3";
            this.labelmark3.Size = new System.Drawing.Size(40, 13);
            this.labelmark3.TabIndex = 5;
            this.labelmark3.Text = "Mark 3";
            // 
            // labelmark2
            // 
            this.labelmark2.AutoSize = true;
            this.labelmark2.ForeColor = System.Drawing.Color.Maroon;
            this.labelmark2.Location = new System.Drawing.Point(23, 166);
            this.labelmark2.Name = "labelmark2";
            this.labelmark2.Size = new System.Drawing.Size(40, 13);
            this.labelmark2.TabIndex = 4;
            this.labelmark2.Text = "Mark 2";
            // 
            // labelmark1
            // 
            this.labelmark1.AutoSize = true;
            this.labelmark1.ForeColor = System.Drawing.Color.Maroon;
            this.labelmark1.Location = new System.Drawing.Point(23, 128);
            this.labelmark1.Name = "labelmark1";
            this.labelmark1.Size = new System.Drawing.Size(37, 13);
            this.labelmark1.TabIndex = 3;
            this.labelmark1.Text = "Mark1";
            // 
            // labelname
            // 
            this.labelname.AutoSize = true;
            this.labelname.ForeColor = System.Drawing.Color.Maroon;
            this.labelname.Location = new System.Drawing.Point(23, 90);
            this.labelname.Name = "labelname";
            this.labelname.Size = new System.Drawing.Size(35, 13);
            this.labelname.TabIndex = 2;
            this.labelname.Text = "Name";
            // 
            // labelid
            // 
            this.labelid.AutoSize = true;
            this.labelid.ForeColor = System.Drawing.Color.Maroon;
            this.labelid.Location = new System.Drawing.Point(23, 53);
            this.labelid.Name = "labelid";
            this.labelid.Size = new System.Drawing.Size(58, 13);
            this.labelid.TabIndex = 1;
            this.labelid.Text = "Student ID";
            // 
            // labelheading
            // 
            this.labelheading.AutoSize = true;
            this.labelheading.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.labelheading.Font = new System.Drawing.Font("Mistral", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelheading.Location = new System.Drawing.Point(155, 24);
            this.labelheading.Name = "labelheading";
            this.labelheading.Size = new System.Drawing.Size(204, 26);
            this.labelheading.TabIndex = 0;
            this.labelheading.Text = "Student Information System";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.buttonupdate);
            this.panel2.Controls.Add(this.buttondelete);
            this.panel2.Controls.Add(this.buttonclear);
            this.panel2.Controls.Add(this.buttonsave);
            this.panel2.Location = new System.Drawing.Point(12, 338);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(481, 68);
            this.panel2.TabIndex = 11;
            // 
            // buttonupdate
            // 
            this.buttonupdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.buttonupdate.ForeColor = System.Drawing.Color.Maroon;
            this.buttonupdate.Location = new System.Drawing.Point(236, 24);
            this.buttonupdate.Name = "buttonupdate";
            this.buttonupdate.Size = new System.Drawing.Size(75, 23);
            this.buttonupdate.TabIndex = 15;
            this.buttonupdate.Text = "UPDATE";
            this.buttonupdate.UseVisualStyleBackColor = false;
            this.buttonupdate.Click += new System.EventHandler(this.buttonupdate_Click);
            // 
            // buttondelete
            // 
            this.buttondelete.Location = new System.Drawing.Point(353, 24);
            this.buttondelete.Name = "buttondelete";
            this.buttondelete.Size = new System.Drawing.Size(75, 23);
            this.buttondelete.TabIndex = 14;
            this.buttondelete.Text = "DELETE";
            this.buttondelete.UseVisualStyleBackColor = true;
            this.buttondelete.Click += new System.EventHandler(this.buttondelete_Click);
            // 
            // buttonclear
            // 
            this.buttonclear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.buttonclear.ForeColor = System.Drawing.Color.Maroon;
            this.buttonclear.Location = new System.Drawing.Point(115, 24);
            this.buttonclear.Name = "buttonclear";
            this.buttonclear.Size = new System.Drawing.Size(75, 23);
            this.buttonclear.TabIndex = 1;
            this.buttonclear.Text = "CLEAR";
            this.buttonclear.UseVisualStyleBackColor = false;
            this.buttonclear.Click += new System.EventHandler(this.buttonclear_Click);
            // 
            // buttonsave
            // 
            this.buttonsave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.buttonsave.ForeColor = System.Drawing.Color.Maroon;
            this.buttonsave.Location = new System.Drawing.Point(6, 24);
            this.buttonsave.Name = "buttonsave";
            this.buttonsave.Size = new System.Drawing.Size(75, 23);
            this.buttonsave.TabIndex = 0;
            this.buttonsave.Text = "NEW";
            this.buttonsave.UseVisualStyleBackColor = false;
            this.buttonsave.Click += new System.EventHandler(this.buttonsave_Click);
            // 
            // labelmessage
            // 
            this.labelmessage.AutoSize = true;
            this.labelmessage.Location = new System.Drawing.Point(157, 57);
            this.labelmessage.Name = "labelmessage";
            this.labelmessage.Size = new System.Drawing.Size(0, 13);
            this.labelmessage.TabIndex = 12;
            // 
            // dgbstudent
            // 
            this.dgbstudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgbstudent.Location = new System.Drawing.Point(499, 73);
            this.dgbstudent.Name = "dgbstudent";
            this.dgbstudent.Size = new System.Drawing.Size(531, 333);
            this.dgbstudent.TabIndex = 16;
            this.dgbstudent.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgbstudent_CellContentClick);
            this.dgbstudent.SelectionChanged += new System.EventHandler(this.dgbstudent_SelectionChanged);
            // 
            // textsearch
            // 
            this.textsearch.Location = new System.Drawing.Point(650, 29);
            this.textsearch.Name = "textsearch";
            this.textsearch.Size = new System.Drawing.Size(100, 20);
            this.textsearch.TabIndex = 14;
            this.textsearch.TextChanged += new System.EventHandler(this.textsearch_TextChanged);
            // 
            // labelSearchName
            // 
            this.labelSearchName.AutoSize = true;
            this.labelSearchName.ForeColor = System.Drawing.Color.Maroon;
            this.labelSearchName.Location = new System.Drawing.Point(539, 32);
            this.labelSearchName.Name = "labelSearchName";
            this.labelSearchName.Size = new System.Drawing.Size(72, 13);
            this.labelSearchName.TabIndex = 14;
            this.labelSearchName.Text = "Search Name";
            // 
            // StudentMAster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1042, 494);
            this.Controls.Add(this.labelSearchName);
            this.Controls.Add(this.textsearch);
            this.Controls.Add(this.dgbstudent);
            this.Controls.Add(this.labelmessage);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.labelheading);
            this.Controls.Add(this.panel1);
            this.Name = "StudentMAster";
            this.Text = "StudentMAster";
            this.Load += new System.EventHandler(this.StudentMAster_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgbstudent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtmark3;
        private System.Windows.Forms.TextBox txtmark2;
        private System.Windows.Forms.TextBox txtmark1;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.Label labelmark3;
        private System.Windows.Forms.Label labelmark2;
        private System.Windows.Forms.Label labelmark1;
        private System.Windows.Forms.Label labelname;
        private System.Windows.Forms.Label labelid;
        private System.Windows.Forms.Label labelheading;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttonsave;
        private System.Windows.Forms.Button buttonclear;
        private System.Windows.Forms.Label labelmessage;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button buttondelete;
        private System.Windows.Forms.Button buttonupdate;
        private System.Windows.Forms.DataGridView dgbstudent;
        private System.Windows.Forms.TextBox textsearch;
        private System.Windows.Forms.Label labelSearchName;
    }
}