﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFAppDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Hello World");
        }

        private void ApplyButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"Description is  :  { this.DescriptionText.Text}");
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            this.weldecheckbox.IsChecked = this.assemblycheckbox.IsChecked = this.plasmacheckbox.IsChecked = 
            this.lasercheckbox.IsChecked = this.purchasecheckbox.IsChecked = this.lathecheckbox.IsChecked = this.drillcheckbox.IsChecked =
            this.foldcheckbox.IsChecked = this.rollcheckbox.IsChecked = this.sawcheckbox.IsChecked = false;
        }

        private void Checkbox_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void checkbox_Checked(object sender, RoutedEventArgs e)
        {
            this.LenghtText.Text += ((CheckBox)sender).Content;
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e) //finish
        {
            if(this.NoteText==null)
            {
                return;
            }
            var combo = ((ComboBox)sender);
            var value = (ComboBoxItem)combo.SelectedValue;

            this.NoteText.Text = (string)value.Content;
          
        }

        private void Assemblycheckbox_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}
