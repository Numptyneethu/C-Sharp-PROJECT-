﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ModuleTest2
{
    class CustomerDetails
    {
        public static void Main()
        {
            Customer objCustomer = new Customer();
            int number = objCustomer.ReadCustomerNo();
            Customer[] customerArray = new Customer[number];
            Console.WriteLine("\n--------- Enter Customer Details -----------");
            for (int i = 0; i < number; i++)
            {
                Console.WriteLine("\n****** Enter Customer {0} ******", i + 1);
                customerArray[i] = new Customer();
                customerArray[i].ReadCustomers();
               
            }
            Console.WriteLine("\n--------- Customer Details -----------");
            for (int i = 0; i < number; i++)
            {
                Console.WriteLine("\n****** Details of Customer {0} ******", i + 1);
             
                customerArray[i].DisplayCustomer();
                Console.WriteLine("\n********************************");
            }
            Console.ReadKey();
        }

    }
    class Customer
    {
        private int customerID;
        private string customerName;
        private int typeUser;
        int noOfCustomers;

        public int CustomerID
        {
            get { return customerID; }
            set { customerID = value; }
        }
        public string CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }
        public int TypeUser
        {
            get { return typeUser; }
            set
            {
                if (typeUser == 1)
                {
                    typeUser = value;
                }
                else
                {
                    typeUser = value;
                }
            }
        }
        public int ReadCustomerNo()
        {
            Console.WriteLine("Enter the No Of Customers ");
            noOfCustomers = Convert.ToInt32(Console.ReadLine());
            return noOfCustomers;
        }
        public void ReadCustomers()
        {
            Console.Write("Enter Customer ID : ");
            customerID = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Customer Name : ");
            customerName = Console.ReadLine();
            Console.Write("Enter User Type (1-Retail , 2-Wholesale) : ");
            typeUser = Convert.ToInt32(Console.ReadLine());
        }
        public void DisplayCustomer()
        {
            Console.Write("\nCustomer ID : " + customerID);
            Console.Write("\nCustomer Name : " + customerName);
            Console.Write("\nCustomer User Type : " + Enum.GetName(typeof(userType), typeUser));
        }
    }
    enum userType
    {
        retail = 1,
        wholesale
    };
}