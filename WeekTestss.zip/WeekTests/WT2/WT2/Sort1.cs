﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ModuleTest2
{
    class MOBException : Exception
    {
        public MOBException()
        {
            Console.WriteLine("****** Wrong input , Please Enter a Value Greater than 0**********\n");
        }
    }
    class SalesAmountOfNMonths
    {
        int noofMonths;
        int[] salesAmount;
        public void ReadData()
        {
            Console.WriteLine("Enter the No Of Months ");
            noofMonths = Convert.ToInt32(Console.ReadLine());
            salesAmount = new int[noofMonths];
            Console.WriteLine("Enter the Sales amount of each Month\n");

            for (int i = 0; i < noofMonths; i++)
            {
                try
                {
                    Console.Write("Enter the Sales Amount of Month -  {0} : ", i + 1);
                    salesAmount[i] = Convert.ToInt32(Console.ReadLine());
                    if (salesAmount[i] < 0)
                    {
                        throw new MOBException();
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("*** Wrong input | Please Enter a valid Integer***" + e.Message.ToString());
                    i--;
                }

            }
        }
        public void SortSalesAmount()
        {
            int[] sortSalesAmount = salesAmount;
            for (int i = 0; i < noofMonths - 1; i++)
            {
                for (int j = i + 1; j < noofMonths; j++)
                {
                    if (sortSalesAmount[j] < sortSalesAmount[i])
                    {
                        int temp = sortSalesAmount[j];
                        sortSalesAmount[j] = sortSalesAmount[i];
                        sortSalesAmount[i] = temp;
                    }
                }
            }
            Console.WriteLine("\n----------SALES REPORT-------------\n");
            foreach (int i in sortSalesAmount)
            {
                Console.Write(i + " ");
            }
        }
        public static void Main()
        {
            SalesAmountOfNMonths objSalesAmount = new SalesAmountOfNMonths();
            objSalesAmount.ReadData();
            objSalesAmount.SortSalesAmount();
            Console.ReadKey();
        }
    }
}