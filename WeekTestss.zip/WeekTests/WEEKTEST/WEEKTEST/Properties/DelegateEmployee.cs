﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WEEKTEST.Properties
{
    class DelegateEmployee
    {
        public static void Main()
        {
            List<Employee> employeeslist = new List<Employee>();
            employeeslist.Add(new Employee { ID = 1, Name = "abc", Experience = 4, Salary = 10000 });
            employeeslist.Add(new Employee { ID = 2, Name = "def", Experience = 6, Salary = 100000 });
            Console.WriteLine("-------------List of Employees-----------");
            Employee.GetPromotedList(employeeslist);
            Console.ReadKey();
        }

    }

    class Employee
    {
        public int ID  //properties
        { get; set; }

        public string Name
        { get; set; }

        public int Experience
        { get; set; }

        public int Salary
        { get; set; }

        public static void GetPromotedList(List<Employee> employeeslist)   //employeeslist - list name ; Employee-Class name
        {
            foreach (Employee employee in employeeslist)
            {
                if (employee.Experience >= 5)
                {
                    Console.WriteLine("Emp ID   " + employee.ID);
                    Console.WriteLine("Name   " + employee.Name);
                    Console.WriteLine("Experience   " + employee.Experience);
                    Console.WriteLine("Salary   " + employee.Salary);
                }
            }
        }

    }

}
