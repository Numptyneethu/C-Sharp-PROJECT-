﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WEEKTEST
{
    class Program
    {
        static void Main(string[] args)
        {
            int no;

            
            Sort obj = new Sort();
            obj.Read();
            obj.Sorting();
            obj.Display();
            Console.ReadKey();
        }
    }

    class Sort
    {
        int no;
        int[] arraysale;
        public  void Read()
        {
            Console.WriteLine("Enter the number of months\n ");
            no = Convert.ToInt32(Console.ReadLine());
            arraysale = new int[no];            //array created--in constructor

            Console.WriteLine("Enter the sales amount of {0} months", no);
            for (int index = 0; index < no; index++)
            {
                try
                {
                    arraysale[index] = Convert.ToInt32(Console.ReadLine());  //sales array is initialised 

                }
                catch
                {
                    Console.WriteLine("Please enter valid integer");
                }
            }
        }
        public void Sorting()
        {
            for (int i = 0; i <= no - 1; i++)
            {
                for (int j = i + 1; j <= no - 1; j++)
                {
                    if (arraysale[i] > arraysale[j])
                    {
                        int temp = arraysale[i];
                        arraysale[i] = arraysale[j];
                        arraysale[j] = temp;
                    }
                }

            }
            Console.WriteLine("\nAfter SORTING : - ");
        }


        public void Display()
        {
            Console.WriteLine("The sorted sales amount for {0} month's --3" +
                " \n", no);

            foreach (int index in arraysale)
            {
                Console.WriteLine(index + " ");
            }
        }
    }
}
