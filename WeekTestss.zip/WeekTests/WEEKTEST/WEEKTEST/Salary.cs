﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WEEKTEST
{
    class Salary
    {
        

        public static void Main()
        {
        int option;
            Employee obj = new Employee();  //object creation
            int noofemployees=obj.ReadData();
            do
            {
                Console.WriteLine("******************************");
                Console.WriteLine("1-Read Data");
                Console.WriteLine("2-Display Data");
                Console.WriteLine("3-Display Particular Employee Data");
                Console.WriteLine("4-Exit");
                Console.WriteLine("******************************");
                option = Convert.ToInt32(Console.ReadLine());


                switch (option)
                {
                    case 1:
                        Console.WriteLine("Enter Salary of all employees\n");

                        for (int index = 0; index < noofemployees; index++)
                        {
                          
                            obj[index] = Convert.ToInt32(Console.ReadLine());     //indexer -- accessing with object 
                        }

                        Console.ReadKey();
                        break;
                    case 2:
                        
                        for (int index = 0; index < noofemployees; index++)
                        {
                            Console.WriteLine("\n Salary of employee {0} is {1} ", index + 1, obj[index]); //indexer 
                        }

                        Console.ReadKey();
                        break;
                    case 3:
                        Console.WriteLine("Enter the particular index number of employee \n");
                        int indexnumber = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("\n Salary of the employee with index number {0} is {1} ", indexnumber , obj[indexnumber-1]); //indexer

                        break;
                    case 4:
                        System.Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Enter a valid  number between 1 and 4");
                        break;


                }
            } while (true);
        }
    }
    public class Employee
    {
      public  int noofemployees;
        public int[] arraysalary;

        public int  ReadData()
        {
            Console.WriteLine("Enter number of employees \n");
            noofemployees = Convert.ToInt32(Console.ReadLine());
            arraysalary = new int[noofemployees];
            return noofemployees;
        }

        public int this[int index]             //indexer
        {
            get
            { return arraysalary[index]; }
            set
            { arraysalary[index] = value; }
        }


        

    }
                
                
                
                
}






    