﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace WEEKTEST
{
    class LockThread
    {
        public static void Main()
        {
            Output objectname = new Output();
            Thread threadname = new Thread(objectname.Display);
            threadname.Start();

            Thread threadname11 = new Thread(objectname.Display);
            threadname11.Start();
            Console.ReadKey();

        }
    }
    class Output
    {
        public void Display()
        { 
            for (int i = 0; i <= 10; i++)
            {

                Console.WriteLine(" " + i);
            }

        }
    }
}

