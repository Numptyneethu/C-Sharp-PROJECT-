﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WEEKTEST
{
    public delegate bool Ispromotabledelegate(Employee1 i);
    class EmployeeDelegate
    {
        public static void Main()
        {
            Ispromotabledelegate objdelegate = new Ispromotabledelegate(Ispromotable);  //stores the address of Ispromotable method
            
            List<Employee1> employeeslist = new List<Employee1>();
            employeeslist.Add(new Employee1 { ID = 1, Name = "abc", Experience = 4, Salary = 10000 });
            employeeslist.Add(new Employee1 { ID = 2, Name = "def", Experience = 6, Salary = 100000 });
            employeeslist.Add(new Employee1 { ID = 3, Name = "zyx", Experience = 10, Salary = 5000 });

            Console.WriteLine("List of Employee");
            Employee1.GetPromotedList(employeeslist,objdelegate);
            Console.ReadKey();
        }
        public static bool Ispromotable(Employee1 employee)
        {
            bool eligible = false;
            if (employee.Experience >= 4 && employee.Salary <= 20000)
            {
                eligible = true;
            }
            return eligible;
        }


    }
    public class Employee1
    {
        public int ID  //properties
        { get; set; }

        public string Name
        { get; set; }

        public int Experience
        { get; set; }

        public int Salary
        { get; set; }

        public static void GetPromotedList(List<Employee1> employeeslist, Ispromotabledelegate objdelgate)   //employeeslist - list name ; Employee-Class name
        {
            foreach (Employee1 i in employeeslist)
            {
                if (objdelgate(i))  //call back method
                {
                    Console.WriteLine("Emp ID   " + i.ID);
                    Console.WriteLine("Name   " + i.Name);
                    Console.WriteLine("Experience   " + i.Experience);
                    Console.WriteLine("Salary   " + i.Salary);
                }
            }
        }
        

    }
}

