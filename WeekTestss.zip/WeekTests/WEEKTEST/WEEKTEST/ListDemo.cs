﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace WEEKTEST
{
    class ListDemo
    {
        public static void Main()
        {
            List<string> names = new List<string>();  //list of stribgs
            names.Add("Ammu");
            names.Add("Annu");
            names.Add("Appu");
            names.Add("Achu");
            names.Add("Ansu");
            names.Add("Nami");
            names.Remove("NAmi");
            names.Insert(0, "Gokul");
            //names.RemoveRange(2, 3);
            //names.RemoveAt(0);
            //names.Reverse();
            //names.Sort();


            foreach (var name in names)
            {
                Console.WriteLine(name);
            }
            Console.ReadKey();
        }
        public static void HashtableDemo()
        {
            Hashtable objhashtable = new Hashtable();  //object
            objhashtable.Add("1", "Ammu");
            objhashtable.Add("2", "Annu");
            objhashtable.Add("3", "Appu");
            objhashtable.Add("4", "Achu");

            //foreach (var name in names)
            //{
            //    Console.WriteLine(name);
            //}
            //Console.ReadKey();
        }
       
     
        

    }
}
