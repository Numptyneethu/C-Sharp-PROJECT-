﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace WEEKTEST
{
    class ThreadDemo
    {
        public static void Main()
        {
            Table objTable = new Table(5,200);
            Thread threadname1 = new Thread(objTable.MultiplicationTable);

            Table objTable1 = new Table(10, 200);
            Thread threadname2 = new Thread(objTable1.MultiplicationTable);

            threadname1.Priority = ThreadPriority.Lowest;
            threadname2.Priority = ThreadPriority.Highest;

            threadname1.Start();
            threadname2.Start();

            //Table objTable2 = new Table(3);
            //Thread threadname2 = new Thread(objTable2.MultiplicationTable);
            //threadname2.Start();




            Console.ReadKey();

        }



    }

    class Table
    {
        private int _number;
        private int _sleep;
        public Table(int  variable,int sleep)
        {
             _number = variable;
            _sleep = sleep;
        }
        public void MultiplicationTable()
        {
            lock (this)
            {
                for (int index = 1; index <= 10; index++)
                {
                    Thread.Sleep(_sleep);
                    Console.WriteLine("{0}*{1}={2} ", index, _number, (index * _number));
                }
            }
        
           
        }

    }
}
