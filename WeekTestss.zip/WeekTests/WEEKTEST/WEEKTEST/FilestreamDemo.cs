﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WEEKTEST
{
    class FilestreamDemo
    {
    public static void Main()
        {
            FileStream datafile = new FileStream("D:\\NEETHU\\data.txt"  , FileMode.OpenOrCreate);   
            for (int j=65;j<=90;j++)
            {
                datafile.WriteByte((byte)j);
            }
            datafile.Close();
            Console.WriteLine("File is created ");

            Console.WriteLine("File read operation.....");
            FileStream outputfile = new FileStream("D:\\NEETHU\\data.txt", FileMode.OpenOrCreate);

            int i = 0;
            while ((i = outputfile.ReadByte()) != -1) //untill eof
            {
                Console.WriteLine((char)i);

            }
            outputfile.Close();
            Console.ReadKey();


        }

    }
}
