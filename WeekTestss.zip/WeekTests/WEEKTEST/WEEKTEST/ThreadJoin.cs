﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace WEEKTEST
{
    class ThreadJoin
    {
        public static void Main()
        {
            Thread thread1 = Thread.CurrentThread;
            thread1.Name = "Main Thread";
            Console.WriteLine("Main method name - " + thread1.Name);

            Thread subthread1 = new Thread(SubThreads.ChildThread1);
            Thread subthread2 = new Thread(SubThreads.ChildThread2);
            subthread1.Start();
            subthread2.Start();

            subthread2.Join();  //subthread2 will be execute untill it is completed..then output of 1st thread will be resumed 
            Console.WriteLine("Main method is completed");

            Console.ReadKey();


        }


    }
    class SubThreads
    {
        public static void ChildThread1()
        {
            Console.WriteLine("Inside CHild Thread 1");
            for (int i=0;i<=10;i++)
            {
                Console.WriteLine(" "+i);
                Thread.Sleep(300);

            }
            Console.WriteLine(" CHild Thread 1 is completed");
        }


        public static void ChildThread2()
        {
            
            
            Console.WriteLine("Inside CHild Thread 2");
            for (int i = 11; i <= 30; i++)
            {
                Console.WriteLine(" " + i);
               
            }
            Console.WriteLine(" CHild Thread 2 is completed");
        }

    }
}
