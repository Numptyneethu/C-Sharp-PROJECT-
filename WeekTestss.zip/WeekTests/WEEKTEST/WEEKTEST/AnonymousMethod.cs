﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WEEKTEST
{
    public delegate void Print(int value);

    class AnonymousMethod
    {
        public static void Main()
        {
            Print objprint = delegate (int val)
            {
                Console.WriteLine("Inside anonymous method value - {0}", val);
            };

            objprint(100);
            Console.ReadKey();
        }

    }
}
