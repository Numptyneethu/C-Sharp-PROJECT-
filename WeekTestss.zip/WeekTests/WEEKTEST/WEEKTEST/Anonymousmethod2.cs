﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace WEEKTEST
//{
//    public delegate void Printt(int value);

//    class AnonymousMethodd
//    {
//        public static void PrintHelperMethod(Printt printdel, int val)
//        {
//            val += 10;
//            printdel(val);
//        }
//        public static void Main()
//        {
//            PrintHelperMethod(delegate (int val)
//            Console.WriteLine("Inside anonymous method value - {0}", val);
//        },100);
       
//    }
    

//}

