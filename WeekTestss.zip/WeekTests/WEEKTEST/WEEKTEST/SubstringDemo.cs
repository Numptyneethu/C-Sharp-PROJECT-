﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WEEKTEST
{
    class SubstringDemo
    {
        //public string str;

        public static void Main()
        {
            Console.WriteLine("Enter your employee id ");
            string str = Console.ReadLine();

            SubstringDemo obj = new SubstringDemo(str);

            Console.ReadKey();
        }

        SubstringDemo(String str)
        {
            String prefix = str.Substring(0, 3);  //from index 0 to 3
          
            int number = Convert.ToInt32(str.Substring(3)); //avoids first 3
            number++;
          
            Console.WriteLine("Output - "+prefix + number);
        }
     
        
    }
}
