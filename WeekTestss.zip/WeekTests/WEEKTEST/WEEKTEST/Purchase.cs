﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ConsoleTestApp
{
    class ProductsCollectionClass
    {
        public static void Main()
        {
            //Item obj = new Item();
            Hashtable product = new Hashtable();
            product.Add(1, new Item(101, "Pista", 450));
            product.Add(2, new Item(102, "Nuts", 320));
            product.Add(3, new Item(103, "Soap", 50));
            product.Add(4, new Item(104, "Rice", 600));
            product.Add(5, new Item(105, "Ice Cream", 150));
            //foreach (var key in product.key)
            //    Console.WriteLine(product[key]);

            int option;
            do
            {
                Console.WriteLine("**********************");
                Console.WriteLine("1. Add Cart");
                Console.WriteLine("2. View Cart");
                Console.WriteLine("3. Checkout");
                Console.WriteLine("4. Exit");
                Console.WriteLine("**********************");
                Console.WriteLine("Enter the Option (1-4)");
                option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:

                        break;
                    case 2:

                        break;
                    case 3:

                        break;
                    case 4:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("\n!!!... Wrong option , Please enter 1-4.");
                        break;
                }
            } while (true);
            Console.ReadKey();
        }
    }
    public class Item
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int UnitPrice { get; set; }

        public Item(int id, string name, int price)
        {
            ID = id;
            Name = name;
            UnitPrice = price;
        }
        public void AddCart()
        {
            Console.WriteLine("Enter Product Key");
            int key = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Product Quantity");
            int quantity = Convert.ToInt32(Console.ReadLine());

        }
        public void ViewCart()
        {
            Console.WriteLine("\n       Product Details      ");
            Console.WriteLine("----------------------------");
            Console.WriteLine("Product ID : " + ID);
            Console.WriteLine("Product Name : " + Name);
            Console.WriteLine("Product Price : " + UnitPrice);
            Console.WriteLine("----------------------------");
        }
    }
}