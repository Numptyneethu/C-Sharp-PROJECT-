﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace WEEKTEST
//{
//    class Customer
//    {
//        public string name; int CustomerID;
//        public static void Main()
//        {
//            int noofcustomers;

//            Console.WriteLine("Enter the number of customers\n ");
//            noofcustomers = Convert.ToInt32(Console.ReadLine());
//            CustomerDetails[] array = new CustomerDetails[noofcustomers ];  //array of objects
//            Console.WriteLine("\n--------- Enter the Customer Details -----------");
//            for (int index = 0; index < noofcustomers; index++)
//            {
//                array[index] = new CustomerDetails();  //array of objects
//                array[index].ReadData();   //getting name,id
 
//            }
//            Console.WriteLine("\nDisplay Details");
//            for (int index = 0; index < noofcustomers; index++)
//            {

//                array[index].DisplayData();   //getting name,id

//            }




//        }


//    }
//    class CustomerDetails
//    {
//        public string name;
//        int CustomerID;

//        //enum Type { Reatail = 1, Wholesale = 2 };

//        public void ReadData()
//        {
//            Console.WriteLine("Enter your name\n");
//            name = Console.ReadLine();
//            Console.WriteLine("Enter your ID\n");
//            CustomerID = Convert.ToInt32(Console.ReadLine());
//        }

//        public void DisplayData()
//        {
//            Console.WriteLine("\nNAME - " + name);
//            Console.WriteLine("\nCUSTOMER ID  - " + CustomerID);
//            Console.WriteLine("\nUSERTYPE - Reatail = 1, Wholesale = 2");
//            //Console.WriteLine("USER TYPE" + Type);
//        }

//        public int SaleID
//        {
//            get { return productID; }
//            set { productID = value; }
//        }
//    }
//}
