﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileHandlingPrograms
{
    class MergeFiles
    {
        
        public static void Main()
        {

            string[] file1 = File.ReadAllLines("D:\\NEETHU\\trialmerge\\file1.txt");
            string[] file2 = File.ReadAllLines("D:\\NEETHU\\trialmerge\\file2.txt");

            using (StreamWriter writer = File.CreateText("D:\\NEETHU\\trialmerge\\file3.txt"))
            {
                int line = 0;
                while (line < file1.Length || line < file2.Length)
                {
                    if (line < file1.Length)
                        writer.WriteLine(file1[line]);
                    if (line < file2.Length)
                        writer.WriteLine(file2[line]);
                    line++;
                }
                Console.WriteLine("Merging Operations Completed.");
            }

            Console.ReadKey();
        }
    }
}