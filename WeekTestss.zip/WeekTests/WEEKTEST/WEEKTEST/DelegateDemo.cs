﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WEEKTEST
{
    public delegate void DelegateName(int value1,int value2);     //delegate declaration  //return type and parameter of delegate and method is same

    class DelegateDemo
    {
        public static void Main()
        {
            
            DelegateName objdelegate = new DelegateName(Calculator.Sum ); //delegate object 
            objdelegate += Calculator1.Difference;  //adding one more method address to the delegate object
            objdelegate -= Calculator.Sum;          //removing one method address from the delegate object

            objdelegate(10, 20);    //calls the first stored address -sum and then calls difference 
          
            Console.ReadKey();
        }


    }
    class Calculator
    {
        public static void Sum(int value1,int value2)              //return type and parameter of delegate and method is same
        {
            Console.WriteLine(value1+value2);
        }
    }
    class Calculator1
    {
        public static void Difference(int value1, int value2)              //return type and parameter of delegate and method is same
        {
            Console.WriteLine(value1 - value2);
        }
    }
}
