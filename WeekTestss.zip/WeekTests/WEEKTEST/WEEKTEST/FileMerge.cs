﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace WEEKTEST
{
    class FileMerge
    {
        public static void Main()
        {
            FileStream datafile = new FileStream("D:\\NEETHU\\merging\\File1.txt", FileMode.OpenOrCreate);
            for (int j = 65; j <= 70; j++)
            {
                datafile.WriteByte((byte)j);
            }
            datafile.Close();
            Console.WriteLine("File 1www is created ");

            Console.WriteLine("File 1www read operation.....");
            FileStream outputfile = new FileStream("D:\\NEETHU\\merging\\File1.txt", FileMode.OpenOrCreate);
           
            int i = 0;
            while ((i = outputfile.ReadByte()) != -1)  //untill eof
            {
                Console.WriteLine((char)i);

            }
            outputfile.Close();
            //////////////////////////////////////////////////
            FileStream datafile1 = new FileStream("D:\\NEETHU\\merging\\File2.txt", FileMode.OpenOrCreate);
            for (int m = 71; m <= 90; m++)
            {
                datafile1.WriteByte((byte)m);
            }
            datafile1.Close();
            Console.WriteLine("File 2 is created ");

            Console.WriteLine("File 2 read operation.....");
            FileStream outputfile1 = new FileStream("D:\\NEETHU\\merging\\File2.txt", FileMode.OpenOrCreate);

            int l = 0;
            while ((l= outputfile1.ReadByte()) != -1) //untill eof
            {
                Console.WriteLine((char)l);

            }
            outputfile1.Close();

           //void MergeFiles(string datafile, string datafile1, string datafile2)
           // {
           //     Console.WriteLine("Merging.....");
           //     File.WriteAllText(datafile2, (File.ReadAllText(datafile) + File.ReadAllText(datafile1)));
           // }



            Console.ReadKey();
        }

        
       

    }
}
