﻿namespace WeeklyTest4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tab2 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.combodepartment = new System.Windows.Forms.ComboBox();
            this.labelpersonal = new System.Windows.Forms.Label();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.buttonsubmit = new System.Windows.Forms.Button();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.buttonview = new System.Windows.Forms.Button();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.radiobuttonothers = new System.Windows.Forms.RadioButton();
            this.radiobuttonfemale = new System.Windows.Forms.RadioButton();
            this.radiobuttonmale = new System.Windows.Forms.RadioButton();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.textBoxmobilenumber = new System.Windows.Forms.TextBox();
            this.textBoxemail = new System.Windows.Forms.TextBox();
            this.textBoxid = new System.Windows.Forms.TextBox();
            this.textBoxname = new System.Windows.Forms.TextBox();
            this.hobbies = new System.Windows.Forms.Label();
            this.dob = new System.Windows.Forms.Label();
            this.gender = new System.Windows.Forms.Label();
            this.mobilenumber = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.department = new System.Windows.Forms.Label();
            this.empid = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.labeldisplay = new System.Windows.Forms.Label();
            this.textrate = new System.Windows.Forms.TextBox();
            this.textloantenure = new System.Windows.Forms.TextBox();
            this.textloanamount = new System.Windows.Forms.TextBox();
            this.textbasicsalary = new System.Windows.Forms.TextBox();
            this.buttoncalculate = new System.Windows.Forms.Button();
            this.labelrate = new System.Windows.Forms.Label();
            this.labeltenure = new System.Windows.Forms.Label();
            this.labelamount = new System.Windows.Forms.Label();
            this.labelbasicsalary = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelexception = new System.Windows.Forms.Label();
            this.labelresult = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tab2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tab2
            // 
            this.tab2.Controls.Add(this.tabPage1);
            this.tab2.Controls.Add(this.tabPage2);
            this.tab2.Location = new System.Drawing.Point(68, 50);
            this.tab2.Name = "tab2";
            this.tab2.SelectedIndex = 0;
            this.tab2.Size = new System.Drawing.Size(690, 557);
            this.tab2.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.combodepartment);
            this.tabPage1.Controls.Add(this.labelpersonal);
            this.tabPage1.Controls.Add(this.dateTimePicker);
            this.tabPage1.Controls.Add(this.checkBox4);
            this.tabPage1.Controls.Add(this.buttonsubmit);
            this.tabPage1.Controls.Add(this.checkBox3);
            this.tabPage1.Controls.Add(this.buttonview);
            this.tabPage1.Controls.Add(this.checkBox2);
            this.tabPage1.Controls.Add(this.radiobuttonothers);
            this.tabPage1.Controls.Add(this.radiobuttonfemale);
            this.tabPage1.Controls.Add(this.radiobuttonmale);
            this.tabPage1.Controls.Add(this.checkBox1);
            this.tabPage1.Controls.Add(this.textBoxmobilenumber);
            this.tabPage1.Controls.Add(this.textBoxemail);
            this.tabPage1.Controls.Add(this.textBoxid);
            this.tabPage1.Controls.Add(this.textBoxname);
            this.tabPage1.Controls.Add(this.hobbies);
            this.tabPage1.Controls.Add(this.dob);
            this.tabPage1.Controls.Add(this.gender);
            this.tabPage1.Controls.Add(this.mobilenumber);
            this.tabPage1.Controls.Add(this.email);
            this.tabPage1.Controls.Add(this.department);
            this.tabPage1.Controls.Add(this.empid);
            this.tabPage1.Controls.Add(this.name);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(682, 531);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            this.tabPage1.MouseHover += new System.EventHandler(this.tabPage1_MouseHover);
            // 
            // combodepartment
            // 
            this.combodepartment.FormattingEnabled = true;
            this.combodepartment.Location = new System.Drawing.Point(133, 112);
            this.combodepartment.Name = "combodepartment";
            this.combodepartment.Size = new System.Drawing.Size(380, 21);
            this.combodepartment.TabIndex = 23;
            this.combodepartment.SelectedIndexChanged += new System.EventHandler(this.comboBox_SelectedIndexChanged);
            this.combodepartment.MouseHover += new System.EventHandler(this.combodepartment_MouseHover);
            // 
            // labelpersonal
            // 
            this.labelpersonal.AutoSize = true;
            this.labelpersonal.Location = new System.Drawing.Point(16, 422);
            this.labelpersonal.Name = "labelpersonal";
            this.labelpersonal.Size = new System.Drawing.Size(109, 13);
            this.labelpersonal.TabIndex = 22;
            this.labelpersonal.Text = "_________________";
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker.Location = new System.Drawing.Point(133, 304);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(380, 25);
            this.dateTimePicker.TabIndex = 21;
            this.dateTimePicker.MouseHover += new System.EventHandler(this.dateTimePicker_MouseHover);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox4.Location = new System.Drawing.Point(482, 349);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(90, 24);
            this.checkBox4.TabIndex = 20;
            this.checkBox4.Text = "WRITTING";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // buttonsubmit
            // 
            this.buttonsubmit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.buttonsubmit.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonsubmit.ForeColor = System.Drawing.Color.White;
            this.buttonsubmit.Location = new System.Drawing.Point(553, 459);
            this.buttonsubmit.Name = "buttonsubmit";
            this.buttonsubmit.Size = new System.Drawing.Size(111, 36);
            this.buttonsubmit.TabIndex = 15;
            this.buttonsubmit.Text = "SUBMIT";
            this.buttonsubmit.UseVisualStyleBackColor = false;
            this.buttonsubmit.Click += new System.EventHandler(this.buttonsubmit_Click);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox3.Location = new System.Drawing.Point(361, 349);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(86, 24);
            this.checkBox3.TabIndex = 19;
            this.checkBox3.Text = "DANCING";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // buttonview
            // 
            this.buttonview.BackColor = System.Drawing.Color.Blue;
            this.buttonview.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonview.ForeColor = System.Drawing.Color.White;
            this.buttonview.Location = new System.Drawing.Point(402, 459);
            this.buttonview.Name = "buttonview";
            this.buttonview.Size = new System.Drawing.Size(111, 36);
            this.buttonview.TabIndex = 14;
            this.buttonview.Text = "VIEW";
            this.buttonview.UseVisualStyleBackColor = false;
            this.buttonview.Click += new System.EventHandler(this.buttonview_Click);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Location = new System.Drawing.Point(240, 349);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(86, 24);
            this.checkBox2.TabIndex = 18;
            this.checkBox2.Text = "READING";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // radiobuttonothers
            // 
            this.radiobuttonothers.AutoSize = true;
            this.radiobuttonothers.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiobuttonothers.Location = new System.Drawing.Point(361, 252);
            this.radiobuttonothers.Name = "radiobuttonothers";
            this.radiobuttonothers.Size = new System.Drawing.Size(66, 24);
            this.radiobuttonothers.TabIndex = 17;
            this.radiobuttonothers.TabStop = true;
            this.radiobuttonothers.Text = "Others";
            this.radiobuttonothers.UseVisualStyleBackColor = true;
            // 
            // radiobuttonfemale
            // 
            this.radiobuttonfemale.AutoSize = true;
            this.radiobuttonfemale.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiobuttonfemale.Location = new System.Drawing.Point(240, 254);
            this.radiobuttonfemale.Name = "radiobuttonfemale";
            this.radiobuttonfemale.Size = new System.Drawing.Size(70, 24);
            this.radiobuttonfemale.TabIndex = 16;
            this.radiobuttonfemale.TabStop = true;
            this.radiobuttonfemale.Text = "Female";
            this.radiobuttonfemale.UseVisualStyleBackColor = true;
            // 
            // radiobuttonmale
            // 
            this.radiobuttonmale.AutoSize = true;
            this.radiobuttonmale.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiobuttonmale.Location = new System.Drawing.Point(133, 252);
            this.radiobuttonmale.Name = "radiobuttonmale";
            this.radiobuttonmale.Size = new System.Drawing.Size(55, 24);
            this.radiobuttonmale.TabIndex = 15;
            this.radiobuttonmale.TabStop = true;
            this.radiobuttonmale.Text = "Male";
            this.radiobuttonmale.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(128, 353);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(80, 24);
            this.checkBox1.TabIndex = 14;
            this.checkBox1.Text = "SINGING";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // textBoxmobilenumber
            // 
            this.textBoxmobilenumber.Location = new System.Drawing.Point(133, 205);
            this.textBoxmobilenumber.Name = "textBoxmobilenumber";
            this.textBoxmobilenumber.Size = new System.Drawing.Size(380, 20);
            this.textBoxmobilenumber.TabIndex = 12;
            this.textBoxmobilenumber.TextChanged += new System.EventHandler(this.textBoxmobilenumber_TextChanged);
            this.textBoxmobilenumber.MouseHover += new System.EventHandler(this.textBoxmobilenumber_MouseHover);
            // 
            // textBoxemail
            // 
            this.textBoxemail.Location = new System.Drawing.Point(133, 162);
            this.textBoxemail.Name = "textBoxemail";
            this.textBoxemail.Size = new System.Drawing.Size(380, 20);
            this.textBoxemail.TabIndex = 11;
            this.textBoxemail.MouseHover += new System.EventHandler(this.textBoxemail_MouseHover);
            // 
            // textBoxid
            // 
            this.textBoxid.Location = new System.Drawing.Point(133, 63);
            this.textBoxid.Name = "textBoxid";
            this.textBoxid.Size = new System.Drawing.Size(380, 20);
            this.textBoxid.TabIndex = 9;
            this.textBoxid.MouseHover += new System.EventHandler(this.textBoxid_MouseHover);
            // 
            // textBoxname
            // 
            this.textBoxname.Location = new System.Drawing.Point(133, 19);
            this.textBoxname.Name = "textBoxname";
            this.textBoxname.Size = new System.Drawing.Size(380, 20);
            this.textBoxname.TabIndex = 8;
            this.textBoxname.TextChanged += new System.EventHandler(this.textBoxname_TextChanged);
            this.textBoxname.MouseHover += new System.EventHandler(this.textBoxname_MouseHover);
            // 
            // hobbies
            // 
            this.hobbies.AutoSize = true;
            this.hobbies.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hobbies.Location = new System.Drawing.Point(18, 356);
            this.hobbies.Name = "hobbies";
            this.hobbies.Size = new System.Drawing.Size(54, 18);
            this.hobbies.TabIndex = 7;
            this.hobbies.Text = "Hobbies";
            // 
            // dob
            // 
            this.dob.AutoSize = true;
            this.dob.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dob.Location = new System.Drawing.Point(18, 310);
            this.dob.Name = "dob";
            this.dob.Size = new System.Drawing.Size(39, 18);
            this.dob.TabIndex = 6;
            this.dob.Text = "DOB";
            // 
            // gender
            // 
            this.gender.AutoSize = true;
            this.gender.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gender.Location = new System.Drawing.Point(16, 258);
            this.gender.Name = "gender";
            this.gender.Size = new System.Drawing.Size(50, 18);
            this.gender.TabIndex = 5;
            this.gender.Text = "Gender";
            // 
            // mobilenumber
            // 
            this.mobilenumber.AutoSize = true;
            this.mobilenumber.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mobilenumber.Location = new System.Drawing.Point(16, 207);
            this.mobilenumber.Name = "mobilenumber";
            this.mobilenumber.Size = new System.Drawing.Size(99, 18);
            this.mobilenumber.TabIndex = 4;
            this.mobilenumber.Text = "Mobile Number";
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.Location = new System.Drawing.Point(18, 164);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(67, 18);
            this.email.TabIndex = 3;
            this.email.Text = "E mail ID";
            // 
            // department
            // 
            this.department.AutoSize = true;
            this.department.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.department.Location = new System.Drawing.Point(16, 112);
            this.department.Name = "department";
            this.department.Size = new System.Drawing.Size(76, 18);
            this.department.TabIndex = 2;
            this.department.Text = "Department";
            // 
            // empid
            // 
            this.empid.AutoSize = true;
            this.empid.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.empid.Location = new System.Drawing.Point(16, 63);
            this.empid.Name = "empid";
            this.empid.Size = new System.Drawing.Size(56, 18);
            this.empid.TabIndex = 1;
            this.empid.Text = "Emp ID";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(16, 19);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(41, 18);
            this.name.TabIndex = 0;
            this.name.Text = "Name";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.labeldisplay);
            this.tabPage2.Controls.Add(this.textrate);
            this.tabPage2.Controls.Add(this.textloantenure);
            this.tabPage2.Controls.Add(this.textloanamount);
            this.tabPage2.Controls.Add(this.textbasicsalary);
            this.tabPage2.Controls.Add(this.buttoncalculate);
            this.tabPage2.Controls.Add(this.labelrate);
            this.tabPage2.Controls.Add(this.labeltenure);
            this.tabPage2.Controls.Add(this.labelamount);
            this.tabPage2.Controls.Add(this.labelbasicsalary);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(682, 531);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 402);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "label3";
            // 
            // labeldisplay
            // 
            this.labeldisplay.AutoSize = true;
            this.labeldisplay.Location = new System.Drawing.Point(38, 350);
            this.labeldisplay.Name = "labeldisplay";
            this.labeldisplay.Size = new System.Drawing.Size(103, 13);
            this.labeldisplay.TabIndex = 9;
            this.labeldisplay.Text = "________________";
            this.labeldisplay.Click += new System.EventHandler(this.labeldisplay_Click);
            // 
            // textrate
            // 
            this.textrate.Location = new System.Drawing.Point(142, 275);
            this.textrate.Name = "textrate";
            this.textrate.Size = new System.Drawing.Size(266, 20);
            this.textrate.TabIndex = 8;
            // 
            // textloantenure
            // 
            this.textloantenure.Location = new System.Drawing.Point(142, 192);
            this.textloantenure.Name = "textloantenure";
            this.textloantenure.Size = new System.Drawing.Size(266, 20);
            this.textloantenure.TabIndex = 7;
            // 
            // textloanamount
            // 
            this.textloanamount.Location = new System.Drawing.Point(142, 113);
            this.textloanamount.Name = "textloanamount";
            this.textloanamount.Size = new System.Drawing.Size(266, 20);
            this.textloanamount.TabIndex = 6;
            // 
            // textbasicsalary
            // 
            this.textbasicsalary.Location = new System.Drawing.Point(142, 48);
            this.textbasicsalary.Name = "textbasicsalary";
            this.textbasicsalary.Size = new System.Drawing.Size(266, 20);
            this.textbasicsalary.TabIndex = 5;
            this.textbasicsalary.MouseHover += new System.EventHandler(this.textbasicsalary_MouseHover);
            // 
            // buttoncalculate
            // 
            this.buttoncalculate.BackColor = System.Drawing.Color.Green;
            this.buttoncalculate.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttoncalculate.ForeColor = System.Drawing.Color.White;
            this.buttoncalculate.Location = new System.Drawing.Point(466, 388);
            this.buttoncalculate.Name = "buttoncalculate";
            this.buttoncalculate.Size = new System.Drawing.Size(153, 55);
            this.buttoncalculate.TabIndex = 4;
            this.buttoncalculate.Text = "CALCULATE";
            this.buttoncalculate.UseVisualStyleBackColor = false;
            this.buttoncalculate.Click += new System.EventHandler(this.buttoncalculate_Click);
            // 
            // labelrate
            // 
            this.labelrate.AutoSize = true;
            this.labelrate.Location = new System.Drawing.Point(38, 282);
            this.labelrate.Name = "labelrate";
            this.labelrate.Size = new System.Drawing.Size(80, 13);
            this.labelrate.TabIndex = 3;
            this.labelrate.Text = "Rate of Interest";
            // 
            // labeltenure
            // 
            this.labeltenure.AutoSize = true;
            this.labeltenure.Location = new System.Drawing.Point(38, 199);
            this.labeltenure.Name = "labeltenure";
            this.labeltenure.Size = new System.Drawing.Size(68, 13);
            this.labeltenure.TabIndex = 2;
            this.labeltenure.Text = "Loan Tenure";
            // 
            // labelamount
            // 
            this.labelamount.AutoSize = true;
            this.labelamount.Location = new System.Drawing.Point(38, 120);
            this.labelamount.Name = "labelamount";
            this.labelamount.Size = new System.Drawing.Size(70, 13);
            this.labelamount.TabIndex = 1;
            this.labelamount.Text = "Loan Amount";
            // 
            // labelbasicsalary
            // 
            this.labelbasicsalary.AutoSize = true;
            this.labelbasicsalary.Location = new System.Drawing.Point(38, 51);
            this.labelbasicsalary.Name = "labelbasicsalary";
            this.labelbasicsalary.Size = new System.Drawing.Size(65, 13);
            this.labelbasicsalary.TabIndex = 0;
            this.labelbasicsalary.Text = "Basic Salary";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 24F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(306, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(213, 34);
            this.label1.TabIndex = 2;
            this.label1.Text = "Employee Data";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // labelexception
            // 
            this.labelexception.AutoSize = true;
            this.labelexception.Location = new System.Drawing.Point(521, 460);
            this.labelexception.Name = "labelexception";
            this.labelexception.Size = new System.Drawing.Size(0, 13);
            this.labelexception.TabIndex = 22;
            // 
            // labelresult
            // 
            this.labelresult.AutoSize = true;
            this.labelresult.Location = new System.Drawing.Point(325, 448);
            this.labelresult.Name = "labelresult";
            this.labelresult.Size = new System.Drawing.Size(0, 13);
            this.labelresult.TabIndex = 23;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 633);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(823, 22);
            this.statusStrip1.TabIndex = 24;
            this.statusStrip1.Text = "statusStrip1";
            this.statusStrip1.ItemAdded += new System.Windows.Forms.ToolStripItemEventHandler(this.statusStrip1_ItemAdded);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(59, 17);
            this.toolStripStatusLabel1.Text = "Textname";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(823, 655);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.labelresult);
            this.Controls.Add(this.labelexception);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tab2);
            this.ForeColor = System.Drawing.Color.Maroon;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tab2.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tab2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBoxname;
        private System.Windows.Forms.Label hobbies;
        private System.Windows.Forms.Label dob;
        private System.Windows.Forms.Label gender;
        private System.Windows.Forms.Label mobilenumber;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label department;
        private System.Windows.Forms.Label empid;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxmobilenumber;
        private System.Windows.Forms.TextBox textBoxemail;
        private System.Windows.Forms.TextBox textBoxid;
        private System.Windows.Forms.Button buttonview;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.RadioButton radiobuttonothers;
        private System.Windows.Forms.RadioButton radiobuttonfemale;
        private System.Windows.Forms.RadioButton radiobuttonmale;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.Button buttonsubmit;
        private System.Windows.Forms.Label labelexception;
        private System.Windows.Forms.Label labelresult;
        private System.Windows.Forms.TextBox textrate;
        private System.Windows.Forms.TextBox textloantenure;
        private System.Windows.Forms.TextBox textloanamount;
        private System.Windows.Forms.TextBox textbasicsalary;
        private System.Windows.Forms.Button buttoncalculate;
        private System.Windows.Forms.Label labelrate;
        private System.Windows.Forms.Label labeltenure;
        private System.Windows.Forms.Label labelamount;
        private System.Windows.Forms.Label labelbasicsalary;
        private System.Windows.Forms.Label labeldisplay;
        private System.Windows.Forms.Label labelpersonal;
        private System.Windows.Forms.ComboBox combodepartment;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    }
}

