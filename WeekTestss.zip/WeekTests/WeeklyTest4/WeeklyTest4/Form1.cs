﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WeeklyTest4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        int employeeid;
        string empmobileNo;
        string empname, empemail,  date_dob, employeedepartment;
        string empgender = "",emphobbies = "";
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttoncalculate_Click(object sender, EventArgs e)
        {
            double basicSalary, loanAmount, loanTenure, interestRate, grossPay, emi, da;

            if (textbasicsalary.Text == String.Empty)
            {
                labeldisplay.Text = "Basic salary should be filled";
            }
            else if (textloanamount.Text == String.Empty)
            {
                labeldisplay.Text = "Loan amount should be filled";
            }
            else if (textloantenure.Text == String.Empty)
            {
                labeldisplay.Text = "Loan tenure should be filled";
            }
            else if (textrate.Text == String.Empty)
            {
                labeldisplay.Text = "Rate of Interest should be filled";
            }
            else

                try
                {
              
                basicSalary = Convert.ToInt64(textbasicsalary.Text);
                loanAmount = Convert.ToInt64(textloanamount.Text);
                loanTenure = Convert.ToInt64(textloantenure.Text);
                interestRate = Convert.ToInt64(textrate.Text);

                da = basicSalary * 0.3;
               grossPay = basicSalary + da;
                    emi = Math.Pow(loanAmount * interestRate * (1 * interestRate), loanTenure) / Math.Pow((1 + interestRate), loanTenure);
                    String titlename = " Salary Details";
                    MessageBox.Show("Basic Salary\t: " + basicSalary + "\nLoan Amount\t: " + loanAmount + "\nLoan Tenure\t: " + loanTenure + "\nRate Of Interest\t: " + interestRate + "\nD A\t\t: " + da + "\nGross Pay\t\t: " + grossPay + "\nEMI\t\t: " + emi, titlename);
                
                
            }
            catch(Exception e2)
            {
                labeldisplay.Text = e2.Message.ToString();
            }
            
            
           

        }

        private void labeldisplay_Click(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBoxname_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = " Enter name";
        }

        private void textbasicsalary_MouseHover(object sender, EventArgs e)
        {
           
        }

        private void textBoxemail_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Enter email Id";
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
           // toolStripStatusLabel1.Text = " ";
            //Textname.Text = " ";
        }

        private void statusStrip1_ItemAdded(object sender, ToolStripItemEventArgs e)
        {

        }

        private void textBoxmobilenumber_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Enter mobile number ";
        }

        private void tabPage1_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = " ";
        }

        private void textBoxid_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Enter Employement ID";
        }

        private void combodepartment_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Enter Department";
        }

        private void dateTimePicker_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Enter Date of Birth";
        }

        private void textBoxmobilenumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tabPage1.Text = "Personal Details";
            tabPage2.Text = "Salary Details";
            combodepartment.Items.Add("Engineer");
            combodepartment.Items.Add("Trainee");
            combodepartment.Items.Add("Intern");
            combodepartment.Items.Add("HR");
            combodepartment.Items.Add("Staff");
            combodepartment.Items.Add("Security");

           
        }

        private void buttonsubmit_Click(object sender, EventArgs e)
        {
            if(textBoxname.Text == String.Empty|| textBoxid.Text == String.Empty|| textBoxemail.Text == String.Empty|| textBoxmobilenumber.Text == String.Empty|| combodepartment.SelectedIndex==-1)
            {
                labelpersonal.Text = "All fields are mandatory";
            }
            
            

                if (textBoxname.Text == String.Empty)
                {
                    labelpersonal.Text = "Name tab should be filled";
                }
                else if (textBoxid.Text == String.Empty)
                {
                    labelpersonal.Text = "Employee ID should be filled";
                }
                else if (textBoxemail.Text == String.Empty)
                {
                    labelpersonal.Text = "Employee mail id  should be filled";
                }
                else if (textBoxmobilenumber.Text == String.Empty)
                {
                    labelpersonal.Text = "Employee mobile number  should be filled";
                }
                else if (    textBoxmobilenumber.Text.Length != 10)
                {
                    labelpersonal.Text = "Employee mobile number  should be a 10 digit number";
                }
                else if (!radiobuttonothers.Checked && !radiobuttonfemale.Checked && !radiobuttonmale.Checked)
                {
                labelpersonal.Text = "Enter you genderr";
                }

            else
                {
                    try
                    {
                        employeeid = Convert.ToInt32(textBoxid.Text);
                        empname = textBoxname.Text;
                        empemail = textBoxemail.Text;
                        empmobileNo = textBoxmobilenumber.Text;
                        date_dob = dateTimePicker.Value.ToString("yyyy-MM-dd");
                        employeedepartment = combodepartment.Text;
                        if (checkBox1.Checked)
                        {
                            emphobbies += checkBox1.Text;
                        }
                        if (checkBox2.Checked)
                        {
                            emphobbies += " & " + checkBox2.Text;
                        }
                        if (checkBox3.Checked)
                        {
                            emphobbies += " & " + checkBox3.Text;
                        }
                        if (checkBox4.Checked)
                        {
                            emphobbies += " & " + checkBox4.Text;
                        }


                        if (radiobuttonfemale.Checked)
                        {
                            empgender = radiobuttonfemale.Text;
                        }
                        else if (radiobuttonmale.Checked)
                        {
                            empgender = radiobuttonmale.Text;
                        }
                        else
                        {
                            empgender = radiobuttonothers.Text;
                        }

                        labelpersonal.Text = "Personal Data saved successfully :)";

                    }
                    catch (Exception e1)
                    {

                    labelpersonal.Text = "Employee ID should be a number";   /*e1.Message.ToString();*/

                    }
                }
            

            
            
        }

        private void textBoxname_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonview_Click(object sender, EventArgs e)
        {
            if (textBoxname.Text == String.Empty || textBoxid.Text == String.Empty || textBoxemail.Text == String.Empty || textBoxmobilenumber.Text == String.Empty|| combodepartment.SelectedIndex == -1)
            {
                labelpersonal.Text = "Enter all data and submit for preview";
            }
            else
            {
                String titlename2 = " Personal Details";
                MessageBox.Show("Employee ID\t: " + employeeid + "\nName\t\t: " + empname + "\nEmail\t\t: " + empemail + "\nMobile No.\t: " + empmobileNo + "\nHobbies\t\t: " + emphobbies + "\nGender\t\t: " + empgender + "\nDate Of Birth\t: " + date_dob + "\nDepartment\t: " + employeedepartment, titlename2);
            }
            
        }
    }
}
