﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace WeekTest3
{
    class TableThread
    {
        public static void Main()
        {
            GenerateTable Table1 = new GenerateTable(5, 500);
            Thread Thread1 = new Thread(new ThreadStart(Table1.ReadData));
            GenerateTable Table2 = new GenerateTable(10, 100);
            Thread Thread2 = new Thread(new ThreadStart(Table2.ReadData));
            GenerateTable Table3 = new GenerateTable(15, 500);
            Thread Thread3 = new Thread(new ThreadStart(Table3.ReadData));

            Thread1.Start();
            Thread2.Start();
            Thread3.Start();

            Console.ReadKey();
        }
    }

    class Table
    {
        public void CreatTable(int n)
        {
            lock (this)
            {
                for (int iteration = 1; iteration <= 10; iteration++)
                {
                    Console.WriteLine("{0} * {1} ={2}", iteration, n, (iteration * n));
                }
            }
        }
    }

    class GenerateTable
    {
        Table table;
        int number;
        private int _sleep;

        public GenerateTable(int target, int sleep)
        {
            number = target;
            _sleep = sleep;
        }

        public void ReadData()
        {
            table = new Table();
            table.CreatTable(number);
        }

    }
}