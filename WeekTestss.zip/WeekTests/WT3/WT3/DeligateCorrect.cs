﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeekTest3
{
    public delegate bool IsPromotableStudent(Student student);
    class DelegateStudent
    {

        public static void Main()
        {
            List<Student> studentList = new List<Student>();


            studentList.Add(new Student { ID = 501, Name = "Sindhu", Mark1 = 40, Mark2 = 40, });
            studentList.Add(new Student { ID = 502, Name = "Raheena", Mark1 = 50, Mark2 = 50 });
            studentList.Add(new Student { ID = 503, Name = "Aiswarya", Mark1 = 60, Mark2 = 60 });
            studentList.Add(new Student { ID = 504, Name = "Athul", Mark1 = 30, Mark2 = 30 });
            studentList.Add(new Student { ID = 505, Name = "Celin", Mark1 = 40, Mark2 = 40 });
            studentList.Add(new Student { ID = 506, Name = "Swetha", Mark1 = 70, Mark2 = 70 });
            studentList.Add(new Student { ID = 507, Name = "Mohith", Mark1 = 30, Mark2 = 30 });
            studentList.Add(new Student { ID = 508, Name = "Arun", Mark1 = 40, Mark2 = 40 });
            studentList.Add(new Student { ID = 509, Name = "Jesna", Mark1 = 20, Mark2 = 20 });





            Console.WriteLine("List of Students Promoted");
            Console.WriteLine("***********************************");


            IsPromotableStudent objdelegate = new IsPromotableStudent(IsPromotable);
            Student.GetPromotedList(studentList, objdelegate);

            Console.ReadLine();

        }
        public static bool IsPromotable(Student students)
        {
            bool eligible = false;
            students.Total = (students.Mark1 + students.Mark2) / 2;

            try
            {
                if (students.Mark1 > 100 || students.Mark2 > 100)
                {
                    students.Total = (students.Mark1 + students.Mark2) / 2;
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("Please Check the mark you entered in the List");
            }

            if (students.Total >= 40)
            {
                eligible = true;
            }
            return eligible;
        }

    }
    public class Student
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public int Mark1 { get; set; }
        public int Mark2 { get; set; }


        public int Total { get; set; }


        public static void GetPromotedList(List<Student> students, IsPromotableStudent isPromotableDelegate)
        {
            foreach (Student student in students)
            {
                if (isPromotableDelegate(student))
                {
                    Console.WriteLine("Student Id {0}", student.ID);
                    Console.WriteLine("Name {0}", student.Name);
                    Console.WriteLine("Mark1 {0}", student.Mark1);
                    Console.WriteLine("Mark2 {0}", student.Mark2);
                    Console.WriteLine("Average Mark {0}", (student.Mark1 + student.Mark2) / 2);


                    Console.WriteLine("***********************************");
                }


            }
        }
    }
}