﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections;

namespace WeekTest3
{
    class AddressBook
    {
        public static void Main()
        {

            Hashtable details = new Hashtable();
            details.Add(1, new AddressDetails(101, "Sindhu", "Enakulam"));
            details.Add(2, new AddressDetails(102, "Celin ", "Thrissur"));
            details.Add(3, new AddressDetails(103, "Kavya ", "Kollam  "));
            details.Add(4, new AddressDetails(104, "Mohith", "Palakad "));
            details.Add(5, new AddressDetails(105, "Athul ", "Wayand  "));


            AddressDetails objaddress = new AddressDetails();
            FileStream addressbookfile = new FileStream("C:\\Users\\1028283\\Desktop\\data\\addressbook1.txt", FileMode.OpenOrCreate);

            foreach (DictionaryEntry item in details)
            {
                BinaryFormatter formatter = new BinaryFormatter();

                formatter.Serialize(addressbookfile, details);
            }


            addressbookfile.Close();

            AddressDetails addressDetail;
            int option;
            do
            {
                Console.WriteLine("******************************************************************");

                Console.WriteLine("1.To Search a Contact");
                Console.WriteLine("2.Delete Conatct");
                Console.WriteLine("3.View Contact");
                Console.WriteLine("4.EXIT");
                Console.WriteLine("******************************************************************");
                Console.WriteLine("Enter the option from (1-4?)");
                Console.WriteLine("******************************************************************");

                option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        string name;
                        Console.WriteLine("Enter the Name to be searched");
                        name = Console.ReadLine();


                        foreach (var line in File.ReadAllLines("C:\\Users\\1028283\\Desktop\\data\\addressbook.txt"))
                        {
                            if (line.Contains(name))
                            {
                                Console.WriteLine("The contact is present");
                            }
                            else
                            {
                                Console.WriteLine("The conatct is not present");
                            }

                        }

                        break;


                    case 2:
                        string name1;
                        Console.WriteLine("Enter the Name to be deleted");
                        name1 = Console.ReadLine();

                        if (details.ContainsValue(name1))
                        {
                            details.Remove(name1);
                            Console.WriteLine("The conatct is deleted");
                        }
                        else
                        {
                            Console.WriteLine("The conatct is not present");
                        }

                        break;

                    case 3:
                        ICollection keys = details.Keys;
                        Console.WriteLine("ID       | Name      | Address");
                        Console.WriteLine("____________________________________");
                        foreach (int key in keys)
                        {
                            addressDetail = ((AddressDetails)details[key]);
                            Console.WriteLine("{0}      |{1}     |{2}", addressDetail.ID, addressDetail.Name, addressDetail.Address);
                        }
                        //FileStream detailsOutfile = new FileStream("C:\\Users\\1028283\\Desktop\\data\\addressbook.txt", FileMode.OpenOrCreate);
                        //int i = 0;
                        //while ((i = detailsOutfile.ReadByte()) != -1)
                        //{
                        //    Console.Write((char)i);
                        //}
                        //detailsOutfile.Close();
                        FileStream stream = new FileStream("C:\\Users\\1028283\\Desktop\\data\\addressbook.txt", FileMode.OpenOrCreate);
                        BinaryFormatter formatter1 = new BinaryFormatter();

                        AddressDetails address = (AddressDetails)formatter1.Deserialize(stream);
                        address.Display();

                        stream.Close();
                        break;


                    case 4:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid Option");
                        break;
                }


            } while (true);

        }
    }

    [Serializable]
    class AddressDetails
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public string Address { get; set; }

        public AddressDetails()
        {

        }

        public AddressDetails(int id, string name, string address)
        {
            ID = id;
            Name = name;
            Address = address;
        }

        public void Display()
        {
            Console.WriteLine("ID :" + ID);
            Console.WriteLine("Name :" + Name);
            Console.WriteLine("Address :" + Address);
        }




    }

}