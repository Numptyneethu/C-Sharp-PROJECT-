﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace WeekTest3
{
    class AddressBook1
    {
        public string name;
        public string place;
        public long phone;

        Hashtable addressBook = new Hashtable();


        public static void Main()
        {
            int option;

            AddressBook1 addressBookObj = new AddressBook1();

            do
            {
                Console.WriteLine("\n***** Welcome to Address Book ******\n");
                Console.WriteLine("\n\t Menu\n");
                Console.WriteLine("\n\t 1 => Add a Contact\n\t 2 => Search a Contact \n\t 3 => Delete a Contact \n\t 4 => View All Contacts\n\t 5 => Exit \n");

                try
                {
                    Console.Write("Enter an Option : ");

                    option = Convert.ToInt32(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Please Enter a Correct Integer");
                    continue;
                }


                switch (option)
                {
                    case 1:
                        addressBookObj.AddContact();
                        break;
                    case 2:
                        addressBookObj.SearchContact();
                        break;
                    case 3:
                        addressBookObj.DeleteContact();
                        break;
                    case 4:
                        addressBookObj.ViewContacts();
                        break;
                    case 5:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("\nInvalid Option Selected! Please Try Again.\n");
                        break;

                }

            } while (true);

            Console.ReadKey();

        }

        public void ViewContacts()      // Method to view Contacts
        {
            Contact contact;

            FileStream stream = new FileStream(@"C:\\Users\\1028260\\Desktop\\AJMAL\\ABCD\\data6.txt", FileMode.OpenOrCreate);
            // FileStream stream = new FileStream(@"C:\Users\1028259\Desktop\NAJEEM\Module_Test3\MyFiles\account.txt", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();

            if (addressBook != null && stream.Length != 0)
            {
                addressBook = (Hashtable)formatter.Deserialize(stream);
                ICollection key = addressBook.Keys;
                foreach (string k in key)
                {
                    contact = ((Contact)addressBook[k]);
                    Console.WriteLine("***********************************");
                    Console.WriteLine("NAME : " + contact.NAME);
                    Console.WriteLine("PLACE : " + contact.PLACE);
                    Console.WriteLine("PHONE : " + contact.PHONE);
                    Console.WriteLine("***********************************");

                }

            }
            else
            {
                Console.WriteLine("\nNo Contacts Available in the Address Book!");
            }
            stream.Close();
        }

        public void DeleteContact()         // Method to Delete a Contact
        {
            Console.Write("Enter a name to delete the contact : ");
            String keyName = Console.ReadLine();

            FileStream stream = new FileStream(@"C:\\Users\\1028260\\Desktop\\AJMAL\\ABCD\\data6.txt", FileMode.OpenOrCreate);
            //FileStream stream = new FileStream(@"C:\Users\1028259\Desktop\NAJEEM\Module_Test3\MyFiles\account.txt", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();

            if (stream.Length != 0)
            {
                addressBook = (Hashtable)formatter.Deserialize(stream);
                stream.Close();



                if (addressBook.ContainsKey(keyName))
                {
                    addressBook.Remove(keyName);

                    //FileStream stream = new FileStream(@"C:\\Users\\1028260\\Desktop\\AJMAL\\ABCD\\data6.txt", FileMode.OpenOrCreate);
                    FileStream stream2 = new FileStream(@"C:\Users\1028259\Desktop\NAJEEM\Module_Test3\MyFiles\account.txt", FileMode.OpenOrCreate);
                    BinaryFormatter formatter2 = new BinaryFormatter();
                    formatter2.Serialize(stream2, addressBook);
                    Console.WriteLine("Contact Deleted Successfully!");
                    stream2.Close();

                }
                else
                {
                    Console.WriteLine("No Contacts Found!");
                }

            }
            else
            {
                Console.WriteLine("No Contacts Found!");
            }



        }

        public void SearchContact()         // Method to search a contact
        {

            Console.Write("Enter a name to search : ");
            String keyName = Console.ReadLine();

            FileStream stream = new FileStream(@"C:\\Users\\1028283\\Desktop\\data\\data6.txt", FileMode.OpenOrCreate);
            //FileStream stream = new FileStream(@"C:\Users\1028259\Desktop\NAJEEM\Module_Test3\MyFiles\account.txt", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();

            if (stream.Length != 0)
            {
                addressBook = (Hashtable)formatter.Deserialize(stream);


                Contact contact;
                if (addressBook.ContainsKey(keyName))
                {

                    contact = ((Contact)addressBook[keyName]);
                    Console.WriteLine("NAME : " + contact.NAME);
                    Console.WriteLine("PLACE : " + contact.PLACE);
                    Console.WriteLine("PHONE : " + contact.PHONE);


                }
                else
                {
                    Console.WriteLine("No Contacts Found!");
                }
            }
            else
            {
                Console.WriteLine("\nNo Contacts Available in the Address Book!");
            }

            stream.Close();



        }

        public void AddContact()            // Method to add a contact
        {
            try
            {
                Console.Write("Enter Name :");
                name = Console.ReadLine();
                Console.Write("Enter Place :");
                place = Console.ReadLine();
                Console.Write("Enter Phone :");
                phone = Convert.ToInt64(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Please Enter The Details in Correct Format!");
            }

            FileStream stream = new FileStream(@"C:\\Users\\1028283\\Desktop\\data\\data6.txt", FileMode.OpenOrCreate);
            //FileStream stream = new FileStream(@"C:\Users\1028259\Desktop\NAJEEM\Module_Test3\MyFiles\account.txt", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();



            if (!addressBook.ContainsKey(name))
            {
                Contact contact1 = new Contact { NAME = name, PLACE = place, PHONE = phone };
                addressBook.Add(name, contact1);
                formatter.Serialize(stream, addressBook);
                Console.WriteLine("\nUser Added Successfully!");
            }
            else
            {
                Console.WriteLine("\nUser Already Exists!");
            }
            stream.Close();


        }

    }

    [Serializable]
    class Contact
    {
        public string NAME { get; set; }
        public string PLACE { get; set; }
        public long PHONE { get; set; }

    }
}