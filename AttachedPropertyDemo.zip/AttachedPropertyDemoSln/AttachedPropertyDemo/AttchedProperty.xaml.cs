﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AttachedPropertyDemo
{
    /// <summary>
    /// Interaction logic for AttchedProperty.xaml
    /// </summary>
    public partial class AttchedProperty : Window
    {
        public AttchedProperty()
        {
            InitializeComponent();
        }
        



        public static string GetNewName(DependencyObject obj) //propa tab
        {
            return (string)obj.GetValue(NewNameProperty);
        }

        public static void SetNewName(DependencyObject obj, string value)
        {
            obj.SetValue(NewNameProperty, value);
        }

        // Using a DependencyProperty as the backing store for NewName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty NewNameProperty =
            DependencyProperty.RegisterAttached("NewName", typeof(string), typeof(AttchedProperty), new PropertyMetadata(0));

        private void UIEelement_Click(object sender, RoutedEventArgs e)
        {
        UIElement uiElement = (UIElement)sender;
            MessageBox.Show("Title of your cotrol is  " + GetNewName(uiElement), "AttachedProperty");

        }

        private void ListBox_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }
    }
}
