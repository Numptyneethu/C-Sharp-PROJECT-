﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MDI
{
    public partial class Notepad : Form
    {
        public Notepad()
        {
            InitializeComponent();

        }
        private void rtbNotepad_TextChanged(object sender, EventArgs e)
        {
        }
        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            New newobj = new New();
            newobj.Show();
            //newobj.MdiParent = this;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
      

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog dlgFont = new FontDialog();
            dlgFont.ShowDialog();
            if (dlgFont.ShowDialog() == DialogResult.OK)
            {
                string fontName;
                float fontSize;
                FontStyle style = dlgFont.Font.Style;
                FontFamily family = dlgFont.Font.FontFamily;
                fontName = dlgFont.Font.Name;
                fontSize = dlgFont.Font.Size;
                rtbNotepad.Font = new Font(family, fontSize, style);
            }
        }

        private void colorToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void foreGroundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.ShowDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                labelwelcome.ForeColor = dlg.Color;
            }
        }
        
        private void Notepad_Load(object sender, EventArgs e)
        {

        }
    }
}
