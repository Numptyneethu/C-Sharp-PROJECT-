﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDatabase.DTO
{
    class DTOClass
    {

        private String id;
        public String ID
        {
            get { return id; }
            set { id = value; }
        }


        private String name;
        public String NAME
        {
            get { return name; }
            set { name = value; }
        }


        
    }
}
