﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeDatabase.DTO;
using EmployeeDatabase.BL;

namespace EmployeeDatabase.Employee
{
    public partial class PresentationLayer : Form
    {
        public PresentationLayer()
        {
            InitializeComponent();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            DTOClass obj = new DTOClass();
            int output = 0;
            obj.ID = textBox1.Text;
            obj.NAME = textBox2.Text;
            output = employeeBL.employeeINSERTBL(obj);
            if(output>0)
            {
                MessageBox.Show("Success - Value is inserted");
            }

        }

        private void buttonview_Click(object sender, EventArgs e)
        {
            string id, name = null;
            DTOClass objview = null;

            try
            {
                objview = employeeBL.ViewEmployeeBL(viewBox.Text);//passing the input value
                if (objview != null)
                {

                    id = objview.ID;
                    name = objview.NAME;
                    MessageBox.Show(" " + id + "  " + name);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(" Error in PresentationLayer");
            }


        }
    }
}
