﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using EmployeeDatabase.DTO;
using System.Data;

namespace EmployeeDatabase.DAO
{
    class DAOClass
    {
        public static int employeeINSERTDAO(DTOClass dtoobject)
        {
            int output = 0;
            string sql = null;
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = " insert into NewTable(Id,name) VALUES (";
                sql = sql + "'" + dtoobject.ID + "',";
                sql = sql + "'" + dtoobject.NAME + "')";
                ////////////
                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs " + e3.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }








        public static DTOClass ViewEmployeeDAO(string studentid)
        {
            DTOClass objDto = null;
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet datasetObj = null;

            try
            {
                sql = "select * from NewTable where Id = '" + studentid + "'";
                con = DBHelper.GetConnection();
                con.Open();
                datasetObj = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(datasetObj);
                Object[] Data = null;



                if (datasetObj.Tables[0].Rows.Count > 0)
                {
                    Data = datasetObj.Tables[0].Rows[0].ItemArray;
                    objDto = new DTOClass();
                    objDto.ID = Data[0].ToString();
                    objDto.NAME = Data[1].ToString();
                    
                }


            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs :ViewEmployeeDAO " + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return objDto;
        }






    }
}
