﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeDatabase.DAO;
using EmployeeDatabase.DTO;


namespace EmployeeDatabase.BL
{
    class employeeBL
    {
        public static int employeeINSERTBL(DTOClass dtoobject)
        {
            int output = 0;

            try
            {
                output=DAOClass.employeeINSERTDAO(dtoobject);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs " + e3.Message.ToString());
            }
            return output;
        }

        public static DTOClass ViewEmployeeBL(string studentid)
        {
            DTOClass objBl = null;

            try
            {
                objBl = DAOClass.ViewEmployeeDAO(studentid);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_bl.cs " + e3.Message.ToString());
            }

            return objBl;
        }

    }

}

