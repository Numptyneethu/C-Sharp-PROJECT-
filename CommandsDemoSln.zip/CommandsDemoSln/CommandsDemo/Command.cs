﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace CommandsDemo
{
    public class Command : ICommand //bulb of icommand->implement interface
    {  //over ride all the methods 
        Action<object> executeMethod;
        Func<object, bool> canExecuteMethod;

        public Command(Action<object> executeMethod,Func<object,bool> canExecuteMethod)
        {
            this.executeMethod = executeMethod;
            this.canExecuteMethod = canExecuteMethod;
        }

       

        public bool CanExecute(object parameter)
        {
            return true;
            //throw new NotImplementedException();
          
        }

        public void Execute(object parameter)
        {
            executeMethod(parameter);
            //throw new NotImplementedException();
        }
        public event EventHandler CanExecuteChanged;
    }
}
