﻿using System;
using System.Collections.Generic;
using System.Text;


namespace PocketMoney_DTO.DTO
{
   public  class PocketMoneyDTO
    {
        private String type, date;
        private String  description;
        private double amount;
        private int slNo;


        public int SlNo
        {
            get { return slNo; }
            set { slNo = value; }
        }
        public String DESCRIPTION
        {
            get { return description; }
            set { description = value; }
        }
        public String DATE
        {
            get { return date; }
            set { date = value; }
        }
        public String TYPE
        {
            get { return type; }
            set { type = value; }
        }
        public double AMOUNT
        {
            get { return amount; }
            set { amount = value; }
        }
       
    }
}
