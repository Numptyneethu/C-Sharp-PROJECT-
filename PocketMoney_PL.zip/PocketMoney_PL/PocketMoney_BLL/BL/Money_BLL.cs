﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using PocketMoney_DTO.DTO;
using System.Data;
using PocketMoney_DSL.DSL;
using System.Data.SqlClient;


namespace PocketMoney_BLL.BL
{
   public  class Money_BLL
    {
        public static int INSERTBL( PocketMoneyDTO dtoobj1)
        {
            int output = 0;
            try
            {
               output = Money_DSL.INSERTDSL(dtoobj1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : AddressBL : INSERTBL() " + ex.Message.ToString());
            }

            return output;
        }


        public static int DELETEBL(string textslno)
        {
            int output = 0;
            try
            {
                output = Money_DSL.DELETEDSL(textslno);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine(" Error : AddressBL : DELETEBL() " + ex.Message.ToString());
            }
            return output;
        }
        public static DataSet GetContact()
        {

            DataSet dsStudent = null;
            try
            {
                dsStudent = Money_DSL.GetContact();


            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("Error :AddressBL :GetContact" + ex.Message.ToString());
            }

            return dsStudent;
        }
        public static int Update(PocketMoneyDTO obj)
        {
            int output = 0;

            try
            {
                output = Money_DSL.Update(obj);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("Error: AddressBL: AddressUpdate" + ex.Message.ToString());
            }

            return output;
        }


        public static DataSet GetContactLike(string likeName)
        {
            DataSet dsSTudents = null;
            try
            {
                dsSTudents = Money_DSL.GetContactLike(likeName);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : Stdent_mark_Bl.cs:GetStudentsLike() " + e3.Message.ToString());
            }
            return dsSTudents;
        }
    }
}
