﻿namespace PocketMoney_PL
{
    partial class PocketMoneyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PocketMoneyForm));
            this.labelslno = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labeldelete = new System.Windows.Forms.Label();
            this.labelerror = new System.Windows.Forms.Label();
            this.radioButtondebit = new System.Windows.Forms.RadioButton();
            this.labelamount = new System.Windows.Forms.Label();
            this.labeltype = new System.Windows.Forms.Label();
            this.labeldescription = new System.Windows.Forms.Label();
            this.labeldate = new System.Windows.Forms.Label();
            this.radioButtoncredit = new System.Windows.Forms.RadioButton();
            this.combodescription = new System.Windows.Forms.ComboBox();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.textamount = new System.Windows.Forms.TextBox();
            this.textslno = new System.Windows.Forms.TextBox();
            this.labelmain = new System.Windows.Forms.Label();
            this.buttonsave = new System.Windows.Forms.Button();
            this.buttonupdate = new System.Windows.Forms.Button();
            this.buttondelete = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelsearch = new System.Windows.Forms.Label();
            this.textsearch = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelslno
            // 
            this.labelslno.AutoSize = true;
            this.labelslno.BackColor = System.Drawing.Color.White;
            this.labelslno.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelslno.ForeColor = System.Drawing.Color.Navy;
            this.labelslno.Location = new System.Drawing.Point(30, 34);
            this.labelslno.Name = "labelslno";
            this.labelslno.Size = new System.Drawing.Size(43, 18);
            this.labelslno.TabIndex = 0;
            this.labelslno.Text = "Sl.No";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.statusStrip1);
            this.panel1.Controls.Add(this.labeldelete);
            this.panel1.Controls.Add(this.labelerror);
            this.panel1.Controls.Add(this.radioButtondebit);
            this.panel1.Controls.Add(this.labelamount);
            this.panel1.Controls.Add(this.labeltype);
            this.panel1.Controls.Add(this.labeldescription);
            this.panel1.Controls.Add(this.labeldate);
            this.panel1.Controls.Add(this.radioButtoncredit);
            this.panel1.Controls.Add(this.combodescription);
            this.panel1.Controls.Add(this.dateTimePicker);
            this.panel1.Controls.Add(this.textamount);
            this.panel1.Controls.Add(this.textslno);
            this.panel1.Controls.Add(this.labelslno);
            this.panel1.Location = new System.Drawing.Point(23, 95);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(519, 363);
            this.panel1.TabIndex = 5;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // labeldelete
            // 
            this.labeldelete.AutoSize = true;
            this.labeldelete.Location = new System.Drawing.Point(218, 67);
            this.labeldelete.Name = "labeldelete";
            this.labeldelete.Size = new System.Drawing.Size(58, 13);
            this.labeldelete.TabIndex = 17;
            this.labeldelete.Text = "labeldelete";
            // 
            // labelerror
            // 
            this.labelerror.AutoSize = true;
            this.labelerror.Location = new System.Drawing.Point(218, 308);
            this.labelerror.Name = "labelerror";
            this.labelerror.Size = new System.Drawing.Size(50, 13);
            this.labelerror.TabIndex = 16;
            this.labelerror.Text = "labelerror";
            // 
            // radioButtondebit
            // 
            this.radioButtondebit.AutoSize = true;
            this.radioButtondebit.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtondebit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.radioButtondebit.Location = new System.Drawing.Point(405, 221);
            this.radioButtondebit.Name = "radioButtondebit";
            this.radioButtondebit.Size = new System.Drawing.Size(65, 25);
            this.radioButtondebit.TabIndex = 15;
            this.radioButtondebit.TabStop = true;
            this.radioButtondebit.Text = "Debit";
            this.radioButtondebit.UseVisualStyleBackColor = true;
            this.radioButtondebit.MouseHover += new System.EventHandler(this.radioButtondebit_MouseHover);
            // 
            // labelamount
            // 
            this.labelamount.AutoSize = true;
            this.labelamount.BackColor = System.Drawing.Color.White;
            this.labelamount.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelamount.ForeColor = System.Drawing.Color.Navy;
            this.labelamount.Location = new System.Drawing.Point(30, 283);
            this.labelamount.Name = "labelamount";
            this.labelamount.Size = new System.Drawing.Size(60, 18);
            this.labelamount.TabIndex = 14;
            this.labelamount.Text = "Amount";
            // 
            // labeltype
            // 
            this.labeltype.AutoSize = true;
            this.labeltype.BackColor = System.Drawing.Color.White;
            this.labeltype.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeltype.ForeColor = System.Drawing.Color.Navy;
            this.labeltype.Location = new System.Drawing.Point(30, 221);
            this.labeltype.Name = "labeltype";
            this.labeltype.Size = new System.Drawing.Size(139, 18);
            this.labeltype.TabIndex = 13;
            this.labeltype.Text = "Type of Transaction";
            // 
            // labeldescription
            // 
            this.labeldescription.AutoSize = true;
            this.labeldescription.BackColor = System.Drawing.Color.White;
            this.labeldescription.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeldescription.ForeColor = System.Drawing.Color.Navy;
            this.labeldescription.Location = new System.Drawing.Point(30, 157);
            this.labeldescription.Name = "labeldescription";
            this.labeldescription.Size = new System.Drawing.Size(83, 18);
            this.labeldescription.TabIndex = 12;
            this.labeldescription.Text = "Description";
            // 
            // labeldate
            // 
            this.labeldate.AutoSize = true;
            this.labeldate.BackColor = System.Drawing.Color.White;
            this.labeldate.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeldate.ForeColor = System.Drawing.Color.Navy;
            this.labeldate.Location = new System.Drawing.Point(30, 97);
            this.labeldate.Name = "labeldate";
            this.labeldate.Size = new System.Drawing.Size(138, 18);
            this.labeldate.TabIndex = 11;
            this.labeldate.Text = "Date of Transaction";
            // 
            // radioButtoncredit
            // 
            this.radioButtoncredit.AutoSize = true;
            this.radioButtoncredit.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtoncredit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.radioButtoncredit.Location = new System.Drawing.Point(221, 221);
            this.radioButtoncredit.Name = "radioButtoncredit";
            this.radioButtoncredit.Size = new System.Drawing.Size(70, 25);
            this.radioButtoncredit.TabIndex = 9;
            this.radioButtoncredit.TabStop = true;
            this.radioButtoncredit.Text = "Credit";
            this.radioButtoncredit.UseVisualStyleBackColor = true;
            this.radioButtoncredit.MouseHover += new System.EventHandler(this.radioButtoncredit_MouseHover);
            // 
            // combodescription
            // 
            this.combodescription.FormattingEnabled = true;
            this.combodescription.Location = new System.Drawing.Point(221, 154);
            this.combodescription.Name = "combodescription";
            this.combodescription.Size = new System.Drawing.Size(263, 21);
            this.combodescription.TabIndex = 8;
            this.combodescription.MouseHover += new System.EventHandler(this.combodescription_MouseHover);
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(221, 95);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(263, 20);
            this.dateTimePicker.TabIndex = 7;
            this.dateTimePicker.MouseHover += new System.EventHandler(this.dateTimePicker_MouseHover);
            // 
            // textamount
            // 
            this.textamount.Location = new System.Drawing.Point(221, 281);
            this.textamount.Name = "textamount";
            this.textamount.Size = new System.Drawing.Size(263, 20);
            this.textamount.TabIndex = 6;
            this.textamount.MouseHover += new System.EventHandler(this.textamount_MouseHover);
            // 
            // textslno
            // 
            this.textslno.Location = new System.Drawing.Point(221, 35);
            this.textslno.Name = "textslno";
            this.textslno.Size = new System.Drawing.Size(263, 20);
            this.textslno.TabIndex = 5;
            this.textslno.MouseHover += new System.EventHandler(this.textslno_MouseHover);
            // 
            // labelmain
            // 
            this.labelmain.AutoSize = true;
            this.labelmain.BackColor = System.Drawing.Color.White;
            this.labelmain.Font = new System.Drawing.Font("Poor Richard", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmain.Location = new System.Drawing.Point(362, 19);
            this.labelmain.Name = "labelmain";
            this.labelmain.Size = new System.Drawing.Size(277, 41);
            this.labelmain.TabIndex = 16;
            this.labelmain.Text = "POCKET MONEY";
            // 
            // buttonsave
            // 
            this.buttonsave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonsave.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonsave.Location = new System.Drawing.Point(577, 375);
            this.buttonsave.Name = "buttonsave";
            this.buttonsave.Size = new System.Drawing.Size(80, 61);
            this.buttonsave.TabIndex = 17;
            this.buttonsave.Text = "SAVE";
            this.buttonsave.UseVisualStyleBackColor = false;
            this.buttonsave.Click += new System.EventHandler(this.buttonsave_Click);
            // 
            // buttonupdate
            // 
            this.buttonupdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonupdate.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonupdate.Location = new System.Drawing.Point(747, 378);
            this.buttonupdate.Name = "buttonupdate";
            this.buttonupdate.Size = new System.Drawing.Size(80, 61);
            this.buttonupdate.TabIndex = 18;
            this.buttonupdate.Text = "UPDATE";
            this.buttonupdate.UseVisualStyleBackColor = false;
            this.buttonupdate.Click += new System.EventHandler(this.buttonupdate_Click);
            // 
            // buttondelete
            // 
            this.buttondelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttondelete.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttondelete.Location = new System.Drawing.Point(914, 376);
            this.buttondelete.Name = "buttondelete";
            this.buttondelete.Size = new System.Drawing.Size(80, 61);
            this.buttondelete.TabIndex = 19;
            this.buttondelete.Text = "DELETE";
            this.buttondelete.UseVisualStyleBackColor = false;
            this.buttondelete.Click += new System.EventHandler(this.buttondelete_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(577, 148);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(405, 203);
            this.dataGridView1.TabIndex = 20;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellContentClick);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 341);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(519, 22);
            this.statusStrip1.TabIndex = 18;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.BackColor = System.Drawing.Color.Gainsboro;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // labelsearch
            // 
            this.labelsearch.AutoSize = true;
            this.labelsearch.BackColor = System.Drawing.Color.White;
            this.labelsearch.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelsearch.ForeColor = System.Drawing.Color.Navy;
            this.labelsearch.Location = new System.Drawing.Point(574, 97);
            this.labelsearch.Name = "labelsearch";
            this.labelsearch.Size = new System.Drawing.Size(43, 18);
            this.labelsearch.TabIndex = 19;
            this.labelsearch.Text = "Sl.No";
            // 
            // textsearch
            // 
            this.textsearch.Location = new System.Drawing.Point(703, 95);
            this.textsearch.Name = "textsearch";
            this.textsearch.Size = new System.Drawing.Size(263, 20);
            this.textsearch.TabIndex = 19;
            this.textsearch.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // PocketMoneyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1027, 504);
            this.Controls.Add(this.textsearch);
            this.Controls.Add(this.labelsearch);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.buttondelete);
            this.Controls.Add(this.buttonupdate);
            this.Controls.Add(this.buttonsave);
            this.Controls.Add(this.labelmain);
            this.Controls.Add(this.panel1);
            this.Name = "PocketMoneyForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.PocketMoneyForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelslno;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioButtondebit;
        private System.Windows.Forms.Label labelamount;
        private System.Windows.Forms.Label labeltype;
        private System.Windows.Forms.Label labeldescription;
        private System.Windows.Forms.Label labeldate;
        private System.Windows.Forms.RadioButton radioButtoncredit;
        private System.Windows.Forms.ComboBox combodescription;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.TextBox textamount;
        private System.Windows.Forms.TextBox textslno;
        private System.Windows.Forms.Label labelmain;
        private System.Windows.Forms.Button buttonsave;
        private System.Windows.Forms.Label labelerror;
        private System.Windows.Forms.Button buttonupdate;
        private System.Windows.Forms.Button buttondelete;
        private System.Windows.Forms.Label labeldelete;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Label labelsearch;
        private System.Windows.Forms.TextBox textsearch;
    }
}

