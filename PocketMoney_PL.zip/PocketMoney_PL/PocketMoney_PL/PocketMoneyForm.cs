﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PocketMoney_DTO.DTO;
using PocketMoney_BLL.BL;
using System.Data.SqlClient;


namespace PocketMoney_PL
{
    public partial class PocketMoneyForm : Form
    {
        public PocketMoneyForm()
        {
            InitializeComponent();
        }

        private void buttonsave_Click(object sender, EventArgs e)
        {
            if (textslno.Text == String.Empty ||  textamount.Text == String.Empty || combodescription.SelectedIndex == -1)
            {
                labelerror.Text = "All fields are mandatory";
            }

            if (textslno.Text == String.Empty)
            {
                labelerror.Text = "Sl No should be filled";
            }
            else if (textamount.Text == String.Empty)
            {
                labelerror.Text = "Amount should be filled";
            }
            else if (!radioButtoncredit.Checked && !radioButtondebit.Checked )
            {
                labelerror.Text = "Enter the type of transaction";
            }
            else if (combodescription.SelectedIndex == -1)
            {
                labelerror.Text = "Enter the required description of your transaction";
            }
            else
            {
                try
                {
                    PocketMoneyDTO objdto = new PocketMoneyDTO();
                    int output = 0;
                    objdto.SlNo = Convert.ToInt32(textslno.Text);
                    objdto.DATE = dateTimePicker.Value.ToString("yyyy-MM-dd");
                    objdto.DESCRIPTION = combodescription.Text;
                    objdto.AMOUNT = Convert.ToInt64(textamount.Text);
                    if (radioButtoncredit.Checked)
                    {
                        objdto.TYPE = radioButtoncredit.Text;
                    }
                    else
                    {
                        objdto.TYPE = radioButtondebit.Text;
                    }

                    output = Money_BLL.INSERTBL(objdto);


                    if (output > 0)
                    {
                        MessageBox.Show("Success - Value is inserted");
                    }
                    else
                    {
                        MessageBox.Show("Fail- Value is not inserted");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error : PocketMoneyForm : SaveMethod() " + ex.Message.ToString());
                }
            }
            LoadContact();
        }

        private void buttonupdate_Click(object sender, EventArgs e)
        {
            PocketMoneyDTO obj = null;
            try
            {
                int output = 0;
               
                obj = new PocketMoneyDTO();
                obj.DATE = dateTimePicker.Value.ToString("dd-MM-yyyy");
                obj.SlNo = Convert.ToInt32(textslno.Text);

                //DateTime now = DateTime.Now;
                //Console.WriteLine(now);
                //Console.ReadLine();



                obj.DESCRIPTION = combodescription.Text;
                obj.AMOUNT = Convert.ToInt64(textamount.Text);

                if (radioButtoncredit.Checked)
                {
                    obj.TYPE = "CREDIT";
                }
                else
                {
                    obj.TYPE = "DEBIT";
                }

                

                output = Money_BLL.Update(obj);
                if (output > 0)
                {
                    MessageBox.Show(" Contact updated successfully");
                    LoadContact();
                }
                else
                {
                    MessageBox.Show(" Contact is not updated");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: PocketMoneyForm : Updatebutton() " + ex.Message.ToString());
            }

        }

        private void PocketMoneyForm_Load(object sender, EventArgs e)
        {
            combodescription.Items.Add("Cafe");
            combodescription.Items.Add("HDFC Bank");
            combodescription.Items.Add("Hotel");
            combodescription.Items.Add("Shopping");
            combodescription.Items.Add("Cafe");
            combodescription.Items.Add("ICICI Bank");
            LoadContact();

        }

        private void buttondelete_Click(object sender, EventArgs e)
        {

            if (textslno.Text == string.Empty)
            {
                labeldelete.Text = "Please select a Sl.No to delete.";
            }
            else
            {
                int output = 0;
                try
                {
                    if (MessageBox.Show("Do you want to Delete", "S I S", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        output = Money_BLL.DELETEBL(textslno.Text);

                        if (output > 0)
                        {
                            labelerror.Text = "DATA deleted ";

                        }
                        else
                        {
                            labelerror.Text = "DATA couldnt be found,Try again later";
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error : PocketMoneyForm : Delete_Method() " + ex.Message.ToString());
                }
            }
        }

        private void LoadContact()
        {
            DataSet dsContacts = null;
            try
            {
                dsContacts = Money_BLL.GetContact();
                if (dsContacts != null)
                {
                    dataGridView1.DataSource = dsContacts.Tables[0];
                }
                else
                {
                    MessageBox.Show(" No Data available ");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : PocketMoneyForm : LoadContact()" + ex.Message.ToString());
            }
        }
        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textslno_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Please enter Sl.No ";
        }

        private void dateTimePicker_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Enter the date of transaction ";
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            toolStripStatusLabel1.Text = " ";
        }

        private void combodescription_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Please select the description of transaction ";
        }

        private void radioButtoncredit_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Cash will be credited ";
        }

        private void radioButtondebit_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Cash will be debited ";
        }

        private void textamount_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Please enter the amount";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            {
                DataSet dsStudents = null;
                try
                {
                    dsStudents = Money_BLL.GetContactLike(textsearch.Text);
                    if (dsStudents != null)
                    {
                        dataGridView1.DataSource = dsStudents.Tables[0];
                        //comboBox1.ValueMember = "Id";
                        //comboBox1.DisplayMember = "Id";
                    }
                    else
                    {
                        labelerror.Text = "No students avialbale";
                    }
                }
                catch (Exception ex)
                {
                    labelerror.Text = ex.Message.ToString();
                }
            }
        }
    }
}
