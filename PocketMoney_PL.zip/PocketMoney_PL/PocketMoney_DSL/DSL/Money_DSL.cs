﻿using System;
using System.Collections.Generic;
using System.Text;
using PocketMoney_DTO.DTO;
using PocketMoney_DSL.Helper;
using System.Data.SqlClient;
using System.Data;



namespace PocketMoney_DSL.DSL
{
    public  class Money_DSL
    {
        public static int INSERTDSL(PocketMoneyDTO dtoobj2)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;
            try
            {
                sql = "insert into Newtable(SlNo,Date,Description,Type,Amount) values(";
                sql = sql + dtoobj2.SlNo + ",";
                sql = sql + "'" + dtoobj2.DATE + "',";
                sql = sql + "'" + dtoobj2.DESCRIPTION + "',";
                sql = sql + "'" + dtoobj2.TYPE + "',";
                sql = sql + dtoobj2.AMOUNT + ")";

                con = Helper.DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("Error : Money_DSL : INSERTDSL() " + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }
        public static int DELETEDSL(string textslno)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;
            try
            {
                sql = "delete from NewTable where SlNo='" + textslno + "'";
                con = Helper.DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("Error : AddressDSL : DELETEDSL() " + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }
        public static DataSet GetContact()
        {

            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsContact = null;
            try
            {

                sql = "select * from NewTable";

                con = DBHelper.GetConnection();

                con.Open();

                dsContact = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsContact);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("Error: MoneyDSL: GetContact" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }
            return dsContact;
        }
        public static int Update(PocketMoneyDTO obj)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = "update NewTable set ";
                sql = sql + "Date = '" + obj.DATE + "',";
                sql = sql + "Description = '" + obj.DESCRIPTION + "',";
                sql = sql + "Type = '" + obj.TYPE + "',";
                sql = sql + "Amount = " + obj.AMOUNT + " ";
                sql = sql + "where SlNo ='" + obj.SlNo + "'";

                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("Error: AddressDSL: AddressUpdate" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }
        public static DataSet GetContactLike(string likeName)
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsSTudents = null;

            try
            {
                sql = "select  * from NewTable where Description like '" + likeName + "%'";
                con = DBHelper.GetConnection();
                con.Open();
                dsSTudents = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsSTudents);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" Inside catch-ERROR : AddressDSL :GetContactLike() " + e3.Message.ToString());
            }
            finally
            {
                con.Close();
            }
            return dsSTudents;
        }
    }
}
