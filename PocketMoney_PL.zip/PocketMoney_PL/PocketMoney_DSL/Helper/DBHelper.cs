﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows;
using PocketMoney_DTO.DTO;


namespace PocketMoney_DSL.Helper
{
    class DBHelper
    {
        public static SqlConnection GetConnection()
        {
            SqlConnection con = null;
            string connectionstring = null;
            try
            {
                connectionstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\1028289\\source\\repos\\PocketMoney_PL\\PocketMoney_DSL\\Data\\Data.mdf;Integrated Security=True";

                con = new SqlConnection(connectionstring); 
            }
            catch (Exception e3)
            {
              
                Console.Out.WriteLine("  DBHelper : SqlConnection " + e3.Message.ToString());
            }
            return con;
        }
    }
}
