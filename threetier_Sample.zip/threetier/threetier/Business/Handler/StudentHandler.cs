﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using threetier.backend;
using threetier.business.dto;

namespace threetier.business.Handler
{
    class StudentHandler
    {
        public static int Insert_Student(Student student)
        {
            int output = 0;
            string sql = "";
            try
            {
                // generate query
                sql = "insert into tbl_student values(";
                sql += student.student_id + ",";
                sql += "'" + student.student_name + "',";
                sql += student.mark1 + ",";
                sql += student.mark2 + ",";
                sql += student.mark3 + ",";
                sql += student.total + ",";
                sql += "'" + student.grade + "')";
                output = DBHelper.ExecuteNonQuery(sql);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("*** Error : Module5.ThreeTier.Business.HelperInsert_Student * ***" + ex.Message.ToString());
            }
            return output;
        }
    }
}
