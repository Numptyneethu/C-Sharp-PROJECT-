﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.ConfigurationManager;

namespace threetier.backend
{
    class DBHelper
    {
        static string connectionString = ConfigurationManager.ConnectionStrings["TestDBConnection"].ConnectionString;

        public static int ExecuteNonQuery(String sql)
        {
            int output = 0;
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(sql, con);
                    output = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("*** Error : Module5.ThreeTier.BackEnd.DBHelperExecuteNonQuery * ***" + ex.Message.ToString());
            }
            return output;
        }
        public static DataSet ExecuteQuery(String sql)
        {
            DataSet dataSet = null;
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    dataSet = new DataSet();
                    SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
                    adapter.Fill(dataSet);
                    
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("*** Error : Module5.ThreeTier.BackEnd.DBHelper ExecuteQuery * ***" + ex.Message.ToString());

            }
            return dataSet;
        }
    }
}