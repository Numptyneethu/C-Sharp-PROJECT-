﻿namespace threetier
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textboxid = new System.Windows.Forms.TextBox();
            this.labelname = new System.Windows.Forms.Label();
            this.labelid = new System.Windows.Forms.Label();
            this.labelmark1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelmark2 = new System.Windows.Forms.Label();
            this.labelmark3 = new System.Windows.Forms.Label();
            this.labeltotal = new System.Windows.Forms.Label();
            this.labelgrade = new System.Windows.Forms.Label();
            this.textBoxmark2 = new System.Windows.Forms.TextBox();
            this.textBoxtotal = new System.Windows.Forms.TextBox();
            this.textBoxmark3 = new System.Windows.Forms.TextBox();
            this.textBoxmark1 = new System.Windows.Forms.TextBox();
            this.textboxname = new System.Windows.Forms.TextBox();
            this.textBoxgrade = new System.Windows.Forms.TextBox();
            this.buttonsave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textboxid
            // 
            this.textboxid.Location = new System.Drawing.Point(311, 55);
            this.textboxid.Name = "textboxid";
            this.textboxid.Size = new System.Drawing.Size(100, 20);
            this.textboxid.TabIndex = 0;
            // 
            // labelname
            // 
            this.labelname.AutoSize = true;
            this.labelname.Location = new System.Drawing.Point(159, 110);
            this.labelname.Name = "labelname";
            this.labelname.Size = new System.Drawing.Size(35, 13);
            this.labelname.TabIndex = 1;
            this.labelname.Text = "Name";
            // 
            // labelid
            // 
            this.labelid.AutoSize = true;
            this.labelid.Location = new System.Drawing.Point(159, 55);
            this.labelid.Name = "labelid";
            this.labelid.Size = new System.Drawing.Size(18, 13);
            this.labelid.TabIndex = 2;
            this.labelid.Text = "ID";
            // 
            // labelmark1
            // 
            this.labelmark1.AutoSize = true;
            this.labelmark1.Location = new System.Drawing.Point(159, 165);
            this.labelmark1.Name = "labelmark1";
            this.labelmark1.Size = new System.Drawing.Size(40, 13);
            this.labelmark1.TabIndex = 3;
            this.labelmark1.Text = "Mark 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(159, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 4;
            // 
            // labelmark2
            // 
            this.labelmark2.AutoSize = true;
            this.labelmark2.Location = new System.Drawing.Point(159, 221);
            this.labelmark2.Name = "labelmark2";
            this.labelmark2.Size = new System.Drawing.Size(37, 13);
            this.labelmark2.TabIndex = 5;
            this.labelmark2.Text = "Mark2";
            // 
            // labelmark3
            // 
            this.labelmark3.AutoSize = true;
            this.labelmark3.Location = new System.Drawing.Point(159, 271);
            this.labelmark3.Name = "labelmark3";
            this.labelmark3.Size = new System.Drawing.Size(37, 13);
            this.labelmark3.TabIndex = 6;
            this.labelmark3.Text = "Mark3";
            // 
            // labeltotal
            // 
            this.labeltotal.AutoSize = true;
            this.labeltotal.Location = new System.Drawing.Point(157, 324);
            this.labeltotal.Name = "labeltotal";
            this.labeltotal.Size = new System.Drawing.Size(31, 13);
            this.labeltotal.TabIndex = 7;
            this.labeltotal.Text = "Total";
            // 
            // labelgrade
            // 
            this.labelgrade.AutoSize = true;
            this.labelgrade.Location = new System.Drawing.Point(157, 382);
            this.labelgrade.Name = "labelgrade";
            this.labelgrade.Size = new System.Drawing.Size(36, 13);
            this.labelgrade.TabIndex = 8;
            this.labelgrade.Text = "Grade";
            // 
            // textBoxmark2
            // 
            this.textBoxmark2.Location = new System.Drawing.Point(311, 221);
            this.textBoxmark2.Name = "textBoxmark2";
            this.textBoxmark2.Size = new System.Drawing.Size(100, 20);
            this.textBoxmark2.TabIndex = 9;
            // 
            // textBoxtotal
            // 
            this.textBoxtotal.Location = new System.Drawing.Point(311, 317);
            this.textBoxtotal.Name = "textBoxtotal";
            this.textBoxtotal.Size = new System.Drawing.Size(100, 20);
            this.textBoxtotal.TabIndex = 10;
            // 
            // textBoxmark3
            // 
            this.textBoxmark3.Location = new System.Drawing.Point(311, 268);
            this.textBoxmark3.Name = "textBoxmark3";
            this.textBoxmark3.Size = new System.Drawing.Size(100, 20);
            this.textBoxmark3.TabIndex = 11;
            // 
            // textBoxmark1
            // 
            this.textBoxmark1.Location = new System.Drawing.Point(311, 162);
            this.textBoxmark1.Name = "textBoxmark1";
            this.textBoxmark1.Size = new System.Drawing.Size(100, 20);
            this.textBoxmark1.TabIndex = 12;
            // 
            // textboxname
            // 
            this.textboxname.Location = new System.Drawing.Point(311, 107);
            this.textboxname.Name = "textboxname";
            this.textboxname.Size = new System.Drawing.Size(100, 20);
            this.textboxname.TabIndex = 13;
            // 
            // textBoxgrade
            // 
            this.textBoxgrade.Location = new System.Drawing.Point(311, 375);
            this.textBoxgrade.Name = "textBoxgrade";
            this.textBoxgrade.Size = new System.Drawing.Size(100, 20);
            this.textBoxgrade.TabIndex = 14;
            // 
            // buttonsave
            // 
            this.buttonsave.Location = new System.Drawing.Point(660, 377);
            this.buttonsave.Name = "buttonsave";
            this.buttonsave.Size = new System.Drawing.Size(75, 23);
            this.buttonsave.TabIndex = 15;
            this.buttonsave.Text = "SAVE";
            this.buttonsave.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonsave);
            this.Controls.Add(this.textBoxgrade);
            this.Controls.Add(this.textboxname);
            this.Controls.Add(this.textBoxmark1);
            this.Controls.Add(this.textBoxmark3);
            this.Controls.Add(this.textBoxtotal);
            this.Controls.Add(this.textBoxmark2);
            this.Controls.Add(this.labelgrade);
            this.Controls.Add(this.labeltotal);
            this.Controls.Add(this.labelmark3);
            this.Controls.Add(this.labelmark2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelmark1);
            this.Controls.Add(this.labelid);
            this.Controls.Add(this.labelname);
            this.Controls.Add(this.textboxid);
            this.Name = "Form1";
            this.Text = "2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textboxid;
        private System.Windows.Forms.Label labelname;
        private System.Windows.Forms.Label labelid;
        private System.Windows.Forms.Label labelmark1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelmark2;
        private System.Windows.Forms.Label labelmark3;
        private System.Windows.Forms.Label labeltotal;
        private System.Windows.Forms.Label labelgrade;
        private System.Windows.Forms.TextBox textBoxmark2;
        private System.Windows.Forms.TextBox textBoxtotal;
        private System.Windows.Forms.TextBox textBoxmark3;
        private System.Windows.Forms.TextBox textBoxmark1;
        private System.Windows.Forms.TextBox textboxname;
        private System.Windows.Forms.TextBox textBoxgrade;
        private System.Windows.Forms.Button buttonsave;
    }
}

