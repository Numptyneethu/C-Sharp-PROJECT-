﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigCalculator
{
    public partial class Form1 : Form
    {
        double Val1, Val2,answer;
        string result = "";
        string Operation;

        private void button1_Click(object sender, EventArgs e)
        {

            if (richtext.Text == "0"  &&  richtext.Text!= null)
            {
                richtext.Text = "1";
            }
            else
            {
                richtext.Text = richtext.Text +"1";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(richtext.Text == "0" && richtext.Text != null)
            {
                richtext.Text = "2";
            }
            else
            {
                richtext.Text = richtext.Text + "2";
            }
        }

        private void add_Click(object sender, EventArgs e) //add
        {
            Val1 = Convert.ToDouble(richtext.Text);
            result = Val1 + "+";
            textBox1.Text = result;
            richtext.Text = "0";
            Operation = "+";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (richtext.Text == "0" && richtext.Text != null)
            {
                richtext.Text = "3";
            }
            else
            {
                richtext.Text = richtext.Text + "3";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (richtext.Text == "0" && richtext.Text != null)
            {
                richtext.Text = "4";
            }
            else
            {
                richtext.Text = richtext.Text + "4";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (richtext.Text == "0" && richtext.Text != null)
            {
                richtext.Text = "5";
            }
            else
            {
                richtext.Text = richtext.Text + "5";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (richtext.Text == "0" && richtext.Text != null)
            {
                richtext.Text = "6";
            }
            else
            {
                richtext.Text = richtext.Text + "6";
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (richtext.Text == "0" && richtext.Text != null)
            {
                richtext.Text = "7";
            }
            else
            {
                richtext.Text = richtext.Text + "7";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (richtext.Text == "0" && richtext.Text != null)
            {
                richtext.Text = "8";
            }
            else
            {
                richtext.Text = richtext.Text + "8";
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (richtext.Text == "0" && richtext.Text != null)
            {
                richtext.Text = "9";
            }
            else
            {
                richtext.Text = richtext.Text + "9";
            }
        }

        private void button11_Click(object sender, EventArgs e) //sub
        {
            Val1 = Convert.ToDouble(richtext.Text);
            result = Val1 + "-";
            textBox1.Text = result;
            richtext.Text = "0";
            Operation = "-";


        }

        private void mult_Click(object sender, EventArgs e)
        {
            Val1 = Convert.ToDouble(richtext.Text);
            result = Val1 + "*";
            textBox1.Text = result;
            richtext.Text = "0";
            Operation = "*";

        }

        private void div_Click(object sender, EventArgs e)
        {
            Val1 = Convert.ToDouble(richtext.Text);
            result = Val1 + "/";
            textBox1.Text = result;
            richtext.Text = "0";
            Operation = "/";

        }

        private void dot_Click(object sender, EventArgs e)
        {
            if (richtext.Text == "0" && richtext.Text != null)
            {
                richtext.Text = ".";
            }
            else
            {
                richtext.Text = richtext.Text + ".";
            }
        }

        private void zero_Click(object sender, EventArgs e)
        {
            if (richtext.Text == "0" && richtext.Text != null)
            {
                richtext.Text = "0";
            }
            else
            {
                richtext.Text = richtext.Text + "0";
            }

        }

        private void clear_Click(object sender, EventArgs e)
        {
            richtext.Text = "0";
        }

        private void backspace_Click(object sender, EventArgs e)
        {
            String prefix = richtext.Text.Substring(0, (richtext.Text.Length-1));  //from index 0 to StringLength - 1
            richtext.Text = prefix;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void equalto_Click(object sender, EventArgs e)
        {

            if (Operation == "+")
            {
                Val2 = Convert.ToDouble(richtext.Text);
                result = Val1 + "+" + Val2;
                answer = Val1 + Val2;
                textBox1.Text = result;
                richtext.Text = Convert.ToString(answer);
                Operation = "0";
            }
            else if (Operation == "-")
            {
                Val2 = Convert.ToDouble(richtext.Text);
                result = Val1 + "-" + Val2;
                answer = Val1 - Val2;
                textBox1.Text = result;
                richtext.Text = Convert.ToString(answer);
                Operation = "0";
            }
            else if (Operation == "*")
            {
                Val2 = Convert.ToDouble(richtext.Text);
                result = Val1 + "*" + Val2;
                answer = Val1 * Val2;
                textBox1.Text = result;
                richtext.Text = Convert.ToString(answer);
                Operation = "0";
            }
            else
            {
                Val2 = Convert.ToDouble(richtext.Text);
                result = Val1 + "/" + Val2;
                answer = Val1 / Val2;
                textBox1.Text = result;
                richtext.Text = Convert.ToString(answer);
                Operation = "0";
            }






        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
