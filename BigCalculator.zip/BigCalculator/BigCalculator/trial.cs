﻿//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Forms;

//namespace WindowsFormsApp1
//{
//    public partial class CalculatorDemo : Form
//    {
//        double Val1, Val2;
//        string result = "";
//        string Operation;

//        public CalculatorDemo()
//        {
//            InitializeComponent();
//        }

//        private void button4_Click(object sender, EventArgs e)
//        {
//            // txResult1.Text +="4";

//            if (txResult1.Text == "0" && txResult1.Text != null)
//            {
//                txResult1.Text = "4";
//                //result += 4;
//            }
//            else
//            {
//                txResult1.Text = txResult1.Text + "4";
//                // result += 4;
//            }

//            //result += 4;
//            //txResult1.Text = result.ToString();
//        }

//        private void button8_Click(object sender, EventArgs e)
//        {
//            if (txResult1.Text == "0" && txResult1.Text != null)
//            {
//                txResult1.Text = "8";
//                //result += 8;
//            }
//            else
//            {
//                txResult1.Text = txResult1.Text + "8";
//                // result += 8;
//            }
//        }

//        private void btn1_Click(object sender, EventArgs e)
//        {
//            if (txResult1.Text == "0" && txResult1.Text != null)
//            {
//                txResult1.Text = "1";
//                // result += 1;
//            }
//            else
//            {
//                txResult1.Text = txResult1.Text + "1";
//                // result += 1;
//            }
//        }

//        private void btn2_Click(object sender, EventArgs e)
//        {
//            if (txResult1.Text == "0" && txResult1.Text != null)
//            {
//                txResult1.Text = "2";
//                // result += 2;
//            }
//            else
//            {
//                txResult1.Text = txResult1.Text + "2";
//                //  result += 2;
//            }
//        }

//        private void btn3_Click(object sender, EventArgs e)
//        {
//            if (txResult1.Text == "0" && txResult1.Text != null)
//            {
//                txResult1.Text = "3";
//                //  result += 3;
//            }
//            else
//            {
//                txResult1.Text = txResult1.Text + "3";
//                //  result += 3;
//            }
//        }

//        private void btn5_Click(object sender, EventArgs e)
//        {
//            if (txResult1.Text == "0" && txResult1.Text != null)
//            {
//                txResult1.Text = "5";
//                // result += 5;
//            }
//            else
//            {
//                txResult1.Text = txResult1.Text + "5";
//                //  result += 5;
//            }
//        }

//        private void btn6_Click(object sender, EventArgs e)
//        {
//            if (txResult1.Text == "0" && txResult1.Text != null)
//            {
//                txResult1.Text = "6";
//                //result += 6;
//            }
//            else
//            {
//                txResult1.Text = txResult1.Text + "6";
//                // result += 6;
//            }
//        }

//        private void btn7_Click(object sender, EventArgs e)
//        {
//            if (txResult1.Text == "0" && txResult1.Text != null)
//            {
//                txResult1.Text = "7";
//                //  result += 7;
//            }
//            else
//            {
//                txResult1.Text = txResult1.Text + "7";
//                // result += 7;
//            }
//        }

//        private void btn9_Click(object sender, EventArgs e)
//        {
//            if (txResult1.Text == "0" && txResult1.Text != null)
//            {
//                txResult1.Text = "9";
//            }
//            else
//            {
//                txResult1.Text = txResult1.Text + "9";
//            }

//        }

//        private void btn0_Click(object sender, EventArgs e)
//        {
//            txResult1.Text = txResult1.Text + "0";
//        }

//        private void btnDot_Click(object sender, EventArgs e)
//        {

//            if (txResult1.Text != null)
//            {
//                txResult1.Text = txResult1.Text + ".";
//                //result += ".";

//            }
//            else
//            {
//                txResult1.Text = "0.";
//                //result += ".";
//            }
//            // result += 9;

//            //if (txResult1.Text=="")
//            //{
//            //    result +=("0.");
//            //    txResult1.Text = result.ToString();
//            //}
//            //else
//            //{
//            //    result += ".";
//            //    txResult1.Text = result.ToString();
//            //}           
//        }

//        private void btnAdd_Click(object sender, EventArgs e)
//        {

//            //{
//            //    Val1 = Convert.ToDouble(txResult1.Text);
//            //    result = Val1 + "+";
//            //    txtShw.Text = result;
//            //    txResult1.Text = "0";
//            //    Operation = "+";
//            //}
//            Val1 = Convert.ToDouble(txResult1.Text);
//            result = Val1 + "+";
//            txtShw.Text = result;
//            txResult1.Text = "0";
//            Operation = "+";
//        }

//        private void butDiv_Click(object sender, EventArgs e)
//        {
//            Val1 = Convert.ToDouble(txResult1.Text);
//            result = Val1 + "/";
//            txtShw.Text = result;
//            txResult1.Text = "0";
//            Operation = "/";
//        }

//        private void btnSub_Click(object sender, EventArgs e)
//        {
//            Val1 = Convert.ToDouble(txResult1.Text);
//            result = Val1 + "-";
//            txtShw.Text = result;
//            txResult1.Text = "0";
//            Operation = "-";
//        }

//        private void btnMul_Click(object sender, EventArgs e)
//        {
//            Val1 = Convert.ToDouble(txResult1.Text);
//            result = Val1 + "*";
//            txtShw.Text = result;
//            txResult1.Text = "0";
//            Operation = "*";
//        }

//        private void btnEql_Click(object sender, EventArgs e)
//        {
//            double Result;

//            Val2 = Convert.ToDouble(txResult1.Text);

//            if (Operation == "+")
//            {
//                result = Val1 + "+" + Val2;
//                txtShw.Text = result;
//                Result = (Val1 + Val2);
//                txResult1.Text = Convert.ToString(Result);
//                Val1 = Result;

//            }
//            if (Operation == "-")
//            {
//                result = Val1 + "-" + Val2;
//                txtShw.Text = result;
//                Result = (Val1 - Val2);
//                txResult1.Text = Convert.ToString(Result);
//                Val1 = Result;
//            }
//            if (Operation == "*")
//            {
//                result = Val1 + "*" + Val2;
//                txtShw.Text = result;
//                Result = (Val1 * Val2);
//                txResult1.Text = Convert.ToString(Result);
//                Val1 = Result;
//            }
//            if (Operation == "/")
//            {
//                result = Val1 + "/" + Val2;
//                txtShw.Text = result;
//                Result = (Val1 / Val2);
//                txResult1.Text = Convert.ToString(Result);
//                Val1 = Result;
//            }

//        }

//        private void txtShw_TextChanged(object sender, EventArgs e)
//        {

//        }

//        private void btnClear_Click(object sender, EventArgs e)
//        {
//            txResult1.Text = "0";
//            txtShw.Text = "0";
//            result = "0";
//            Val1 = 0;
//            Val2 = 0;

//        }
//    }
//}