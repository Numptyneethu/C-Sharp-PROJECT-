﻿namespace LinQ
{
    partial class StudentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelid = new System.Windows.Forms.Label();
            this.labelHeading = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelname = new System.Windows.Forms.Label();
            this.labelmark3 = new System.Windows.Forms.Label();
            this.labelmark2 = new System.Windows.Forms.Label();
            this.labelmark1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textid = new System.Windows.Forms.TextBox();
            this.texttotal = new System.Windows.Forms.TextBox();
            this.textmark3 = new System.Windows.Forms.TextBox();
            this.textmark2 = new System.Windows.Forms.TextBox();
            this.textmark1 = new System.Windows.Forms.TextBox();
            this.textname = new System.Windows.Forms.TextBox();
            this.textgrade = new System.Windows.Forms.TextBox();
            this.comboBox = new System.Windows.Forms.ComboBox();
            this.buttonnew = new System.Windows.Forms.Button();
            this.buttondelete = new System.Windows.Forms.Button();
            this.buttonedit = new System.Windows.Forms.Button();
            this.labelmessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelid
            // 
            this.labelid.AutoSize = true;
            this.labelid.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.labelid.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.labelid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelid.Location = new System.Drawing.Point(100, 149);
            this.labelid.Name = "labelid";
            this.labelid.Size = new System.Drawing.Size(19, 15);
            this.labelid.TabIndex = 0;
            this.labelid.Text = "ID";
            // 
            // labelHeading
            // 
            this.labelHeading.AutoSize = true;
            this.labelHeading.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHeading.ForeColor = System.Drawing.Color.Blue;
            this.labelHeading.Location = new System.Drawing.Point(255, 10);
            this.labelHeading.Name = "labelHeading";
            this.labelHeading.Size = new System.Drawing.Size(139, 24);
            this.labelHeading.TabIndex = 1;
            this.labelHeading.Text = "Student Details";
            this.labelHeading.Click += new System.EventHandler(this.labelHeading_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.label2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(100, 402);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Total";
            // 
            // labelname
            // 
            this.labelname.AutoSize = true;
            this.labelname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.labelname.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.labelname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelname.Location = new System.Drawing.Point(100, 202);
            this.labelname.Name = "labelname";
            this.labelname.Size = new System.Drawing.Size(86, 15);
            this.labelname.TabIndex = 3;
            this.labelname.Text = "Student Name";
            // 
            // labelmark3
            // 
            this.labelmark3.AutoSize = true;
            this.labelmark3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.labelmark3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.labelmark3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmark3.Location = new System.Drawing.Point(100, 355);
            this.labelmark3.Name = "labelmark3";
            this.labelmark3.Size = new System.Drawing.Size(42, 15);
            this.labelmark3.TabIndex = 4;
            this.labelmark3.Text = "Mark3";
            // 
            // labelmark2
            // 
            this.labelmark2.AutoSize = true;
            this.labelmark2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.labelmark2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.labelmark2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmark2.Location = new System.Drawing.Point(100, 309);
            this.labelmark2.Name = "labelmark2";
            this.labelmark2.Size = new System.Drawing.Size(42, 15);
            this.labelmark2.TabIndex = 5;
            this.labelmark2.Text = "Mark2";
            // 
            // labelmark1
            // 
            this.labelmark1.AutoSize = true;
            this.labelmark1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.labelmark1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.labelmark1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmark1.Location = new System.Drawing.Point(100, 253);
            this.labelmark1.Name = "labelmark1";
            this.labelmark1.Size = new System.Drawing.Size(42, 15);
            this.labelmark1.TabIndex = 6;
            this.labelmark1.Text = "Mark1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.label1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(101, 448);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "Grade";
            // 
            // textid
            // 
            this.textid.Location = new System.Drawing.Point(229, 141);
            this.textid.Name = "textid";
            this.textid.Size = new System.Drawing.Size(306, 21);
            this.textid.TabIndex = 8;
            // 
            // texttotal
            // 
            this.texttotal.Location = new System.Drawing.Point(229, 402);
            this.texttotal.Name = "texttotal";
            this.texttotal.Size = new System.Drawing.Size(306, 21);
            this.texttotal.TabIndex = 9;
            // 
            // textmark3
            // 
            this.textmark3.Location = new System.Drawing.Point(229, 347);
            this.textmark3.Name = "textmark3";
            this.textmark3.Size = new System.Drawing.Size(306, 21);
            this.textmark3.TabIndex = 10;
            // 
            // textmark2
            // 
            this.textmark2.Location = new System.Drawing.Point(229, 301);
            this.textmark2.Name = "textmark2";
            this.textmark2.Size = new System.Drawing.Size(306, 21);
            this.textmark2.TabIndex = 11;
            // 
            // textmark1
            // 
            this.textmark1.Location = new System.Drawing.Point(229, 245);
            this.textmark1.Name = "textmark1";
            this.textmark1.Size = new System.Drawing.Size(306, 21);
            this.textmark1.TabIndex = 12;
            // 
            // textname
            // 
            this.textname.Location = new System.Drawing.Point(229, 194);
            this.textname.Name = "textname";
            this.textname.Size = new System.Drawing.Size(306, 21);
            this.textname.TabIndex = 13;
            // 
            // textgrade
            // 
            this.textgrade.Location = new System.Drawing.Point(229, 448);
            this.textgrade.Name = "textgrade";
            this.textgrade.Size = new System.Drawing.Size(306, 21);
            this.textgrade.TabIndex = 14;
            // 
            // comboBox
            // 
            this.comboBox.FormattingEnabled = true;
            this.comboBox.Location = new System.Drawing.Point(229, 89);
            this.comboBox.Name = "comboBox";
            this.comboBox.Size = new System.Drawing.Size(306, 23);
            this.comboBox.TabIndex = 15;
            // 
            // buttonnew
            // 
            this.buttonnew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonnew.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonnew.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonnew.Location = new System.Drawing.Point(104, 513);
            this.buttonnew.Name = "buttonnew";
            this.buttonnew.Size = new System.Drawing.Size(120, 51);
            this.buttonnew.TabIndex = 16;
            this.buttonnew.Text = "NEW";
            this.buttonnew.UseVisualStyleBackColor = true;
            // 
            // buttondelete
            // 
            this.buttondelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttondelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttondelete.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttondelete.ImageKey = "(none)";
            this.buttondelete.Location = new System.Drawing.Point(415, 513);
            this.buttondelete.Name = "buttondelete";
            this.buttondelete.Size = new System.Drawing.Size(120, 51);
            this.buttondelete.TabIndex = 17;
            this.buttondelete.Text = "DELETE";
            this.buttondelete.UseVisualStyleBackColor = true;
            // 
            // buttonedit
            // 
            this.buttonedit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonedit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonedit.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonedit.Location = new System.Drawing.Point(260, 513);
            this.buttonedit.Name = "buttonedit";
            this.buttonedit.Size = new System.Drawing.Size(120, 51);
            this.buttonedit.TabIndex = 18;
            this.buttonedit.Text = "EDIT";
            this.buttonedit.UseVisualStyleBackColor = true;
            // 
            // labelmessage
            // 
            this.labelmessage.AutoSize = true;
            this.labelmessage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelmessage.Location = new System.Drawing.Point(299, 51);
            this.labelmessage.Name = "labelmessage";
            this.labelmessage.Size = new System.Drawing.Size(58, 15);
            this.labelmessage.TabIndex = 19;
            this.labelmessage.Text = "Message";
            // 
            // StudentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(661, 612);
            this.Controls.Add(this.labelmessage);
            this.Controls.Add(this.buttonedit);
            this.Controls.Add(this.buttondelete);
            this.Controls.Add(this.buttonnew);
            this.Controls.Add(this.comboBox);
            this.Controls.Add(this.textgrade);
            this.Controls.Add(this.textname);
            this.Controls.Add(this.textmark1);
            this.Controls.Add(this.textmark2);
            this.Controls.Add(this.textmark3);
            this.Controls.Add(this.texttotal);
            this.Controls.Add(this.textid);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelmark1);
            this.Controls.Add(this.labelmark2);
            this.Controls.Add(this.labelmark3);
            this.Controls.Add(this.labelname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelHeading);
            this.Controls.Add(this.labelid);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "StudentForm";
            this.Text = "StudentForm";
            this.TransparencyKey = System.Drawing.Color.Red;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelid;
        private System.Windows.Forms.Label labelHeading;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelname;
        private System.Windows.Forms.Label labelmark3;
        private System.Windows.Forms.Label labelmark2;
        private System.Windows.Forms.Label labelmark1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textid;
        private System.Windows.Forms.TextBox texttotal;
        private System.Windows.Forms.TextBox textmark3;
        private System.Windows.Forms.TextBox textmark2;
        private System.Windows.Forms.TextBox textmark1;
        private System.Windows.Forms.TextBox textname;
        private System.Windows.Forms.TextBox textgrade;
        private System.Windows.Forms.ComboBox comboBox;
        private System.Windows.Forms.Button buttonnew;
        private System.Windows.Forms.Button buttondelete;
        private System.Windows.Forms.Button buttonedit;
        private System.Windows.Forms.Label labelmessage;
    }
}