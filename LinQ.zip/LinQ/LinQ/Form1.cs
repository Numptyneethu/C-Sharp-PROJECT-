﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LinQ
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           // Loadnumber();
          //  LoadName();
        }

        private void Loadnumber()
        {
            int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            var LinQuery = from num in numbers
                           where (num % 2) == 0
                           select num;
            cbNumbers.DataSource = LinQuery.ToList();

            //List<int> lstNumbers = LinQuery.ToList();

            //foreach(int val in lstNumbers)
            //{
            //    cbNumbers.Items.Add(val);
            //   // Console.WriteLine("val : " + val);
            //}
        }

        private void btnLoadNumber_Click(object sender, EventArgs e)
        {
            Loadnumber();
        }
        private void LoadName()
        {
            //datasourse
            string[] names = { "bill", "Steve","Mohan","james" };
            //linquery
            var myLinquery = from name in names
                             where name.Contains('a')
                             select name;
            //query execution
            foreach(var name in myLinquery)
            {
                cbName.Items.Add(name);
            }
        }

        private void btnLoadName_Click(object sender, EventArgs e)
        {
            LoadName();
        }
    }
    
}
