﻿namespace LinQ
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoadNumber = new System.Windows.Forms.Button();
            this.cbNumbers = new System.Windows.Forms.ComboBox();
            this.cbName = new System.Windows.Forms.ComboBox();
            this.btnLoadName = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnLoadNumber
            // 
            this.btnLoadNumber.Location = new System.Drawing.Point(84, 273);
            this.btnLoadNumber.Name = "btnLoadNumber";
            this.btnLoadNumber.Size = new System.Drawing.Size(143, 50);
            this.btnLoadNumber.TabIndex = 0;
            this.btnLoadNumber.Text = "Load Number";
            this.btnLoadNumber.UseVisualStyleBackColor = true;
            this.btnLoadNumber.Click += new System.EventHandler(this.btnLoadNumber_Click);
            // 
            // cbNumbers
            // 
            this.cbNumbers.FormattingEnabled = true;
            this.cbNumbers.Location = new System.Drawing.Point(84, 121);
            this.cbNumbers.Name = "cbNumbers";
            this.cbNumbers.Size = new System.Drawing.Size(121, 21);
            this.cbNumbers.TabIndex = 1;
            // 
            // cbName
            // 
            this.cbName.FormattingEnabled = true;
            this.cbName.Location = new System.Drawing.Point(334, 121);
            this.cbName.Name = "cbName";
            this.cbName.Size = new System.Drawing.Size(121, 21);
            this.cbName.TabIndex = 2;
            // 
            // btnLoadName
            // 
            this.btnLoadName.Location = new System.Drawing.Point(334, 273);
            this.btnLoadName.Name = "btnLoadName";
            this.btnLoadName.Size = new System.Drawing.Size(143, 50);
            this.btnLoadName.TabIndex = 3;
            this.btnLoadName.Text = "Load Name";
            this.btnLoadName.UseVisualStyleBackColor = true;
            this.btnLoadName.Click += new System.EventHandler(this.btnLoadName_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLoadName);
            this.Controls.Add(this.cbName);
            this.Controls.Add(this.cbNumbers);
            this.Controls.Add(this.btnLoadNumber);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLoadNumber;
        private System.Windows.Forms.ComboBox cbNumbers;
        private System.Windows.Forms.ComboBox cbName;
        private System.Windows.Forms.Button btnLoadName;
    }
}

