﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LinQ
{
    //Linq with array and collection object
    public partial class Lambda : Form
    {
        Student[] studentArray =
        {
            new Student() {StudentID=1,StudentName= "Ammu",Age=18},
             new Student() {StudentID=2,StudentName="Jancy",Age=28},
             new Student() {StudentID=3,StudentName="Geetha",Age=15},
             new Student() {StudentID=4,StudentName="Akku",Age=38},
              new Student() {StudentID=5,StudentName="Meena",Age=42},
        };
        
        public Lambda()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void btnLambda1_Click(object sender, EventArgs e)
        {
            List<Student> teenagerStudents = studentArray.Where(s => s.Age > 12 && s.Age < 20).ToList();
            dataGridView.DataSource = teenagerStudents;
        }

        private void btnLambda2_Click(object sender, EventArgs e)
        {
            List<Student> teenageStudents = studentArray.Where(i => i.StudentName == "ammu").ToList();
            dataGridView.DataSource = teenageStudents;
        }

        private void btnLambda3_Click(object sender, EventArgs e)
        {
            List<Student> teenageStudents = studentArray.Where(i => i.StudentID == 3).ToList();
            dataGridView.DataSource = teenageStudents;
        }

        private void Lambda_Load(object sender, EventArgs e)
        {

        }
    }
    class Student
    {
        public int StudentID
        { get; set; }
        public string StudentName
        { get; set; }
        public int Age
        { get; set; }
    }

   
}
