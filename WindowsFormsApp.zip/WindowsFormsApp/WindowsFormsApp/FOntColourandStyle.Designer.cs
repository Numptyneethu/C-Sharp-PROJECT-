﻿namespace WindowsFormsApp
{
    partial class BigCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelwelcome = new System.Windows.Forms.Label();
            this.buttoncolor = new System.Windows.Forms.Button();
            this.buttonfonrchange = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelwelcome
            // 
            this.labelwelcome.AutoSize = true;
            this.labelwelcome.Font = new System.Drawing.Font("Monotype Corsiva", 21.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelwelcome.Location = new System.Drawing.Point(63, 101);
            this.labelwelcome.Name = "labelwelcome";
            this.labelwelcome.Size = new System.Drawing.Size(132, 36);
            this.labelwelcome.TabIndex = 0;
            this.labelwelcome.Text = "Welcome....";
            // 
            // buttoncolor
            // 
            this.buttoncolor.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttoncolor.Font = new System.Drawing.Font("Snap ITC", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttoncolor.ForeColor = System.Drawing.Color.White;
            this.buttoncolor.Location = new System.Drawing.Point(64, 140);
            this.buttoncolor.Name = "buttoncolor";
            this.buttoncolor.Size = new System.Drawing.Size(131, 58);
            this.buttoncolor.TabIndex = 1;
            this.buttoncolor.Text = "Change my Color";
            this.buttoncolor.UseVisualStyleBackColor = false;
            this.buttoncolor.Click += new System.EventHandler(this.buttoncolor_Click);
            // 
            // buttonfonrchange
            // 
            this.buttonfonrchange.Font = new System.Drawing.Font("Snap ITC", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonfonrchange.Location = new System.Drawing.Point(64, 218);
            this.buttonfonrchange.Name = "buttonfonrchange";
            this.buttonfonrchange.Size = new System.Drawing.Size(131, 58);
            this.buttonfonrchange.TabIndex = 2;
            this.buttonfonrchange.Text = "Change my Font";
            this.buttonfonrchange.UseVisualStyleBackColor = true;
            this.buttonfonrchange.Click += new System.EventHandler(this.buttonfonrchange_Click);
            // 
            // BigCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonfonrchange);
            this.Controls.Add(this.buttoncolor);
            this.Controls.Add(this.labelwelcome);
            this.Name = "BigCalculator";
            this.Text = "BigCalculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelwelcome;
        private System.Windows.Forms.Button buttoncolor;
        private System.Windows.Forms.Button buttonfonrchange;
    }
}