﻿namespace WindowsFormsApp
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelValue1 = new System.Windows.Forms.Label();
            this.labelvalue2 = new System.Windows.Forms.Label();
            this.labelresult = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button1ADD = new System.Windows.Forms.Button();
            this.button2SUB = new System.Windows.Forms.Button();
            this.button3DIV = new System.Windows.Forms.Button();
            this.button4MULT = new System.Windows.Forms.Button();
            this.labelexception = new System.Windows.Forms.Label();
            this.button_Ampersant = new System.Windows.Forms.Button();
            this.button_CLEAR = new System.Windows.Forms.Button();
            this.one = new System.Windows.Forms.Button();
            this.three = new System.Windows.Forms.Button();
            this.six = new System.Windows.Forms.Button();
            this.nine = new System.Windows.Forms.Button();
            this.eight = new System.Windows.Forms.Button();
            this.seven = new System.Windows.Forms.Button();
            this.five = new System.Windows.Forms.Button();
            this.four = new System.Windows.Forms.Button();
            this.two = new System.Windows.Forms.Button();
            this.dot = new System.Windows.Forms.Button();
            this.zero = new System.Windows.Forms.Button();
            this.equalto = new System.Windows.Forms.Button();
            this.input1 = new System.Windows.Forms.Label();
            this.input2 = new System.Windows.Forms.Label();
            this.richtextbox = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // labelValue1
            // 
            this.labelValue1.AutoSize = true;
            this.labelValue1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.labelValue1.Location = new System.Drawing.Point(0, 43);
            this.labelValue1.Name = "labelValue1";
            this.labelValue1.Size = new System.Drawing.Size(46, 13);
            this.labelValue1.TabIndex = 0;
            this.labelValue1.Text = "Value 1 ";
            // 
            // labelvalue2
            // 
            this.labelvalue2.AutoSize = true;
            this.labelvalue2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.labelvalue2.Location = new System.Drawing.Point(0, 87);
            this.labelvalue2.Name = "labelvalue2";
            this.labelvalue2.Size = new System.Drawing.Size(43, 13);
            this.labelvalue2.TabIndex = 1;
            this.labelvalue2.Text = "Value 2";
            // 
            // labelresult
            // 
            this.labelresult.AutoSize = true;
            this.labelresult.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelresult.Location = new System.Drawing.Point(0, 130);
            this.labelresult.Name = "labelresult";
            this.labelresult.Size = new System.Drawing.Size(37, 13);
            this.labelresult.TabIndex = 2;
            this.labelresult.Text = "Result";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(3, 287);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(3, 320);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 4;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(3, 346);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 5;
            // 
            // button1ADD
            // 
            this.button1ADD.Location = new System.Drawing.Point(232, 33);
            this.button1ADD.Name = "button1ADD";
            this.button1ADD.Size = new System.Drawing.Size(75, 23);
            this.button1ADD.TabIndex = 6;
            this.button1ADD.Text = "ADD";
            this.button1ADD.UseVisualStyleBackColor = true;
            this.button1ADD.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2SUB
            // 
            this.button2SUB.Location = new System.Drawing.Point(232, 62);
            this.button2SUB.Name = "button2SUB";
            this.button2SUB.Size = new System.Drawing.Size(75, 23);
            this.button2SUB.TabIndex = 7;
            this.button2SUB.Text = "SUB";
            this.button2SUB.UseVisualStyleBackColor = true;
            this.button2SUB.Click += new System.EventHandler(this.button2SUB_Click);
            // 
            // button3DIV
            // 
            this.button3DIV.Location = new System.Drawing.Point(232, 120);
            this.button3DIV.Name = "button3DIV";
            this.button3DIV.Size = new System.Drawing.Size(75, 23);
            this.button3DIV.TabIndex = 8;
            this.button3DIV.Text = "DIV";
            this.button3DIV.UseVisualStyleBackColor = true;
            this.button3DIV.Click += new System.EventHandler(this.button3DIV_Click);
            // 
            // button4MULT
            // 
            this.button4MULT.Location = new System.Drawing.Point(232, 91);
            this.button4MULT.Name = "button4MULT";
            this.button4MULT.Size = new System.Drawing.Size(75, 23);
            this.button4MULT.TabIndex = 9;
            this.button4MULT.Text = "MULT";
            this.button4MULT.UseVisualStyleBackColor = true;
            this.button4MULT.Click += new System.EventHandler(this.button4MULT_Click);
            // 
            // labelexception
            // 
            this.labelexception.AutoSize = true;
            this.labelexception.Location = new System.Drawing.Point(46, 13);
            this.labelexception.Name = "labelexception";
            this.labelexception.Size = new System.Drawing.Size(0, 13);
            this.labelexception.TabIndex = 10;
            // 
            // button_Ampersant
            // 
            this.button_Ampersant.Location = new System.Drawing.Point(232, 149);
            this.button_Ampersant.Name = "button_Ampersant";
            this.button_Ampersant.Size = new System.Drawing.Size(75, 23);
            this.button_Ampersant.TabIndex = 11;
            this.button_Ampersant.Text = "%";
            this.button_Ampersant.UseVisualStyleBackColor = true;
            // 
            // button_CLEAR
            // 
            this.button_CLEAR.Location = new System.Drawing.Point(232, 178);
            this.button_CLEAR.Name = "button_CLEAR";
            this.button_CLEAR.Size = new System.Drawing.Size(75, 23);
            this.button_CLEAR.TabIndex = 12;
            this.button_CLEAR.Text = "C";
            this.button_CLEAR.UseVisualStyleBackColor = true;
            this.button_CLEAR.Click += new System.EventHandler(this.button_CLEAR_Click);
            // 
            // one
            // 
            this.one.Location = new System.Drawing.Point(3, 183);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(43, 23);
            this.one.TabIndex = 22;
            this.one.Text = "1";
            this.one.UseVisualStyleBackColor = true;
            this.one.Click += new System.EventHandler(this.one_Click);
            // 
            // three
            // 
            this.three.Location = new System.Drawing.Point(101, 183);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(43, 23);
            this.three.TabIndex = 23;
            this.three.Text = "3";
            this.three.UseVisualStyleBackColor = true;
            this.three.Click += new System.EventHandler(this.three_Click);
            // 
            // six
            // 
            this.six.Location = new System.Drawing.Point(101, 212);
            this.six.Name = "six";
            this.six.Size = new System.Drawing.Size(43, 23);
            this.six.TabIndex = 24;
            this.six.Text = "6";
            this.six.UseVisualStyleBackColor = true;
            this.six.Click += new System.EventHandler(this.six_Click);
            // 
            // nine
            // 
            this.nine.Location = new System.Drawing.Point(101, 241);
            this.nine.Name = "nine";
            this.nine.Size = new System.Drawing.Size(43, 23);
            this.nine.TabIndex = 25;
            this.nine.Text = "9";
            this.nine.UseVisualStyleBackColor = true;
            this.nine.Click += new System.EventHandler(this.nine_Click);
            // 
            // eight
            // 
            this.eight.Location = new System.Drawing.Point(52, 241);
            this.eight.Name = "eight";
            this.eight.Size = new System.Drawing.Size(43, 23);
            this.eight.TabIndex = 26;
            this.eight.Text = "8";
            this.eight.UseVisualStyleBackColor = true;
            this.eight.Click += new System.EventHandler(this.eight_Click);
            // 
            // seven
            // 
            this.seven.Location = new System.Drawing.Point(3, 241);
            this.seven.Name = "seven";
            this.seven.Size = new System.Drawing.Size(43, 23);
            this.seven.TabIndex = 27;
            this.seven.Text = "7";
            this.seven.UseVisualStyleBackColor = true;
            this.seven.Click += new System.EventHandler(this.seven_Click);
            // 
            // five
            // 
            this.five.Location = new System.Drawing.Point(52, 212);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(43, 23);
            this.five.TabIndex = 28;
            this.five.Text = "5";
            this.five.UseVisualStyleBackColor = true;
            this.five.Click += new System.EventHandler(this.five_Click);
            // 
            // four
            // 
            this.four.Location = new System.Drawing.Point(3, 212);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(43, 23);
            this.four.TabIndex = 29;
            this.four.Text = "4";
            this.four.UseVisualStyleBackColor = true;
            this.four.Click += new System.EventHandler(this.four_Click);
            // 
            // two
            // 
            this.two.Location = new System.Drawing.Point(49, 183);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(43, 23);
            this.two.TabIndex = 30;
            this.two.Text = "2";
            this.two.UseVisualStyleBackColor = true;
            this.two.Click += new System.EventHandler(this.two_Click);
            // 
            // dot
            // 
            this.dot.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dot.Location = new System.Drawing.Point(150, 212);
            this.dot.Name = "dot";
            this.dot.Size = new System.Drawing.Size(75, 23);
            this.dot.TabIndex = 32;
            this.dot.Text = ".";
            this.dot.UseVisualStyleBackColor = true;
            // 
            // zero
            // 
            this.zero.Location = new System.Drawing.Point(150, 241);
            this.zero.Name = "zero";
            this.zero.Size = new System.Drawing.Size(75, 23);
            this.zero.TabIndex = 33;
            this.zero.Text = "0";
            this.zero.UseVisualStyleBackColor = true;
            // 
            // equalto
            // 
            this.equalto.Location = new System.Drawing.Point(151, 183);
            this.equalto.Name = "equalto";
            this.equalto.Size = new System.Drawing.Size(75, 23);
            this.equalto.TabIndex = 34;
            this.equalto.Text = "=";
            this.equalto.UseVisualStyleBackColor = true;
            this.equalto.Click += new System.EventHandler(this.equalto_Click);
            // 
            // input1
            // 
            this.input1.AutoSize = true;
            this.input1.Location = new System.Drawing.Point(159, 310);
            this.input1.Name = "input1";
            this.input1.Size = new System.Drawing.Size(13, 13);
            this.input1.TabIndex = 35;
            this.input1.Text = "..";
            this.input1.Click += new System.EventHandler(this.input1_Click);
            // 
            // input2
            // 
            this.input2.AutoSize = true;
            this.input2.Location = new System.Drawing.Point(75, 310);
            this.input2.Name = "input2";
            this.input2.Size = new System.Drawing.Size(13, 13);
            this.input2.TabIndex = 36;
            this.input2.Text = "..";
            this.input2.Click += new System.EventHandler(this.input2_Click);
            // 
            // richtextbox
            // 
            this.richtextbox.Location = new System.Drawing.Point(60, 40);
            this.richtextbox.Name = "richtextbox";
            this.richtextbox.Size = new System.Drawing.Size(146, 118);
            this.richtextbox.TabIndex = 37;
            this.richtextbox.Text = "";
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(306, 357);
            this.Controls.Add(this.richtextbox);
            this.Controls.Add(this.input2);
            this.Controls.Add(this.input1);
            this.Controls.Add(this.equalto);
            this.Controls.Add(this.zero);
            this.Controls.Add(this.dot);
            this.Controls.Add(this.two);
            this.Controls.Add(this.four);
            this.Controls.Add(this.five);
            this.Controls.Add(this.seven);
            this.Controls.Add(this.eight);
            this.Controls.Add(this.nine);
            this.Controls.Add(this.six);
            this.Controls.Add(this.three);
            this.Controls.Add(this.one);
            this.Controls.Add(this.button_CLEAR);
            this.Controls.Add(this.button_Ampersant);
            this.Controls.Add(this.labelexception);
            this.Controls.Add(this.button4MULT);
            this.Controls.Add(this.button3DIV);
            this.Controls.Add(this.button2SUB);
            this.Controls.Add(this.button1ADD);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.labelresult);
            this.Controls.Add(this.labelvalue2);
            this.Controls.Add(this.labelValue1);
            this.Name = "Calculator";
            this.Text = "Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelValue1;
        private System.Windows.Forms.Label labelvalue2;
        private System.Windows.Forms.Label labelresult;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button1ADD;
        private System.Windows.Forms.Button button2SUB;
        private System.Windows.Forms.Button button3DIV;
        private System.Windows.Forms.Button button4MULT;
        private System.Windows.Forms.Label labelexception;
        private System.Windows.Forms.Button button_Ampersant;
        private System.Windows.Forms.Button button_CLEAR;
        private System.Windows.Forms.Button one;
        private System.Windows.Forms.Button three;
        private System.Windows.Forms.Button six;
        private System.Windows.Forms.Button nine;
        private System.Windows.Forms.Button eight;
        private System.Windows.Forms.Button seven;
        private System.Windows.Forms.Button five;
        private System.Windows.Forms.Button four;
        private System.Windows.Forms.Button two;
        private System.Windows.Forms.Button dot;
        private System.Windows.Forms.Button zero;
        private System.Windows.Forms.Button equalto;
        private System.Windows.Forms.Label input1;
        private System.Windows.Forms.Label input2;
        private System.Windows.Forms.RichTextBox richtextbox;
    }
}