﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class BigCalculator : Form
    {
        public BigCalculator()
        {
            InitializeComponent();
        }

        private void buttoncolor_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.ShowDialog();
            if( dlg.ShowDialog()==DialogResult.OK)
            {
                labelwelcome.ForeColor = dlg.Color;
            }
              
        }

        private void buttonfonrchange_Click(object sender, EventArgs e)
        {
            FontDialog dlg = new FontDialog();
            dlg.ShowDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                labelwelcome.Font = dlg.Font;
            }
        }
    }
}
