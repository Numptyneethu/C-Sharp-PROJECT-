﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class Calculator : Form
    {
        public Calculator()
        {
            Calculator obj = new Calculator();
            obj.textBox1.Text = " 0";
            InitializeComponent();
             
        }
       

        private void button1_Click(object sender, EventArgs e) //add
        {
            int value1, value2,operation;

            operation = Convert.ToInt32("+");
            richtextbox.Text = (richtextbox.Text + "+");
            try
            {
                value1 = Convert.ToInt32(textBox1.Text.ToString());
                value2 = Convert.ToInt32(textBox2.Text.ToString());
               // result = value1 + value2;
               // textBox3.Text = result.ToString();
            }
            catch(Exception i)
            {
                labelexception.Text = "Enter a valid input";
            }
        }

        private void button2SUB_Click(object sender, EventArgs e)
        {
            int value1, value2, result;
            try
            {
                value1 = Convert.ToInt32(textBox1.Text.ToString());
                value2 = Convert.ToInt32(textBox2.Text.ToString());
                result = value1 - value2;
                textBox3.Text = result.ToString();
            }
            catch (Exception i)
            {
                labelexception.Text = "Please enter a valid input";
            }

        }

        private void button4MULT_Click(object sender, EventArgs e)
        {
            int value1, value2, result;
            try
            {
                value1 = Convert.ToInt32(textBox1.Text.ToString());
                value2 = Convert.ToInt32(textBox2.Text.ToString());
                result = value1 * value2;
                textBox3.Text = result.ToString();
            }
            catch (Exception i)
            {
                labelexception.Text = " Please enter a valid input";
            }

        }

        private void button3DIV_Click(object sender, EventArgs e)
        {
            int value1, value2, result;
            try
            {
                value1 = Convert.ToInt32(textBox1.Text.ToString());
                value2 = Convert.ToInt32(textBox2.Text.ToString());
                result = value1 / value2;
                textBox3.Text = result.ToString();
            }
            catch
            {
                labelexception.Text = "Please enter a valid input";
            }

        }

        private void button_CLEAR_Click(object sender, EventArgs e)
        {
            richtextbox.Text = "  ";
        }

        private void one_Click(object sender, EventArgs e)
        {

            richtextbox.Text = (richtextbox.Text + "1");
        }

        private void two_Click(object sender, EventArgs e)
        {
            richtextbox.Text = (richtextbox.Text + "2");
        }

        private void three_Click(object sender, EventArgs e)
        {
            richtextbox.Text = (richtextbox.Text + "3");
        }

        private void four_Click(object sender, EventArgs e)
        {
            richtextbox.Text = (richtextbox.Text + "4");
        }

        private void five_Click(object sender, EventArgs e)
        {
            richtextbox.Text = (richtextbox.Text + "5");
        }

        private void six_Click(object sender, EventArgs e)
        {

        }

        private void seven_Click(object sender, EventArgs e)
        {

        }

        private void eight_Click(object sender, EventArgs e)
        {

        }

        private void nine_Click(object sender, EventArgs e)
        {

        }

        private void input2_Click(object sender, EventArgs e)
        {

        }

        private void input1_Click(object sender, EventArgs e)
        {
         
        }

        private void equalto_Click(object sender, EventArgs e)
        {
            int result;
            

        }

        //private void button9_Click(object sender, EventArgs e)
        //{

        //}
    }
}
