﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit;
using NUnit.Framework;
using TestDemoApp;
using Assert = NUnit.Framework.Assert;

namespace TestCalculator
{
    [TestFixture]
    class MyTest
    {
        [TestCase]
        public void TestMethod1()
        {
            Calculator p1 = new Calculator();
            Assert.AreEqual(30, p1.Add(20, 11));

        }

        [TestCase]
        public void TestSubMethod()
        {
            Calculator p1 = new Calculator();
            Assert.AreEqual(9, p1.Sub(20, 11));

        }
    }
}
