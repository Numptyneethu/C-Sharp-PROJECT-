﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestDemoApp;


namespace TestCalculator
{
    [TestClass]
    public class CalculatorTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            Calculator p1 = new Calculator();
            Assert.AreEqual(30, p1.Add(20, 11));
           
        }

        [TestMethod]
        public void TestSubMethod()
        {
            Calculator p1 = new Calculator();
            Assert.AreEqual(9, p1.Sub(20, 11));

        }
    }
}
