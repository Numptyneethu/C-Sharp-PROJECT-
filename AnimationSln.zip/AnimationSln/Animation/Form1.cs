﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

public class AnimateImage : Form
{
    private int width = 10;
    private int height = 10;

    Image pic = Image.FromFile("winter.jpg");
    private Button abort = new Button();
    Thread t;

    public AnimateImage()
    {
        abort.Text = "Abort";
        abort.Location = new Point(50, 230);
        abort.Click += new EventHandler(Abort_Click);
        Controls.Add(abort);

        SetStyle(ControlStyles.DoubleBuffer
               | ControlStyles.AllPaintingInWmPaint
               | ControlStyles.UserPaint, true);

        t = new Thread(new ThreadStart(Run));
        t.Start();
    }
    protected void Abort_Click(object sender, EventArgs e)
    {
        t.Abort();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        g.DrawRectangle(Pens.Black, 8, 8, width + 3, height + 3);
        g.DrawImage(pic, 10, 10, width, height);
        base.OnPaint(e);
    }

    public void Run()
    {
        int dx = 5, dy = 5;
        while (true)
        {
            for (int i = 0; i < 500; i++)
            {
                width += dx;
                height += dy;
                Invalidate();
                Thread.Sleep(30);
            }
            dx = -dx; dy = -dy;
        }
    }
    public static void Main()
    {
        Application.Run(new AnimateImage());
    }
}