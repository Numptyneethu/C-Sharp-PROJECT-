﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AddressBookDTO.DTO
{
    public class AddressBook
    {
        private String id, state, address;
        private String name,dob,email, gender;
        private double mobileno;


        public String ID
        {
            get { return id; }
            set { id = value; }
        }
        public String NAME
        {
            get { return name; }
            set { name = value; }
        }
        public String DOB
        {
            get { return dob; }
            set { dob = value; }
        }
        public String Email
        {
            get { return email; }
            set { email = value; }
        }
        public double Mobileno
        {
            get { return mobileno; }
            set { mobileno = value; }
        }
        public String Gender
        {
            get { return gender; }
            set { gender = value; }
        }
        public String State
        {
            get { return state; }
            set { state = value; }
        }
        public String Address
        {
            get { return address; }
            set { address = value; }
        }
    }
}
