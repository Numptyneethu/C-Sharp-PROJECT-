﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AddressBookBLL.AddressBL;
using AddressBookDTO.DTO;
using AddressBook_PL;

namespace AddressBook_PL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       

        private void labelemail_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void radiomale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet.NewTable' table. You can move, or remove it, as needed.
            this.newTableTableAdapter.Fill(this.databaseDataSet.NewTable);
            comboBoxstate.Items.Add("Kerala");
            comboBoxstate.Items.Add("Assam");
            comboBoxstate.Items.Add("Goa");
            comboBoxstate.Items.Add("Bihar");
            comboBoxstate.Items.Add("Tamil Nadu");
            comboBoxstate.Items.Add("Tripura");
            comboBoxstate.Items.Add("A P");
            LoadContactIds();
            LoadContact();
        }

        private void button1_Click(object sender, EventArgs e)  //save
        {
            try
            {
                AddressBook objdto = new AddressBook();
                int output = 0;
                objdto.ID = textid.Text;
                objdto.NAME = textname.Text;
                objdto.Address = richTextaddress.Text;
                objdto.Email = textemail.Text;
                objdto.Mobileno = Convert.ToInt64(textmobileno.Text);
                objdto.DOB = dateTimePicker.Value.ToString("yyyy-MM-dd");
                objdto.State = comboBoxstate.Text;

                if (radiofemale.Checked)
                {
                    objdto.Gender = radiofemale.Text;
                }
                else if (radiomale.Checked)
                {
                    objdto.Gender = radiomale.Text;
                }
                else
                {
                    objdto.Gender = radioothers.Text;
                }


                output = AddressBL.INSERTBL(objdto);

                if (output > 0)
                {
                    MessageBox.Show("Success - Value is inserted");
                }
                else
                {
                    MessageBox.Show("Fail- Value is not inserted");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : Form1 : button1_Click() " + ex.Message.ToString());
            }

        }

        private void comboBoxstate_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
       

        private void buttonview_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttondelete_Click(object sender, EventArgs e)
        {
            if (textid.Text == string.Empty)
            {
                labelDeleteMessage.Text = "Please select a Contact Id for delete.";
            }
            else
            {
                int output = 0;
                try
                {
                    if (MessageBox.Show("Do you want to Delete", "S I S", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        output = AddressBL.DELETEBL(textid.Text);

                        if (output > 0)
                        {
                            labelDeleteMessage.Text = "DATA deleted ";
                            
                        }
                        else
                        {
                            labelDeleteMessage.Text = "DATA couldnt be found,Try again later";
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error : Form1 : buttondelete_Click() " + ex.Message.ToString());
                }
            }
            //    int output = 0;
            //    try
            //    {
            //        if (MessageBox.Show("Do you want to Delete", "S I S", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            //        {
            //            output = AddressBL.DELETEBL(textid.Text);
            //            if (output > 0)
            //            {
            //                MessageBox.Show("DATA DELETED SUCCESSULLY");
            //            }
            //            else

            //            {
            //                MessageBox.Show("TRY AGAIN LATER");
            //            }
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //        Console.Out.WriteLine(ex.Message.ToString());
            //    }
            //}
            //private void LoadAddressBook()
            //{
            //    DataSet dsAddressBook = null;
            //    try
            //    {
            //        dsAddressBook = AddressBL.GetAddressBook();
            //        if (dsAddressBook != null)
            //        {
            //            dataGridView1.DataSource = dsAddressBook.Tables[0];
            //        }
            //        else
            //        {
            //            MessageBox.Show("No Details Available in Address Book");
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //        Console.Out.WriteLine(ex.Message.ToString());
            //    }
        }

        private void buttonupdate_Click(object sender, EventArgs e)
        {
            AddressBook addressBook = null;
            int output = 0;

            try
            {
                addressBook = new AddressBook();
                addressBook.ID = textid.Text;
                addressBook.NAME = textname.Text;
                addressBook.DOB = dateTimePicker.Value.ToString("dd-MM-yyyy");
                if (radiomale.Checked)
                {
                    addressBook.Gender = "Male";
                }
                else if (radiofemale.Checked)
                {
                    addressBook.Gender = "Female";
                }
                else
                {
                    addressBook.Gender = "Others";
                }
                
                addressBook.State = comboBoxstate.Text;
                addressBook.Email = textemail.Text;
                addressBook.Mobileno = Convert.ToInt64(textmobileno.Text);


                output = AddressBL.AddressUpdate(addressBook);

                if (output > 0)
                {
                    MessageBox.Show(" Contact updated successfully");
                    LoadContactIds();
                    LoadContact();
                }
                else
                {
                    MessageBox.Show(" Contact is not updated");
                  
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Form1 : Updatebutton() " + ex.Message.ToString());
            }
        }
        private void LoadContactIds()
        {
            DataSet dsContactIds = null;
            try
            {
                dsContactIds = AddressBL.GetContactIds();
                if (dsContactIds != null)
                {
                    comboBoxID.DataSource = dsContactIds.Tables[0];
                    comboBoxID.ValueMember = "Id";
                    comboBoxID.DisplayMember = "Id";
                }
                else
                {
                    MessageBox.Show(" No Contacts available ");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : Form1 : LoadContactIds()" + ex.Message.ToString());
            }
        }
        private void LoadContact()
        {
            DataSet dsContacts = null;
            try
            {
                dsContacts = AddressBL.GetContact();
                if (dsContacts != null)
                {
                    dataGridView1.DataSource = dsContacts.Tables[0];
                }
                else
                {
                    MessageBox.Show(" No Contacts available ");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : Form1 : LoadContact()" + ex.Message.ToString());
            }
        }
    }
}

