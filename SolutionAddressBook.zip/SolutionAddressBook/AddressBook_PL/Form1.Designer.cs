﻿namespace AddressBook_PL
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.labelname = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioothers = new System.Windows.Forms.RadioButton();
            this.radiofemale = new System.Windows.Forms.RadioButton();
            this.radiomale = new System.Windows.Forms.RadioButton();
            this.comboBoxstate = new System.Windows.Forms.ComboBox();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.richTextaddress = new System.Windows.Forms.RichTextBox();
            this.textmobileno = new System.Windows.Forms.TextBox();
            this.textemail = new System.Windows.Forms.TextBox();
            this.textname = new System.Windows.Forms.TextBox();
            this.textid = new System.Windows.Forms.TextBox();
            this.labeladdress = new System.Windows.Forms.Label();
            this.labelstate = new System.Windows.Forms.Label();
            this.labelgender = new System.Windows.Forms.Label();
            this.labelmobileno = new System.Windows.Forms.Label();
            this.labelemail = new System.Windows.Forms.Label();
            this.labeldob = new System.Windows.Forms.Label();
            this.labelid = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dOBDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mobilenoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addessDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.newTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.databaseDataSet = new AddressBook_PL.DatabaseDataSet();
            this.newTableTableAdapter = new AddressBook_PL.DatabaseDataSetTableAdapters.NewTableTableAdapter();
            this.buttondelete = new System.Windows.Forms.Button();
            this.button = new System.Windows.Forms.Button();
            this.buttonsave = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelDeleteMessage = new System.Windows.Forms.Label();
            this.buttonupdate = new System.Windows.Forms.Button();
            this.comboBoxID = new System.Windows.Forms.ComboBox();
            this.labelsearch = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.newTableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelname
            // 
            this.labelname.AutoSize = true;
            this.labelname.Location = new System.Drawing.Point(34, 69);
            this.labelname.Name = "labelname";
            this.labelname.Size = new System.Drawing.Size(53, 19);
            this.labelname.TabIndex = 0;
            this.labelname.Text = "Name";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.labelDeleteMessage);
            this.panel1.Controls.Add(this.radioothers);
            this.panel1.Controls.Add(this.radiofemale);
            this.panel1.Controls.Add(this.radiomale);
            this.panel1.Controls.Add(this.comboBoxstate);
            this.panel1.Controls.Add(this.dateTimePicker);
            this.panel1.Controls.Add(this.richTextaddress);
            this.panel1.Controls.Add(this.textmobileno);
            this.panel1.Controls.Add(this.textemail);
            this.panel1.Controls.Add(this.textname);
            this.panel1.Controls.Add(this.textid);
            this.panel1.Controls.Add(this.labeladdress);
            this.panel1.Controls.Add(this.labelstate);
            this.panel1.Controls.Add(this.labelgender);
            this.panel1.Controls.Add(this.labelmobileno);
            this.panel1.Controls.Add(this.labelemail);
            this.panel1.Controls.Add(this.labeldob);
            this.panel1.Controls.Add(this.labelid);
            this.panel1.Controls.Add(this.labelname);
            this.panel1.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel1.Location = new System.Drawing.Point(26, 128);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(549, 479);
            this.panel1.TabIndex = 1;
            // 
            // radioothers
            // 
            this.radioothers.AutoSize = true;
            this.radioothers.Location = new System.Drawing.Point(378, 278);
            this.radioothers.Name = "radioothers";
            this.radioothers.Size = new System.Drawing.Size(77, 23);
            this.radioothers.TabIndex = 17;
            this.radioothers.TabStop = true;
            this.radioothers.Text = "Others";
            this.radioothers.UseVisualStyleBackColor = true;
            // 
            // radiofemale
            // 
            this.radiofemale.AutoSize = true;
            this.radiofemale.Location = new System.Drawing.Point(266, 278);
            this.radiofemale.Name = "radiofemale";
            this.radiofemale.Size = new System.Drawing.Size(81, 23);
            this.radiofemale.TabIndex = 16;
            this.radiofemale.TabStop = true;
            this.radiofemale.Text = "Female";
            this.radiofemale.UseVisualStyleBackColor = true;
            // 
            // radiomale
            // 
            this.radiomale.AutoSize = true;
            this.radiomale.Location = new System.Drawing.Point(151, 280);
            this.radiomale.Name = "radiomale";
            this.radiomale.Size = new System.Drawing.Size(63, 23);
            this.radiomale.TabIndex = 15;
            this.radiomale.TabStop = true;
            this.radiomale.Text = "Male";
            this.radiomale.UseVisualStyleBackColor = true;
            this.radiomale.CheckedChanged += new System.EventHandler(this.radiomale_CheckedChanged);
            // 
            // comboBoxstate
            // 
            this.comboBoxstate.FormattingEnabled = true;
            this.comboBoxstate.Location = new System.Drawing.Point(151, 332);
            this.comboBoxstate.Name = "comboBoxstate";
            this.comboBoxstate.Size = new System.Drawing.Size(312, 27);
            this.comboBoxstate.TabIndex = 14;
            this.comboBoxstate.SelectedIndexChanged += new System.EventHandler(this.comboBoxstate_SelectedIndexChanged);
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(151, 123);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(312, 26);
            this.dateTimePicker.TabIndex = 13;
            // 
            // richTextaddress
            // 
            this.richTextaddress.ForeColor = System.Drawing.Color.Black;
            this.richTextaddress.Location = new System.Drawing.Point(151, 386);
            this.richTextaddress.Name = "richTextaddress";
            this.richTextaddress.Size = new System.Drawing.Size(312, 79);
            this.richTextaddress.TabIndex = 12;
            this.richTextaddress.Text = "";
            this.richTextaddress.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // textmobileno
            // 
            this.textmobileno.Location = new System.Drawing.Point(151, 228);
            this.textmobileno.Name = "textmobileno";
            this.textmobileno.Size = new System.Drawing.Size(312, 26);
            this.textmobileno.TabIndex = 11;
            // 
            // textemail
            // 
            this.textemail.Location = new System.Drawing.Point(151, 176);
            this.textemail.Name = "textemail";
            this.textemail.Size = new System.Drawing.Size(312, 26);
            this.textemail.TabIndex = 10;
            // 
            // textname
            // 
            this.textname.Location = new System.Drawing.Point(151, 66);
            this.textname.Name = "textname";
            this.textname.Size = new System.Drawing.Size(312, 26);
            this.textname.TabIndex = 9;
            // 
            // textid
            // 
            this.textid.Location = new System.Drawing.Point(151, 13);
            this.textid.Name = "textid";
            this.textid.Size = new System.Drawing.Size(312, 26);
            this.textid.TabIndex = 8;
            // 
            // labeladdress
            // 
            this.labeladdress.AutoSize = true;
            this.labeladdress.Location = new System.Drawing.Point(28, 386);
            this.labeladdress.Name = "labeladdress";
            this.labeladdress.Size = new System.Drawing.Size(70, 19);
            this.labeladdress.TabIndex = 7;
            this.labeladdress.Text = "Address";
            // 
            // labelstate
            // 
            this.labelstate.AutoSize = true;
            this.labelstate.Location = new System.Drawing.Point(31, 332);
            this.labelstate.Name = "labelstate";
            this.labelstate.Size = new System.Drawing.Size(46, 19);
            this.labelstate.TabIndex = 6;
            this.labelstate.Text = "State";
            // 
            // labelgender
            // 
            this.labelgender.AutoSize = true;
            this.labelgender.Location = new System.Drawing.Point(31, 282);
            this.labelgender.Name = "labelgender";
            this.labelgender.Size = new System.Drawing.Size(66, 19);
            this.labelgender.TabIndex = 5;
            this.labelgender.Text = "Gender";
            // 
            // labelmobileno
            // 
            this.labelmobileno.AutoSize = true;
            this.labelmobileno.Location = new System.Drawing.Point(31, 228);
            this.labelmobileno.Name = "labelmobileno";
            this.labelmobileno.Size = new System.Drawing.Size(89, 19);
            this.labelmobileno.TabIndex = 4;
            this.labelmobileno.Text = "Mobile No:";
            // 
            // labelemail
            // 
            this.labelemail.AutoSize = true;
            this.labelemail.Location = new System.Drawing.Point(34, 176);
            this.labelemail.Name = "labelemail";
            this.labelemail.Size = new System.Drawing.Size(50, 19);
            this.labelemail.TabIndex = 3;
            this.labelemail.Text = "Email";
            this.labelemail.Click += new System.EventHandler(this.labelemail_Click);
            // 
            // labeldob
            // 
            this.labeldob.AutoSize = true;
            this.labeldob.Location = new System.Drawing.Point(34, 123);
            this.labeldob.Name = "labeldob";
            this.labeldob.Size = new System.Drawing.Size(43, 19);
            this.labeldob.TabIndex = 2;
            this.labeldob.Text = "DOB";
            // 
            // labelid
            // 
            this.labelid.AutoSize = true;
            this.labelid.Location = new System.Drawing.Point(34, 13);
            this.labelid.Name = "labelid";
            this.labelid.Size = new System.Drawing.Size(26, 19);
            this.labelid.TabIndex = 1;
            this.labelid.Text = "ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 24F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(255, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(253, 40);
            this.label1.TabIndex = 18;
            this.label1.Text = "ADDRESS BOOK";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.dOBDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.mobilenoDataGridViewTextBoxColumn,
            this.genderDataGridViewTextBoxColumn,
            this.stateDataGridViewTextBoxColumn,
            this.addessDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.newTableBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(604, 78);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(595, 352);
            this.dataGridView1.TabIndex = 20;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // dOBDataGridViewTextBoxColumn
            // 
            this.dOBDataGridViewTextBoxColumn.DataPropertyName = "DOB";
            this.dOBDataGridViewTextBoxColumn.HeaderText = "DOB";
            this.dOBDataGridViewTextBoxColumn.Name = "dOBDataGridViewTextBoxColumn";
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            // 
            // mobilenoDataGridViewTextBoxColumn
            // 
            this.mobilenoDataGridViewTextBoxColumn.DataPropertyName = "Mobileno";
            this.mobilenoDataGridViewTextBoxColumn.HeaderText = "Mobileno";
            this.mobilenoDataGridViewTextBoxColumn.Name = "mobilenoDataGridViewTextBoxColumn";
            // 
            // genderDataGridViewTextBoxColumn
            // 
            this.genderDataGridViewTextBoxColumn.DataPropertyName = "Gender";
            this.genderDataGridViewTextBoxColumn.HeaderText = "Gender";
            this.genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            // 
            // stateDataGridViewTextBoxColumn
            // 
            this.stateDataGridViewTextBoxColumn.DataPropertyName = "State";
            this.stateDataGridViewTextBoxColumn.HeaderText = "State";
            this.stateDataGridViewTextBoxColumn.Name = "stateDataGridViewTextBoxColumn";
            // 
            // addessDataGridViewTextBoxColumn
            // 
            this.addessDataGridViewTextBoxColumn.DataPropertyName = "Addess";
            this.addessDataGridViewTextBoxColumn.HeaderText = "Addess";
            this.addessDataGridViewTextBoxColumn.Name = "addessDataGridViewTextBoxColumn";
            // 
            // newTableBindingSource
            // 
            this.newTableBindingSource.DataMember = "NewTable";
            this.newTableBindingSource.DataSource = this.databaseDataSet;
            // 
            // databaseDataSet
            // 
            this.databaseDataSet.DataSetName = "DatabaseDataSet";
            this.databaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // newTableTableAdapter
            // 
            this.newTableTableAdapter.ClearBeforeFill = true;
            // 
            // buttondelete
            // 
            this.buttondelete.Image = global::AddressBook_PL.Properties.Resources.aa;
            this.buttondelete.Location = new System.Drawing.Point(232, 23);
            this.buttondelete.Name = "buttondelete";
            this.buttondelete.Size = new System.Drawing.Size(66, 56);
            this.buttondelete.TabIndex = 22;
            this.buttondelete.UseVisualStyleBackColor = true;
            this.buttondelete.Click += new System.EventHandler(this.buttondelete_Click);
            // 
            // button
            // 
            this.button.Image = global::AddressBook_PL.Properties.Resources._12345;
            this.button.Location = new System.Drawing.Point(129, 23);
            this.button.Name = "button";
            this.button.Size = new System.Drawing.Size(66, 56);
            this.button.TabIndex = 21;
            this.button.UseVisualStyleBackColor = true;
            this.button.Click += new System.EventHandler(this.buttonview_Click);
            // 
            // buttonsave
            // 
            this.buttonsave.Image = ((System.Drawing.Image)(resources.GetObject("buttonsave.Image")));
            this.buttonsave.Location = new System.Drawing.Point(24, 23);
            this.buttonsave.Name = "buttonsave";
            this.buttonsave.Size = new System.Drawing.Size(66, 56);
            this.buttonsave.TabIndex = 19;
            this.buttonsave.UseVisualStyleBackColor = true;
            this.buttonsave.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel2.Controls.Add(this.buttonupdate);
            this.panel2.Controls.Add(this.buttonsave);
            this.panel2.Controls.Add(this.buttondelete);
            this.panel2.Controls.Add(this.button);
            this.panel2.Location = new System.Drawing.Point(604, 462);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(595, 100);
            this.panel2.TabIndex = 23;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // labelDeleteMessage
            // 
            this.labelDeleteMessage.AutoSize = true;
            this.labelDeleteMessage.Location = new System.Drawing.Point(147, 42);
            this.labelDeleteMessage.Name = "labelDeleteMessage";
            this.labelDeleteMessage.Size = new System.Drawing.Size(91, 19);
            this.labelDeleteMessage.TabIndex = 18;
            this.labelDeleteMessage.Text = "labeldelete";
            // 
            // buttonupdate
            // 
            this.buttonupdate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonupdate.BackgroundImage")));
            this.buttonupdate.Location = new System.Drawing.Point(331, 26);
            this.buttonupdate.Name = "buttonupdate";
            this.buttonupdate.Size = new System.Drawing.Size(55, 56);
            this.buttonupdate.TabIndex = 23;
            this.buttonupdate.UseVisualStyleBackColor = true;
            this.buttonupdate.Click += new System.EventHandler(this.buttonupdate_Click);
            // 
            // comboBoxID
            // 
            this.comboBoxID.FormattingEnabled = true;
            this.comboBoxID.Location = new System.Drawing.Point(177, 95);
            this.comboBoxID.Name = "comboBoxID";
            this.comboBoxID.Size = new System.Drawing.Size(121, 21);
            this.comboBoxID.TabIndex = 19;
            // 
            // labelsearch
            // 
            this.labelsearch.AutoSize = true;
            this.labelsearch.Location = new System.Drawing.Point(58, 98);
            this.labelsearch.Name = "labelsearch";
            this.labelsearch.Size = new System.Drawing.Size(69, 13);
            this.labelsearch.TabIndex = 19;
            this.labelsearch.Text = "Search by ID";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1211, 663);
            this.Controls.Add(this.labelsearch);
            this.Controls.Add(this.comboBoxID);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.newTableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelname;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelstate;
        private System.Windows.Forms.Label labelgender;
        private System.Windows.Forms.Label labelmobileno;
        private System.Windows.Forms.Label labelemail;
        private System.Windows.Forms.Label labeldob;
        private System.Windows.Forms.Label labelid;
        private System.Windows.Forms.RadioButton radioothers;
        private System.Windows.Forms.RadioButton radiofemale;
        private System.Windows.Forms.RadioButton radiomale;
        private System.Windows.Forms.ComboBox comboBoxstate;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.RichTextBox richTextaddress;
        private System.Windows.Forms.TextBox textmobileno;
        private System.Windows.Forms.TextBox textemail;
        private System.Windows.Forms.TextBox textname;
        private System.Windows.Forms.TextBox textid;
        private System.Windows.Forms.Label labeladdress;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonsave;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DatabaseDataSet databaseDataSet;
        private System.Windows.Forms.BindingSource newTableBindingSource;
        private DatabaseDataSetTableAdapters.NewTableTableAdapter newTableTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dOBDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mobilenoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addessDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button;
        private System.Windows.Forms.Button buttondelete;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelDeleteMessage;
        private System.Windows.Forms.Button buttonupdate;
        private System.Windows.Forms.ComboBox comboBoxID;
        private System.Windows.Forms.Label labelsearch;
    }
}

