﻿using System;
using System.Collections.Generic;
using System.Text;
using AddressBookDTO.DTO;
using AddressBookDSL.AddressDL;
using System.Windows.Forms;
using System.Data;
using AddressBookDSL.Helper;

namespace AddressBookBLL.AddressBL
{
    public class AddressBL
    {
        public static int INSERTBL(AddressBook dtoobj1)
        {
            int output = 0;
            try
            {
                output = AddressDSL.INSERTDSL(dtoobj1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : AddressBL : INSERTBL() " + ex.Message.ToString());
            }

            return output;
        }
        public static int DELETEBL(string textid)///
        {
            int output = 0;
            try
            {
                output = AddressDSL.DELETEDSL(textid);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine(" Error : AddressBL : DELETEBL() " + ex.Message.ToString());
            }
            return output;
        }
        public static int AddressUpdate(AddressBook addressBook)
        {
            int output = 0;

            try
            {
                output = AddressDSL.AddressUpdate(addressBook);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("Error: AddressBL: AddressUpdate" + ex.Message.ToString());
            }

            return output;
        }

        public static DataSet GetContactIds()
        {
            DataSet dsContact = null;
            try
            {
                dsContact = AddressDSL.GetContactIds();
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine(" Error :AddressBLL :GetContactIds" + ex.Message.ToString());
            }
            return dsContact;
        }

        public static DataSet GetContact()
        {

            DataSet dsStudent = null;
            try
            {
                dsStudent = AddressDSL.GetContact();

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("Error :AddressBL :GetContact" + ex.Message.ToString());
            }

            return dsStudent;
        }


        ////public static DataSet GetAddressBook()
        ////{
        ////    DataSet dsAddressBook = null;
        ////    try
        ////    {
        ////        dsAddressBook = AddressDSL.GetAddressBook();
        ////    }
        ////    catch (Exception ex)
        ////    {
        ////        Console.Out.WriteLine(" Error : AddressBL : GetAddressBook() " + ex.Message.ToString());
        ////    }
        ////    return dsAddressBook;
        //    int output = 0;
        //    try
        //    {
        //        output = AddressDSL.DELETEDSL(dtoobj1);
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Error : AddressBL : DELETEDSL() " + ex.Message.ToString());
        //    }

        //    return output;

        ////public static DataSet GetAddressBook()
        ////{
        ////    DataSet dsAddressBook = null;
        ////    try
        ////    {
        ////        dsAddressBook = AddressDSL.GetAddressBook();
        ////    }
        ////    catch (Exception ex)
        ////    {
        ////        Console.Out.WriteLine(" Error : AddressBLL : GetAddressBook() " + ex.Message.ToString());
        ////    }
        ////    return dsAddressBook;
        ////}

    }
}

