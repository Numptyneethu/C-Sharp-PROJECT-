﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;


namespace AddressBookDSL.Helper
{
    class DBHelper
    {
        public static SqlConnection GetConnection()
        {
            SqlConnection con = null;
            //string connectionstring = null;
            try
            {
                String connectionstring = ConfigurationManager.ConnectionStrings["AddressBook_PL.Properties.Settings.DatabaseConnectionString"].ConnectionString;
               // connectionstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\1028289\\source\\repos\\SolutionAddressBook\\ClasAddressBookDSL\\Data1\\Database.mdf;Integrated Security=True";
                con = new SqlConnection(connectionstring); //connection with db
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : DB_helper.cs " + e3.Message.ToString());
            }
            return con;
        }
    }
}
