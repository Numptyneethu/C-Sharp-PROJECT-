﻿using System;
using System.Collections.Generic;
using System.Text;
using AddressBookDTO.DTO;
using System.Data.SqlClient;
using System.Windows.Forms;
using AddressBookDSL.Helper;
using System.Data;
using AddressBookDSL.Helper;


namespace AddressBookDSL.AddressDL
{
   public  class AddressDSL
    {
        public static int INSERTDSL(AddressBook dtoobj2)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;
            try
            {
                sql = "insert into Newtable(Id,Name,DOB,Email,Mobileno,Gender,State,Addess) values(";
                sql = sql + dtoobj2.ID +",";
                sql = sql + "'" + dtoobj2.NAME + "',";
                sql = sql + "'" + dtoobj2.DOB + "',";
                sql = sql + "'" + dtoobj2.Email + "',";
                sql = sql +  dtoobj2.Mobileno + ",";
                sql = sql + "'" + dtoobj2.Gender + "',";
                sql = sql + "'" + dtoobj2.State + "',";
                sql = sql + "'" + dtoobj2.Address + "')";

                //insert into Newtable(Id, Name, DOB, Email, Mobileno, Gender, State, Addess)
                //  values(101, 'neeru', '2019-12-01', 'email', 7777777, 'Male', 'A P', 'addressss')
                con = Helper.DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : AddressDSL : INSERTDSL() " + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }

        public static int DELETEDSL(string textid)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;
            try
            {
                sql = "delete from NewTable where Id='" + textid + "'";
                con = Helper.DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("Error : AddressDSL : DELETEDSL() " + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }

        public static int AddressUpdate(AddressBook addressBook)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = "update NewTable set ";
                sql = sql + "Name = '" + addressBook.NAME + "',";
                sql = sql + "DOB = '" + addressBook.DOB + "',";
                sql = sql + "Gender = '" + addressBook.Gender + "',";
                sql = sql + "Address = '" + addressBook.State + "',";
                sql = sql + "State = '" + addressBook.State + "',";
                sql = sql + "Email = '" + addressBook.Email + "',";
                sql = sql + "Mobileno = " + addressBook.Mobileno + " ";
                sql = sql + "where Id ='" + addressBook.ID + "'";

                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);

                output = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("Error: AddressDSL: AddressUpdate" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }
        public static DataSet GetContactIds()
        {

            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsContact = null;
            try
            {
                sql = "select Id from NewTable";
                con = DBHelper.GetConnection();
                con.Open();
                dsContact = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsContact);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:AddressDSL.cs:GetContactIds" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }
            return dsContact;
        }
        public static DataSet GetContact()
        {

            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsContact = null;
            try
            {

                sql = "select * from address_book";

                con = DBHelper.GetConnection();

                con.Open();

                dsContact = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsContact);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:AddressDSL.cs:GetContact" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }
            return dsContact;
        }


    }
}
