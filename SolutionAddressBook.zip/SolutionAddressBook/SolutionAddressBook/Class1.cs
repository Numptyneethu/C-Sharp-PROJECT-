﻿using System;

namespace SolutionAddressBook
{
    public class Class1
    {
    }
}
