﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest
{
    class Program
    {
        int no; int interval1, interval2;
        static void Main(string[] args)
        {
            int choice;
            Console.WriteLine("**********\nSelect One\n1 - Prime Number Checking\n2 - Print prime numbers between 2 intervals\n3 - Print N number of prime numbers\n4 - Exit\n**********");
            choice = Convert.ToInt32(Console.ReadLine());
            Program p = new Program();
            switch (choice)
            { case 1:
                  p.Read();
                  p.Calculate();
                  Console.ReadKey();
                  break;

              case 2:
                  p.ReadInterval();
                  p.CalculateInterval();
                  Console.ReadKey();
                  break;

                case 3:
                    p.input();
                    p.output();
                    Console.ReadKey();
                    break;

              case 4:
                System.Environment.Exit(0);
                break;
            }
        }
        void Read()
        {
            Console.WriteLine("Enter a number : -");
            no = Convert.ToInt32(Console.ReadLine());
        }
        void Calculate()
        {
            bool flag = false;

            for (int i = 2; i <no; i++)
            {
                if (no % i == 0)    
                {
                    flag = true;
                    break;
                }
                

            }

            if (flag == true) 
            {
                Console.WriteLine("The number {0} is not a prime number", no);
            } 
            else
            {
                Console.WriteLine("The number {0} is a prime number", no);
            }
        }

        void ReadInterval()
        {
            Console.WriteLine("Enter the first intervals - i1\n");
            interval1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the second intervals - i2\n");
            interval2 = Convert.ToInt32(Console.ReadLine());
        }
        void CalculateInterval()
        {
            for (int i = interval1; i <= interval2; i++)
            {
                int count = 0;
                for (int div = 2; div <= i; div++)
                {
                    if (i % div == 0)  //Prime
                    {
                        count++;
                    }

                }
                if (count==1)
                {
                    Console.WriteLine(i + "is a prime number");
                }
            }
        }
        void input()
        {
            Console.WriteLine("Enter 'N' to print N number of prime numbers-\n");
            interval2 = Convert.ToInt32(Console.ReadLine());
        }
        void output()
        {
            int count=0;
            for (int i=0; count < interval2; i++)
            {
              
                for (int div = 2; div <= i; div++)
                {
                    if (i % div == 0)  //Prime
                    {
                        count++;
                    }
                }
                if (count == 1)
                {
                    Console.WriteLine(i + "is a prime number");
                    count++;
                }
            }
        }
           

    }
}
