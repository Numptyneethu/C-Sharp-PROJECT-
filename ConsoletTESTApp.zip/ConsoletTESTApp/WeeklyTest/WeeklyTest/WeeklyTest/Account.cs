﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest
{
    public class Bank
    {
        
        public static void Main()
        {
            SBAccount obj1 = new SBAccount();
            obj1.CalculateInterest();
            SBAccount obj2 = new SBAccount();
            obj2.CalculateInterest();
            Console.ReadKey();
           
        }
    }
    public abstract class Account
    {
        public abstract void CalculateInterest();  //abstract method

    }

    public class SBAccount : Account
    {
        int principle, years, rate, SI; 
        public readonly int ID;   //readonly
        static int temp=1;
       

        public SBAccount()              //constructor
        {
            ID = temp;
            temp++;
        }
           
        public override void CalculateInterest()
        {
            Console.WriteLine("Enter a Principle :- ");
            principle = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the number of years :- ");
            years = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the rate of interest :- ");
            rate = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\nID:- {0},P:- {1}, N:-{2}, R:-{3}, ", ID, principle, years, rate);
            SI = principle * (1 + years * rate / 100);
            Console.WriteLine("Simple Interest :- " + SI);
            Console.WriteLine("********************************************************************");

        }
    }
}
