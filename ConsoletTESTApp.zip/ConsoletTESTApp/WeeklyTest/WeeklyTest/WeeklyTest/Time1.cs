﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest
{
    class Time
    {
        int hour, sec, minute;
        public static void Main()
        {
            Time obj1 = new Time();
            Time obj2 = new Time();
            Console.WriteLine("Enter  Time--(1):- ");
            obj1.ReadTime();
            Console.WriteLine("Enter  Time--(2):- ");
            obj2.ReadTime();
            Time obj3 = obj1 + obj2;
            obj3.Displaytime();
            Time obj4 = obj1 - obj2;
            obj4.Displaytime();
            Console.ReadKey();

        }
        public void ReadTime()
        {
            Console.WriteLine("Enter Hour :- ");
            hour = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Minute :- ");
            minute = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Seconds:- ");
           sec = Convert.ToInt32(Console.ReadLine());
        }
        public static Time operator +( Time t1,Time t2)  //always static for operator overloading
        {

            Time t = new Time();
            t.hour = t1.hour + t2.hour;
            t.sec = t1.sec + t2.sec;
            t.minute = t1.minute + t2.minute;
            if(t.sec>=60)
            {
                t.minute++;
               t.sec = 60 - t.sec;
            }
            if(t.minute>=60)
            {
                t.hour++;
                t.minute = 60 - t.minute;
            }

            return t;
        }
        public static Time operator - (Time t1, Time t2)
        {
            Time t=new Time();
            int total1, total2,subraction;
            total1 = t1.sec + t1.minute * 60 + t1.hour * 3600;
            total2 = t2.sec + t2.minute * 60 + t2.hour * 3600;
            subraction = Math.Abs(total1 - total2);
            t.sec = subraction % 60;
            subraction = subraction / 60;
            t.minute = subraction % 60;
            t.hour = subraction / 60;
            return t;
            
        }
        public void Displaytime()
        {
            Console.WriteLine("Hour-{0}, Minute-{1}, Seconds - {2} ",hour,minute,sec);
        }

    }
}
