﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace WeeklyTest
//{
//    class trial
//    {
//        public static void Main()
//        {
//            trial x = new trial();
//            int i1 = 2, i2 = 20;
//            x.calc();


//        }
//        bool flag = true;

//        for (int i1; i1<i2; i1++)
//        {

//            for (int i = 2; i <= n; i++)
//            {

//                if (n % i == 0)
//                {
//                    flag = true;
//                    Console.WriteLine(no + "aa\n");
//                }
//                else
//                {
//                    flag = false;   //prime
//                    Console.WriteLine(no + "bbb\n");

//                }

//            }

//            if (flag)
//            {


//                    Console.WriteLine(no + "ccc\n");

//            }
//        }
//    }
//}
