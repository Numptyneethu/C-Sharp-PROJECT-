﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class Inheritance
    {
        class Person
        {
            int id;
            string name;
            public void ReadP()
            {
                Console.WriteLine("Enter a name");
                name = Console.ReadLine();
                Console.WriteLine("Enter your ID ");
                id = Convert.ToInt32(Console.ReadLine());
            }
            public void DisplayP()

            {
                Console.WriteLine("Person Details:- NAME- {0} , ID -{1}", name, id);
            }
        }
        class Student : Person
        {
            int m1, m2, m3; double total; string Result;

            public void ReadS()
            {
                Console.WriteLine("Enter your Mark-1");
                m1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter your Mark-2");
                m2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter your Mark-3");
                m3 = Convert.ToInt32(Console.ReadLine());
            }
            public void DisplayS()

            {
                total = m1 + m2 + m3;
                if (total > 50)
                    Result = "Pass";
                else
                    Result = "Fail";


                Console.WriteLine("Student Details:- TOTAL MARKS- {0} , RESULT -{1}", total, Result);
            }
        }
        public static void Main()
        {
            Person obj = new Person();         //Base Class object----can only access base class data
            Student std = new Student();        //Derived Class object----can access base class data and derived class data
            //Person std = new Student();         //Dynamic Binding

            obj.ReadP();
            obj.DisplayP();
            std.ReadS();
            std.DisplayS();
            std.ReadS();
            Console.ReadKey();
        }
    }

}

