﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class SwitvhCaseMenu
    {
        
     public static void Main()
        {
            int option;
            do
         {
                Console.WriteLine("******************************");
                Console.WriteLine("1-Sum of Digits");
                Console.WriteLine("2- Check Prime ");
                Console.WriteLine("Exit");
                Console.WriteLine("Enter a number between 1 and 3");
                Console.WriteLine("******************************");
                option=Convert.ToInt32(Console.ReadLine());
          
            

            switch(option)
            {
                case 1:
                    DigitSum obj = new DigitSum();
                     obj.read();
                    obj.find();
                    obj.display();
                    Console.ReadKey();
                    break;
                case 2:
                    Prime obj1 = new Prime();
                    obj1.read();
                    obj1.calc();
                    obj1.disp();
                    Console.ReadKey();
                    break;
                case 3:
                    System.Environment.Exit(0);
                    break;

                default:
                    Console.WriteLine("Enter a valid  number between 1 and 3");
                    break;


            }
          } while (true);



        }
    }
}
