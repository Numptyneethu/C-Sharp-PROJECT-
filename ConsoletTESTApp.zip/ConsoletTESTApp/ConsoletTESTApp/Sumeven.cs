﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class Sumeven
    {
        int n,t, sum;
        public void read()
        {
            Console.WriteLine("Enter a number say N");
            n = Convert.ToInt32(Console.ReadLine());
        }
        public void SUM()
        {
            for(int i =0;i<n; i++)
            {
                sum = sum + 2;
                t = t + sum;
                
            }
           
            Console.WriteLine("Sum of first N even numbers-" +t);
            
        }
        public static void Main(string[] args)
        {
            Sumeven obj = new Sumeven();
            obj.read();
            obj.SUM();
            Console.ReadKey();
          
        }








    }
}
