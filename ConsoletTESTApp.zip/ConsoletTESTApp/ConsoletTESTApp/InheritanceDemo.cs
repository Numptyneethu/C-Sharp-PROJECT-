﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class InheritanceDemo
    {

        public static void Main()
        {
            A a1 = new A();
            B b1 = new B();
            a1.displayA();
            b1.displayB();

        }
        class A
        {
            public int val1;

            public A()              //constructor
            {
                val1 = 10;
            }
            public A(int v1)              //parametric constructor
            {
                val1 = v1;
            }
            public void displayA()
            { Console.WriteLine("In base class A"+val1);
              Console.ReadKey();
            }
        }
        class B : A
        {
            int val2;
            public B()             //constructor...will autmatically evoke base class constructor A
            {
                val2 = 100;
            }
            public B(int v1,int v2) :base(v1)     //call parametric constructor in A - base class
            {
                val2 = v2;
            }
            public void displayB()
            {
                Console.WriteLine("In base class B" + val2);
                Console.ReadKey();
            }

        }

    }
}
