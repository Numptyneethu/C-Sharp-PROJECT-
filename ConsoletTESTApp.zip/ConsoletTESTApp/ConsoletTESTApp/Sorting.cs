﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class Sorting
    {
        static int limit = 5;
        int[] array = { 3, 4, 1, 2, 6 };
        public static void Main()
        {
            Sorting obj = new Sorting();
            obj.Read();
            obj.Display();
            obj.Calculate();
            obj.Display();
            Console.ReadKey();
        }
        void Read()
        {
            Console.WriteLine("Enter the Numbers : - ");
            for (int i = 0; i < limit; i++)
            {
                array[i] = Convert.ToInt32(Console.ReadLine());
            }
        }

        void Display()
        {
            Console.WriteLine("{0} numbers of the array are : \n",limit);

            for (int i = 0; i < limit; i++)
            {
                Console.WriteLine(array [i]);
            }
        }
        void Calculate()
        {
            for(int i=0;i<=limit-1;i++)
            {
                for (int j = i+1; j <= limit-1; j++)
                {
                    if (array[i] > array[j])
                    {
                        int temp = array[i];
                        array[i] = array[j];
                        array[j] = temp;
                    }
                }
                   
            }
            Console.WriteLine("\nAfter SORTING : - ");
        }



    }
}
