﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class BinarySearch2
    {
        int limit, number;
        int[] array;

        public void ReadNumbers()
        {
            Console.WriteLine("Enter The limit of the Array ");
            limit = Convert.ToInt32(Console.ReadLine());
            array = new int[limit];  //search array

            Console.WriteLine("Enter Array Elements");
            for (int index = 0; index < limit; index++)
            {
                array[index] = Convert.ToInt32(Console.ReadLine());
            }
        }


        void Sort()
        {
            for (int i = 0; i <= limit - 1; i++)
            {
                for (int j = i + 1; j <= limit - 1; j++)
                {
                    if (array[i] > array[j])
                    {
                        int temp = array[i];
                        array[i] = array[j];
                        array[j] = temp;
                    }
                }

            }
            Console.WriteLine("\nAfter SORTING : - ");
        }


        public void SearchNumber()
        {
            Console.WriteLine("Enter the Number to be Searched ");
            number = Convert.ToInt32(Console.ReadLine());
            bool flag = false;
            int low = 0;
            int high = limit - 1;

            while (low <= high)
            {
                int middle = (high + low) / 2;

                if (array[middle] == number)
                {
                    flag = true;
                    Console.WriteLine("Number {0} Exists at location {1}", number, middle + 1);
                    break;
                }
                if (number < array[middle])
                {
                    high = middle - 1;
                }
                else
                {
                    low = middle + 1;
                }
            }
            if (!flag)
            {
                Console.WriteLine("Number {0} does not Exist in the Array", number);
            }
        }

        public static void Main()
        {
            BinarySearch2 obj = new BinarySearch2();
            obj.ReadNumbers();
            obj.Sort();
            obj.SearchNumber();

            Console.ReadKey();
        }
    }
}