﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class BinarySearch
    {
        static int limit = 5; int no;
        int[] array = { 30, 4, 11, 9, 6 };
        public static void Main()
        {
            BinarySearch obj = new BinarySearch();
            obj.Display();
            obj.Sort();
            obj.Display();
            obj.input();
            obj.search();
            Console.ReadKey();

        }
        void Display()
        {
            Console.WriteLine("{0} numbers of the array are : \n", limit);

            for (int i = 0; i < limit; i++)
            {
                Console.WriteLine(array[i]);
            }
        }
        void Sort()
        {
            for (int i = 0; i <= limit - 1; i++)
            {
                for (int j = i + 1; j <= limit - 1; j++)
                {
                    if (array[i] > array[j])  //exchange i and j
                    {
                        int temp = array[i];
                        array[i] = array[j];
                        array[j] = temp;
                    }
                }

            }
            Console.WriteLine("\nAfter SORTING : - ");
        }
        void input()
        {
            Console.WriteLine("Enter the Number which is te be searched : - ");
            no = Convert.ToInt32(Console.ReadLine());
        }
        void search()
        {
            int start = 0, stop = limit - 1;

            for (int length = array.Length; (length / 2) > 1; length = (length / 2) + 1)
            {
                int mid = (start + stop) / 2;
            Label1: if (no < array[start] || no > array[stop])
                {
                    Console.WriteLine("The number {0} is NOT present in the array", no);
                }
                else if (no == array[mid])
                {

                    stop = mid;
                    Console.WriteLine("The number {0} is present in the array at location - {1} ", no, mid + 1);
                    continue;
                }
                else if (no <= array[mid])
                {

                    stop = mid;
                    Console.WriteLine("zzzzz");
                    goto Label1;


                }
                else if (no > array[mid])
                {
                    start = mid;
                    goto Label1;

                }
                else
                {
                    Console.WriteLine("aaaaaaid");
                }

            }



        }

    }
}
