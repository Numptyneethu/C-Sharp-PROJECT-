﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class Primeinterval
    {
        int int1, int2;

        public void Read()
        {
            Console.WriteLine("Enter the first interval");
            int1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Eneter the second interval");
            int2 = Convert.ToInt32(Console.ReadLine());
        }
        public void calc()
        {
            
           
            
            for (int i = int1; i <= int2; i++)
        {
                int a = 0;
                for (int j = 2; j <= i; j++)
                {
                    if (i % j == 0)  //Prime
                    {
                        a = a + 1;
                    }

                }
                if (a == 1)
                {
                    Console.WriteLine(i + "is a prime number");
                }
               
            }
        }
        public static void Main(string[] args)
        {
            Primeinterval obj = new Primeinterval();
            obj.Read();
            obj.calc();
            Console.ReadKey();


        }


    }
}
