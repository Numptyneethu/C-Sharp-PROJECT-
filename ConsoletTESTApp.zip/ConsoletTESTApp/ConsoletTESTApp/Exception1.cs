﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class Exception1
    {
        public static void Main()
        {
            Sub obj = new Sub();
            Sub.Read();
            
        }
      
    }
    class Sub
    {
        public static void Read()
        {
            int value = 0, salary; bool flag = true;
            do
            {
                try
                {
                    Console.WriteLine("Enter mark");
                    value = Convert.ToInt32(Console.ReadLine());

                    try
                    {
                        Console.WriteLine("Enter salary");
                        salary = Convert.ToInt32(Console.ReadLine());
                    }
                    catch
                    {
                        Console.WriteLine("WRONG VALUE , Enter valid salary between 6000 and 7000");
                        flag =  false;

                    }
                }

                catch (Exception e)
                {
                    Console.WriteLine("WRONG VALUE , Enter mark between 0 and 100");
                    flag = false;
                }

            } while (flag);
            if (!flag)
            {

            }
        }

    }

}
