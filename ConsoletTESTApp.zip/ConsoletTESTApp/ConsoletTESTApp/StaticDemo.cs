﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class StaticDemo
    {
        public static void Main()
        {
            Console.WriteLine("10+22= " + Calculate.sum(10, 20));

            Calculate objcalc = new Calculate();
            Console.WriteLine("20-10= " + objcalc.diff(20, 10));
            Console.ReadKey();
        }


    }
}
