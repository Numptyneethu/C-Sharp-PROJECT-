﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class Factorial
    {
        int n=0;
        int fact = 1;

        public void Read()
        {
            Console.WriteLine("Enter a number ");
            n = Convert.ToInt32(Console.ReadLine());
        }
         
        public void Fact()
        {   if(n<0)
            {
                Console.WriteLine("Enter a valid number");
                Console.ReadKey();
                System.Environment.Exit(0);
            }

            for(int i=n;i>0;i--)
            {
                fact = fact * i;
            }
        }
        public void Display()
        {
            Console.WriteLine("Factorial of {0} is {1}",n, fact);
        }

        public static void Main()
        {
            Factorial obj = new Factorial();
            obj.Read();
            obj.Fact();
            obj.Display();
            Console.ReadKey();

        }

    }
}
