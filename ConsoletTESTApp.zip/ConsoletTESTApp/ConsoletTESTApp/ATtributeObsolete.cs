﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class ATtributeObsolete
    {
        public static void  Main()
        {
            List<int> list = new List<int>();
            list.Add(30);
            list.Add(20);
            list.Add(10);
            list.Add(40);


            int result1 = calculator.Add(10, 20);
            int result2 = calculator.Add(list);
            Console.ReadKey();
        }
    }

    [Obsolete ("Depricated Class ")]

    class calculator
    {
    [Obsolete ("new method:int Add(List<int> numbers)")]
    public static int Add(int value1,int value2)
         {
            return (value1 + value2);
         }
        public static int Add(List<int>numbers)
        {
            int sum = 0;
            foreach(int number in numbers)
            {
                sum = sum + number;
            }
         return sum;
        }
    }
}
