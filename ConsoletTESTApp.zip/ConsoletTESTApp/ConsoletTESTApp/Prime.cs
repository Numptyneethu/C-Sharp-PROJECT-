﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class Prime
    {
        int n;
        string result;
        public void read()
        {
            Console.WriteLine("Enter a number ");
            n = Convert.ToInt32(Console.ReadLine());
        }
        public void calc()
        {
            bool flag = true;
            for (int i =2;i<n;i++)
            {
                
                if (n % i == 0)  //Prime
                {
                    flag = false;
                    break;
                }
               
            }
        if(flag)
            {
                result = "PRIME";
            }
            else
            {
                result = "NOT PRIME";
            }
         
        }
        public void disp()

        { Console.WriteLine("The given number {0} is {1}",n,result);
           
        }
        public static void Main(string[] args)
        {
            Prime obj = new Prime();
            obj.read();
            obj.calc();
            obj.disp();
            Console.ReadKey();


        }












    }
}
