﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryDemo;

namespace ConsoletTESTApp
{
    class TestLibrary
    {
        public static void Main()
        {
            Calculator calc1 = new Calculator();
            calc1.display();
        }
    }
}
