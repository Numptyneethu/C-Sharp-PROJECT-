﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class BinaryToDecimal
    {
        int bin, dec = 0;

        public void read()
        {
            Console.WriteLine("Enter a binary number ");
            bin = Convert.ToInt32(Console.ReadLine());

        }
        public void find()
        {
            int lastdig,baseval,n;
            n = bin;
            baseval = 1;
            do
            {
                lastdig = n % 10;
                n = n / 10;
                dec = dec + lastdig * baseval;
                baseval = baseval * 2;


            } while (n > 0);
        }
        public void display()

        {
            Console.WriteLine("The decimal of the number {0} is {1}", bin, dec);

        }
        public static void Main()
        {
            BinaryToDecimal obj = new BinaryToDecimal();

            obj.read();
            obj.find();
            obj.display();
            Console.ReadKey();
        }


    }
}
