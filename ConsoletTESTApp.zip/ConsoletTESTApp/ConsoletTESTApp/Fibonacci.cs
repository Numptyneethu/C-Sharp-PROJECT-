﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class Fibonacci
    {
        int limit = 0; int n3;

        public void Read()
        {
            Console.WriteLine("Enter a number ");
            limit = Convert.ToInt32(Console.ReadLine());
        }

        public void Series()
        {
            int n1 = 0;
            int n2 = 1, count = 0;

            if (limit < 0)
            {
                Console.WriteLine("Enter a valid number");
                Console.ReadKey();
                System.Environment.Exit(0);
            }
            Console.WriteLine("Series upto " +limit+ " is - \n1");
            ++count;
            do
            {
                n3 = n1 + n2;
                Console.WriteLine(+n3);
                count++;
                n1 = n2;
                n2 = n3;

            } while (count<limit);

        }
        

        public static void Main()
        {
            Fibonacci obj = new Fibonacci();
            obj.Read();
            obj.Series();
            Console.ReadKey();

        }
    }
}
