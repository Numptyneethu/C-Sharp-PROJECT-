﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ConsoletTESTApp
{
    class ExceptionDemo
    {
        public static void Main()
        {
            int a = 10, b = 5, c = 0;
            Console.WriteLine("Before  try\n");

            try
            {
                Console.WriteLine("Inside try\n");
                c = a / 0;
            }
            catch(Exception e)
            {
                c = a / b;
                Console.WriteLine(c+"\nInside try\n" + e.Message.ToString());
            }

            Console.WriteLine("Outside catch\n");
            Console.ReadKey();
        }
        
    }
}
