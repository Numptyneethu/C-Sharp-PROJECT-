﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class Pattern3
    {
        public static void Main()
        {
            int i, k=1;
            string gap = " ";
            string star = "*";

            for (i = 1; i <= 5; i++)
            {
                for (int j=5; j >= i; j--)
                {
                    
                    Console.Write("o");
                    
                }
                Console.Write("-");
                Console.Write("\n");
            }
            Console.ReadKey();
        }

    }
}
