﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class Array
    {
        int noofelements, sum = 0;
        int[] arraysum=new int[10];
        public static void Main()
        {
            Array obj = new Array();
            obj.ReadArray();
            obj.CalculateSum();
            obj.DisplayArray();
            Console.ReadKey();
        }
        void ReadArray()
        {
            Console.WriteLine("Enter  number of elements in an array");
            noofelements = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter  the  elements ");

            for(int i=0;i<noofelements;i++)
            {
               arraysum[i] = Convert.ToInt32(Console.ReadLine());
            }
        }
        void CalculateSum()
        {
            for (int i = 0; i < noofelements; i++)
            {
                sum = arraysum[i] + sum;
            }
        }
        void DisplayArray()
        {
            Console.WriteLine("Array Elements of size {0} are ",noofelements);
            for (int i = 0; i < noofelements; i++)
            {
                Console.WriteLine(arraysum[i]);
            }
            Console.WriteLine("********************************");
        }
        
    }
}
