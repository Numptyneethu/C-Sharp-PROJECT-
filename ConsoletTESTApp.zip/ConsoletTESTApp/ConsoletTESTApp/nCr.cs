﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Ncr
    {
        int n, r;
        int ncr;

        public Ncr(int a, int b)
        {
            n = a;
            r = b;

        }

        public void FindNcr()
        {
            ncr = FindFactorial(n) / ((FindFactorial(r)) * (FindFactorial(n - r)));
        }
        public static int FindFactorial(int f)
        {
            int fact = 1;
            int i;

            for (i = 1; i <= f; i++)
            {

                fact = fact * i;
            }
            return fact;

        }

        public void Display()
        {

            Console.WriteLine(" ncr :{0}", ncr);
        }

        public static void Main()
        {

            Ncr ncr1 = new Ncr(20, 5);
            ncr1.FindNcr();
            ncr1.Display();
            Console.ReadKey();

        }


    }
}
