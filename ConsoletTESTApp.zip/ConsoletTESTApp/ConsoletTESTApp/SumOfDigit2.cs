﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class SumOfDigit2
    {
        int input,sum;

        public static  void Main()
        {

            SumOfDigit2 obj = new SumOfDigit2();
            obj.read();
            obj.check();
            obj.display();
            Console.ReadKey();
        }
        public void read()
        {
            Console.WriteLine("Enter a number ");
            input = Convert.ToInt32(Console.ReadLine());
        }
        public void check()
        {
            
            int temp = input;
            do
            {
                sum = find(temp);
                temp = sum;
            } while (temp> 9);

         
         }

        int find(int a)
        {
            int first = a, lastdig, summ = 0;
            do
            {
                lastdig = first % 10;
                summ = summ + lastdig; ;
                first = first / 10;
            } while (first > 0);
            return (summ);
        }


        public void display()
        {
            Console.WriteLine("Sum Is "+sum);
           
        }

    }
}
        

