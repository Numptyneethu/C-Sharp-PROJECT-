﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class CartProperty
    {
        public static void Main()
        {
            Product objCart = new Product();

            int option;
            do
            {
                Console.WriteLine("**********************");
                Console.WriteLine("1. Add Cart");
                Console.WriteLine("2. View Cart");
                Console.WriteLine("3. Checkout");
                Console.WriteLine("4. Exit");
                Console.WriteLine("**********************");
                Console.WriteLine("Enter the Option (1-4)");
                option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        objCart.AddCart();
                        break;
                    case 2:
                        objCart.ViewCart();
                        break;
                    case 3:

                        break;
                    case 4:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("\n!!!... Wrong option , Please enter 1-4.");
                        break;
                }
            } while (true);

            Console.ReadKey();
        }
    }
    class Product
    {
        int productId;
        private string productName;
        private int price, supplierId;
        static int count = 101;
        public Product()
        {
            productId = count;
            count++;
        }
        public String ProductName
        {
            get { return productName; }
            set { productName = value; }
        }
        public int Price
        {
            get { return price; }
            set { price = value; }
        }

        public int SupplierId
        {
            get { return supplierId; }
            set { supplierId = value; }
        }
        public void AddCart()
        {
            Console.WriteLine("Enter Product Name");
            productName = Console.ReadLine();
            Console.WriteLine("Enter Product Price");
            price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Supplier ID");
            supplierId = Convert.ToInt32(Console.ReadLine());
        }
        public void ViewCart()
        {
            Console.WriteLine("\n       Product Details      ");
            Console.WriteLine("----------------------------");
            Console.WriteLine("Product ID : " + productId);
            Console.WriteLine("Product Name : " + ProductName);
            Console.WriteLine("Product Price : " + price);
            Console.WriteLine("Supplier ID : " + supplierId);
            Console.WriteLine("----------------------------");
        }
    }
}