﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class DigitSum
    {
        int no, sumdig = 0;
      
       
       public void read()
        {
            Console.WriteLine("Enter a number ");
            no = Convert.ToInt32(Console.ReadLine());
        }
        public void display()

        {
            Console.WriteLine("The sum of digit of {0} is {1}", no, sumdig);

        }
        public void find()
        {
            int lastdig, n;
            n = no;
            do
            {
                lastdig = n % 10;
                sumdig = sumdig + lastdig;
                n = n / 10;

            } while (n > 0);
        }

        public static void Main()
        {
            DigitSum obj = new DigitSum();
            
            obj.read();
            obj.find();
            obj.display();
            Console.ReadKey();
        }
    }
}





        






