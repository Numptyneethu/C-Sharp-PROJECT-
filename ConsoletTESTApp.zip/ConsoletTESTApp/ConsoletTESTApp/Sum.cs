﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class Sum
    {
        int value1, value2, value3;

        public void Display()
        {
            Console.WriteLine("value 1 - " + value1);
            Console.WriteLine("value 2 - " + value2);
            Console.WriteLine("value 3 - " + value3);
        }
        public void Read()
        {
            Console.WriteLine("Enter value 1 ");
            value1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter value 2 ");
            value2 = Convert.ToInt32(Console.ReadLine());
        }
        public void CalculateSum()
        {
            value3 = value1 + value2;
        }

      

        public static void Main(string[] args)
        {
            Sum objsum = new Sum();   //object created
            objsum.Read();
            objsum.Display();
            objsum.CalculateSum();
            Console.ReadKey();  
        }
        
    }




}
