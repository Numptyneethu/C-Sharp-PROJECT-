﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class DecimalToBinary
    {
        int bin=0, dec = 0;

        public void read()
        {
            Console.WriteLine("Enter a decimal number ");
            dec = Convert.ToInt32(Console.ReadLine());

        }
        public void find()
        {
            int rem, baseval=1, n;
            n = dec;
        
            do
            {
                rem = n % 2;
                n = n / 2;
                bin = bin + baseval * rem;
                baseval = baseval * 10;

            } while (n > 0);
        }
        public void display()

        {
            Console.WriteLine("The binary of the number {0} is {1}", dec, bin);

        }
        public static void Main()
        {
            DecimalToBinary obj = new DecimalToBinary();

            obj.read();
            obj.find();
            obj.display();
            Console.ReadKey();
        }
    }
}
