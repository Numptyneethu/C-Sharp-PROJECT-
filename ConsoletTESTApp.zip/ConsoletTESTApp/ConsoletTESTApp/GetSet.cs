﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class GetSet
    {
        public static void Main()
        {
            Company obj = new Company();
            obj.CompanyID = 101;
            obj.CompanyName = "Neethu";
            Console.WriteLine(obj.CompanyID+ "  -  ID");
            Console.WriteLine(obj.CompanyName+ " - Name");
            Console.ReadKey();

        }

    }
    class Company
    {
        private int ID;
        private string Name, Address;

        public int CompanyID   //Company ID is the property --not a method
        {
            set { ID = value; }
            get { return ID; }
            
        }
        public string CompanyName
        {
            get { return Name; }
            set { Name = value; }

        }
            




    }
       


}
