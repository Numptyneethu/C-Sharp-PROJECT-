﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class CarParking
    {
     
        public int Parea = 5;
        public static int [] Pslot = new int[5];  //array
    public static void Main()
        {
             int choice;
        CarParking p = new CarParking();
            
            do
            {
                Console.WriteLine("**********\nSelect One\n1 - Park your car\n2 - Unpark your car\n3 - View available parking slots\n4 - Exit\n**********");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        p.parking();
                        break;

                    case 2:
                        p.unparking();
                        break;

                    case 3:
                        p.viewing();
                        break;

                    case 4:
                        System.Environment.Exit(0);
                        break;
                }
            } while (true);
            

        }
        public void parking()
        {
            bool flag = false;
           for(  int i=0 ; i<Parea; i++ )
           {
                if (Pslot[i] == 0)
                {
                    Pslot[i] = 1;
                    flag = true;
                    Console.WriteLine("Parked at  location " +(i+1));
                    i++;
                    break;
                }
                
            }
            if (flag = true)
            {
                Console.WriteLine("No parking area is available");
            }

        }
        public void unparking()
        {
            int unparkingno;
            Console.WriteLine("Enter your Parking Slot number for unparking your car ");
            unparkingno = Convert.ToInt32(Console.ReadLine());
            if(Pslot[unparkingno]==1)
            {
                Pslot[unparkingno] = 0;
                Console.WriteLine("Car is unparked from slot number -  "+unparkingno);
            }
            else
            {
                Console.WriteLine("No Car is parked at "+unparkingno);
            }
            
        }
        public void viewing()
        {
            bool flag = false;
            for (int i = 0; i <= Parea; i++)
            {
                if (Pslot[i] == 0)
                {
                    Console.WriteLine("Slot No "+(i+1)+ " is available for car parking " );
                    flag = true;

                }
                else
                {
                    Console.WriteLine("No parking area ");
                    break;
                }
            }
            if (flag != true)
            {
                Console.WriteLine("No parking area is available");
            }
            Console.ReadKey();
        }



    }
}
