﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    abstract class AbstractShape
    {

       

        public const double pi = 3.14;
        public double area;
        public abstract void findarea();
        public void display()
        {
            Console.WriteLine("Area - " + area);
            Console.ReadKey();
        }

        public static void Main()
        {
            Square sqrobj = new Square();
            sqrobj.readsquare();
            sqrobj.findarea();
            sqrobj.display();

            Circle crc = new Circle();
            crc.readcircle();
            crc.findarea();
            crc.display();

        }


    }

    class Square : AbstractShape
    {
        int side;

        public override void findarea()
        {
            area = side * side;
           
        }

        public void readsquare()
        {
            Console.WriteLine("Enter the side of a square ");
            side = Convert.ToInt32(Console.ReadLine());
        }
    }
    class Circle : AbstractShape
    {
        int radius;

        public override void findarea()
        {
            area = radius * radius * pi;

        }

        public void readcircle()
        {
            Console.WriteLine("Enter the radius ");
            radius = Convert.ToInt32(Console.ReadLine());
        }

    }
  
}




