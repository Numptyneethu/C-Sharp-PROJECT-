﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class Matrix
    {
        int[,] matrix;         //matrix decleration
        int row, column;
        int rowstart = 0, columnstart=0;
    public static void Main()
        {
            Matrix obj1 = new Matrix();
            Matrix obj2 = new Matrix();
            obj1.ReadMatrix();
            obj2.ReadMatrix();
            obj1.DisplayMatrix();
            obj2.DisplayMatrix();
            Matrix obj3;
            obj3 = obj1 + obj2;
            obj3.DisplayMatrix();
            //Matrix obj4;
            //obj4 = obj1 - obj2;
            //obj4.DisplayMatrix();


            Console.ReadKey();

        }
        void ReadMatrix()
        {
            Console.WriteLine("Enter  number of rows of the array");
            row = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter  number of columns of the array");
            column = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter  the  elements ");
            matrix = new int[row, column];               //matrix initialisatiob

            for (int rowstart = 0; rowstart < row; rowstart++)
            {
                for (int columnstart = 0; columnstart < column; columnstart++)
                {
                    matrix[rowstart, columnstart] = Convert.ToInt32(Console.ReadLine());
                }
                 
            }
            Console.WriteLine("***************");
        }
        void DisplayMatrix()
        {
            for (int rowstart = 0; rowstart < row; rowstart++)
            {
                for (int columnstart = 0; columnstart < column; columnstart++)
                {
                    Console.WriteLine( matrix[rowstart, columnstart]);  
                }
            }
            Console.WriteLine("***************");
        }
        public static Matrix operator +(Matrix M1,Matrix M2)      //public ans static since operator overloading
        {
            Matrix M3 = new Matrix();
           
            for (int rowstart = 0; rowstart < M1.row; rowstart++)
            {
               
                for (int columnstart = 0; columnstart < M1.column; columnstart++)
                {
                  
                    M3.rowstart = M1.rowstart + M2.rowstart;
                    M3.columnstart= M1.columnstart + M2.columnstart;
                }
            }
            return M3;
        }
    }
}
