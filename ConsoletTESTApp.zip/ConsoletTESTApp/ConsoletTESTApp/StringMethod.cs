﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class StringMethod
    {
        int ID, Salary, HRA, DA, TA;
        String name;
        public static void Main()
        {

        }
    }
    class Students
    {
        //Students s1 = new Students(101, "Rahul");   //should be passed to a constructor
        //Console.WriteLine(s1);
     
    }
}
