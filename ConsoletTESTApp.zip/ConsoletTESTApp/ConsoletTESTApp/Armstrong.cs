﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class Armstrong
    {
        int n, ans = 0;
        public void Read()
        {
            Console.WriteLine("Enter a number ");
            n = Convert.ToInt32(Console.ReadLine());
        }
        public void Calculate()
        {
           int i = n;
            for (; i > 0;)
            {

                int r = i % 10;
                ans = (r * r * r) + ans;
                i = i / 10;
            }
        }

    
        public void Display()
        {
            if (ans == n)
            {
                Console.WriteLine("Amstrong Number of {0} is {1} ", n, ans);
            }
            else
            {
                Console.WriteLine(n + "is not an Amstrong Number");


            }
        }
        public static void Main()
        {
            Armstrong obj = new Armstrong();
            obj.Read();
            obj.Calculate();
            obj.Display();
            Console.ReadKey();
        }
    }
}
