﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class circle
    {
        int r;
        public void Read()
        {
            Console.WriteLine("Enter the radius");
            r = Convert.ToInt32(Console.ReadLine());
        }

        public void area()
        {
            Console.WriteLine("Area = " + (3.14 * r * r));

        }
        public void peri()
        {
            Console.WriteLine("Perimeter = " + (3.14 * 2 * r));

        }

        public static void Main(string[] args)
        {
            circle obj = new circle();   //object created
            obj.Read();
            obj.area();
            obj.peri();

            Console.ReadKey();
        }
    }
}

