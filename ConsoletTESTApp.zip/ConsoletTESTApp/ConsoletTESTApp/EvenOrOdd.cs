﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class EvenOrOdd
    {
        int no, value;

        public void Read()
        {
            Console.WriteLine("Eneter the number");
            no = Convert.ToInt32(Console.ReadLine());
        }
        public void Find()
        {
            if (no % 2 == 0)
            {
                Console.WriteLine("It is an Even Number");
            }
            else
            {
                Console.WriteLine("It is an Odd Number");
            }


        }

        public static void Main(string[] args)
        {
            EvenOrOdd obj = new EvenOrOdd();   //object created
            obj.Read();
            obj.Find();

            Console.ReadKey();
        }
    }
}
