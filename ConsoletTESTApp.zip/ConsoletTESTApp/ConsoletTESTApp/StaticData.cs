﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class Static
    {

        int id=1;
        static int passmark=50;


        public void display()
        {
            id = id + 1;
            passmark = passmark + 1;
            Console.WriteLine("ID - {0},passmark - {1}", id, passmark);
        }




        public static void Main()
        {
            Static s1 = new Static();
            Static s2 = new Static();
            Static s3 = new Static();
            s1.display();
            s2.display();
            s3.display();
            Console.ReadKey();
        }
    }
}

