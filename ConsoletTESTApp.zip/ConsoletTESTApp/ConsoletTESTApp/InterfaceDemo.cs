﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class InterfaceDemo
    {
       public static void Main()
       {
            ABC obj = new ABC();
            //obj.disp();
            obj.Aaa();
            obj.disp1();
            Console.ReadKey();
           

        }
    }
    interface Inter1
    {
         void Aaa();        //abstarct method declaration

    }
      
    class class1
    {
       public void disp1()                 //should be in public mode to extend to derived classes.
        {
            Console.WriteLine("In class1  class -disp1 method");
          
        }
    }
    class ABC : class1, Inter1
    {
        
       public void Aaa()                     //override-----should be in public mode to extend to derived classes.
        {
            Console.WriteLine("aaaaaaABC class-disp method----overidded method");
          
        }

    }

}
