﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class AbstractDemo
    {
        abstract class ABC
        {
            int val1;
            static int val2;
            public abstract void disp();           //abstarct method declaration
            public static int find(int v1, int v2)
            {
                return (v1 + v2);
            }
            public void print()
            {
                Console.WriteLine("In class ABC -print method");
            }
        }
        class XYZ : ABC
        {
            int val3;
            public override void disp()               //abstarct method is overrided 
            {
                Console.WriteLine("In class XYZ -disp method");
            }
            public void check()
            {
                Console.WriteLine("In class XYZ -check method");
            }
        }
        public static void Main()
        {
            XYZ obj = new XYZ();
        
            obj.disp();
            obj.check();
            obj.print();
            int sum=  ABC.find(10, 5);
            Console.WriteLine("Sum is"+sum);

            



            Console.ReadKey();
        }

    }

}















