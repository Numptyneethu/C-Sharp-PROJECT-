﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class SingleDIgitSum
    {
        int no, sumdig = 0;
        
        public void read()
        {
            Console.WriteLine("Enter a number ");
            no = Convert.ToInt32(Console.ReadLine());
        }
          public void display()

          {
            Console.WriteLine("the sigle digits sum = "+sumdig);
            Console.ReadKey();
          }

        public int find(int b)

        {
            int first = b, sum=0;
            int lastdig;
            do
            {
                lastdig = first % 10;
                sum = sum+ lastdig;
                first = first / 10;

            } while (first>0);

            return (sum);
            
        }

        public void check()
        {
            
            int n;
            n = no;
            do
            {
               sumdig= find(n);
                n = sumdig;

            } while (n> 9);
          
        }
        public static void Main()
        {
            SingleDIgitSum obj = new SingleDIgitSum();
            obj.read();
            obj.check();
            obj.display();
         
        }
    }
}
