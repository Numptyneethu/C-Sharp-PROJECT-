﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class Interval
    {
        int int1, int2;
        public void Read()
        {
            Console.WriteLine("Enter the first interval");
            int1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Eneter the second interval");
            int2 = Convert.ToInt32(Console.ReadLine());
        }

        public void Find()
        {
            for (int i = int1; i < (int2 - int1 + 1); i++)
            {
                if (int1 % 2 != 0)
                {
                    Console.WriteLine(int1+ "is an Odd Number");
                }
             
            }
        }





    }
}
