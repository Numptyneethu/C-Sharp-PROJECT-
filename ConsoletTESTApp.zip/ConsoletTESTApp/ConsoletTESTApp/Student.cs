﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class Student
    {
        float mark;int id;string name; string result;
        static int passmark, minmark, maxmark;

        public void read()
        {
            Console.WriteLine("Enter your id");
            id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter your name");
            name = Console.ReadLine();
            Console.WriteLine("Enter your mark");
            mark = Convert.ToInt32(Console.ReadLine());
        }
        public void StaticData()
        {
            passmark = 80;
            minmark = 0;
            maxmark = 100;

            passmark++;
        }
        public void calc()
        {
            if(mark<=passmark)
            {
                Console.WriteLine("Name{0}\n---FAIL---\nPassmark-{1},Minimum Mark-{2},Maximum Mark -{3},",name,passmark,minmark,maxmark);
            }
            else
            {
                Console.WriteLine("Name{0}\n---PASS---\nPassmark-{1},Minimum Mark-{2},Maximum Mark -{3},", name, passmark, minmark, maxmark);
            }
            Console.ReadKey();

        }

        public static void Main()
        {
            
            Student obj = new Student();
            obj.read();
            obj.StaticData();
            obj.calc();
        
            Student obj1 = new Student();
            obj1.read();
            obj1.StaticData();
            obj1.calc();

        }












    }
}
