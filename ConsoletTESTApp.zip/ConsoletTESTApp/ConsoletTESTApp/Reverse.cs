﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoletTESTApp
{
    class Reverse
    {

        int no, rev=0;
            
     public void read()
        {
            Console.WriteLine("Enter a number ");
            no = Convert.ToInt32(Console.ReadLine());
        }
        public void find()
        {
            int lastdig, n;
            n = no;
            do
            {
                lastdig = n % 10;
                n = n / 10;
                rev = rev*10 + lastdig;


            } while (n > 0);
        }
        public void display()

        {
            Console.WriteLine("The reverse of the number {0} is {1}", no, rev);

        }
        public static void Main()
        {
            Reverse obj = new Reverse();

            obj.read();
            obj.find();
            obj.display();
            Console.ReadKey();
        }















    }
}
