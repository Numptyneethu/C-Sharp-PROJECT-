﻿//#define RELEASE
//#define FOOL   //defining that value as preprocessor directive will execute that method
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;




namespace ConsoletTESTApp
{
    class Attribute
    {
        public static void Main()
        {
            Greet.GreetDebug();
            Greet.GreetRelease();
            Greet.GreetFool();
            Console.ReadKey();
        }
      


        //Solution config=debug --3 output else when it is in release mode DEBUG is not executed 

    }

    class Greet
    {
      [Conditional ("DEBUG")]   //Conditional Attribute    --no need of defining DEBUG 
      public static void GreetDebug()
        {
            Console.WriteLine("Greeting from Debug ");
        }
        [Conditional("RELEASE")]
        public static void GreetRelease()
        {
            Console.WriteLine("Greeting from Release ");
        }
        [Conditional("FOOL")]  //method is attributed with preprocessor value
        public static void GreetFool()
        {
            Console.WriteLine("Greeting from Trace ");
        }

    }
}
